/*
Navicat MySQL Data Transfer

Source Server         : 119.3.79.152
Source Server Version : 50724
Source Host           : localhost:3306
Source Database       : annual_party_bosch

Target Server Type    : MYSQL
Target Server Version : 50724
File Encoding         : 65001

Date: 2019-01-21 09:42:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for agenda
-- ----------------------------
DROP TABLE IF EXISTS `agenda`;
CREATE TABLE `agenda` (
  `id` varchar(255) NOT NULL,
  `start_at` datetime DEFAULT NULL COMMENT '开始时间',
  `end_at` datetime DEFAULT NULL COMMENT '结束时间',
  `duration` bigint(20) DEFAULT NULL COMMENT '持续时间',
  `content` varchar(255) DEFAULT NULL COMMENT '日程安排内容',
  `agenda_day` varchar(255) DEFAULT NULL COMMENT '日程安排的日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='日程安排';

-- ----------------------------
-- Records of agenda
-- ----------------------------
INSERT INTO `agenda` VALUES ('A10051000', '2019-01-17 06:00:00', '2019-01-17 18:00:00', null, 'Arrival', 'Day 1: 17th-Jan');
INSERT INTO `agenda` VALUES ('A10051001', '2019-01-17 12:00:00', '2019-01-17 13:00:00', null, 'Lunch', 'Day 1: 17th-Jan');
INSERT INTO `agenda` VALUES ('A10051002', '2019-01-17 14:00:00', '2019-01-17 18:00:00', null, 'Leadership Dialogue', 'Day 1: 17th-Jan');
INSERT INTO `agenda` VALUES ('A10051003', '2019-01-17 14:00:00', '2019-01-17 18:00:00', null, 'Parallel Team Activities', 'Day 1: 17th-Jan');
INSERT INTO `agenda` VALUES ('A10051004', '2019-01-17 19:00:00', '2019-01-17 22:00:00', null, 'Welcome Dinner ', 'Day 1: 17th-Jan');
INSERT INTO `agenda` VALUES ('A10051006', '2019-01-18 08:00:00', '2019-01-18 08:15:00', null, 'Welcome', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051007', '2019-01-18 08:15:00', '2019-01-18 09:30:00', '7', 'BV Strategy Presentation ', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051008', '2019-01-18 09:30:00', '2019-01-18 09:50:00', null, 'GDU Presenation', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051009', '2019-01-18 09:50:00', '2019-01-18 10:30:00', null, 'Product Demo', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051010', '2019-01-18 09:50:00', '2019-01-18 10:30:00', null, 'Coffee Break & Networking', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051011', '2019-01-18 10:30:00', '2019-01-18 12:00:00', null, 'rBU & Sales Presentation ', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051012', '2019-01-18 12:00:00', '2019-01-18 12:30:00', null, 'Group Photo & Rotation Briefing', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051013', '2019-01-18 12:30:00', '2019-01-18 13:30:00', null, 'Lunch Break', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051014', '2019-01-18 13:30:00', '2019-01-18 14:30:00', null, 'Product Demo', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051015', '2019-01-18 14:40:00', '2019-01-18 15:40:00', null, 'Focus Topic Rotation 1', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051016', '2019-01-18 15:40:00', '2019-01-18 16:00:00', null, 'Coffee Break & Networking', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051017', '2019-01-18 16:00:00', '2019-01-18 17:00:00', null, 'Focus Topic Rotation 2', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051018', '2019-01-18 17:10:00', '2019-01-18 18:10:00', null, 'Focus Topic Rotation 3', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051019', '2019-01-18 18:10:00', '2019-01-18 18:30:00', null, 'Wrap Up', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051020', '2019-01-18 18:30:00', '2019-01-18 19:30:00', null, 'Free time', 'Day 2: 18th-Jan');
INSERT INTO `agenda` VALUES ('A10051021', '2019-01-18 19:30:00', '2019-01-18 21:30:00', null, 'Gala Dinner', 'Day 2: 18th-Jan');

-- ----------------------------
-- Table structure for beacon
-- ----------------------------
DROP TABLE IF EXISTS `beacon`;
CREATE TABLE `beacon` (
  `id` varchar(50) NOT NULL COMMENT 'ID',
  `major` int(11) DEFAULT NULL,
  `minor` int(11) DEFAULT NULL,
  `indoor_map_id` varchar(50) DEFAULT NULL COMMENT '室内地图ID',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_at` datetime DEFAULT NULL COMMENT '更新时间',
  `percent_x` float(10,3) DEFAULT NULL,
  `percent_y` float(10,3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `indoor_map_id` (`indoor_map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='信标';

-- ----------------------------
-- Records of beacon
-- ----------------------------
INSERT INTO `beacon` VALUES ('1081072722030759936', '14', '155', 'kickoff2019', null, '2019-01-04 14:19:56', '2019-01-04 15:12:25', '34.664', '29.013');
INSERT INTO `beacon` VALUES ('1081074718435577856', '14', '228', 'kickoff2019', null, '2019-01-04 14:27:52', '2019-01-04 15:13:19', '42.143', '54.400');
INSERT INTO `beacon` VALUES ('1081074967103279104', '14', '152', 'kickoff2019', null, '2019-01-04 14:28:52', '2019-01-04 15:13:52', '30.336', '26.457');
INSERT INTO `beacon` VALUES ('1081075250881499136', '14', '156', 'kickoff2019', null, '2019-01-04 14:29:59', '2019-01-04 15:14:08', '30.735', '20.348');
INSERT INTO `beacon` VALUES ('1081075552292573184', '14', '161', 'kickoff2019', null, '2019-01-04 14:31:11', '2019-01-04 15:14:24', '35.463', '14.150');
INSERT INTO `beacon` VALUES ('1081075698761863168', '14', '251', 'kickoff2019', null, '2019-01-04 14:31:46', '2019-01-04 15:14:40', '46.134', '15.696');
INSERT INTO `beacon` VALUES ('1081075837610102784', '14', '201', 'kickoff2019', null, '2019-01-04 14:32:19', '2019-01-04 15:14:52', '55.048', '15.101');
INSERT INTO `beacon` VALUES ('1081075962898157568', '14', '164', 'kickoff2019', null, '2019-01-04 14:32:49', '2019-01-04 15:15:06', '55.042', '8.234');
INSERT INTO `beacon` VALUES ('1081076105974255616', '14', '192', 'kickoff2019', null, '2019-01-04 14:33:23', '2019-01-04 15:15:16', '49.585', '2.348');
INSERT INTO `beacon` VALUES ('1081076201302396928', '14', '207', 'kickoff2019', null, '2019-01-04 14:33:46', '2019-01-04 15:15:28', '44.500', '2.408');
INSERT INTO `beacon` VALUES ('1081076274216177664', '14', '232', 'kickoff2019', null, '2019-01-04 14:34:03', '2019-01-04 15:15:38', '37.164', '2.556');
INSERT INTO `beacon` VALUES ('1081076532610469888', '14', '176', 'kickoff2019', null, '2019-01-04 14:35:05', '2019-01-04 15:15:55', '36.943', '6.153');
INSERT INTO `beacon` VALUES ('1085741899152756736', '14', '245', 'kickoff2019', null, null, null, '29.286', '33.264');
INSERT INTO `beacon` VALUES ('1085742103415361536', '14', '191', 'kickoff2019', null, null, null, '30.315', '37.782');
INSERT INTO `beacon` VALUES ('1085742461697003520', '14', '250', 'kickoff2019', null, null, null, '26.586', '41.312');
INSERT INTO `beacon` VALUES ('1085742813221621760', '14', '160', 'kickoff2019', null, null, null, '28.803', '46.121');
INSERT INTO `beacon` VALUES ('1085743139467169792', '14', '224', 'kickoff2019', null, null, null, '29.370', '52.192');
INSERT INTO `beacon` VALUES ('1085743312230551552', '14', '217', 'kickoff2019', null, null, null, '42.647', '45.333');
INSERT INTO `beacon` VALUES ('1085743449493344256', '14', '187', 'kickoff2019', null, null, null, '42.269', '34.483');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` varchar(100) NOT NULL COMMENT 'id',
  `user_id` varchar(100) NOT NULL COMMENT '用户Id',
  `topic` varchar(255) DEFAULT NULL COMMENT '主题',
  `content` varchar(255) DEFAULT NULL COMMENT '留言内容',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('1085719471051640832', '10051153', null, 'Welcome to Asia Kick-off 2019 !', '2019-01-17 10:04:28');
INSERT INTO `comment` VALUES ('1085720093356331008', '10051166', null, 'Enjoy～!', '2019-01-17 10:06:57');
INSERT INTO `comment` VALUES ('1085735366239064064', '10051080', null, 'I like the digital arrangement! :-)', '2019-01-17 11:07:38');
INSERT INTO `comment` VALUES ('1085737752017899520', '10051176', null, 'Looking forward to 2 exiting days!', '2019-01-17 11:17:07');
INSERT INTO `comment` VALUES ('1085753815145254912', '10051084', null, 'Like the map, btw, who is the heart?', '2019-01-17 12:20:57');
INSERT INTO `comment` VALUES ('1085758796749475840', '10051191', null, 'Cute heart=Staff Crew :)', '2019-01-17 12:40:44');
INSERT INTO `comment` VALUES ('1085765115116130304', '10051143', null, 'This information platform is really cool,  flat , transparent and with interesting functionality.', '2019-01-17 13:05:51');
INSERT INTO `comment` VALUES ('1085768519251005440', '10051179', null, 'Amazing platform -:)', '2019-01-17 13:19:22');
INSERT INTO `comment` VALUES ('1085770694668718080', '10051110', null, 'Quite some dots in lobby now', '2019-01-17 13:28:01');
INSERT INTO `comment` VALUES ('1085810141007319040', '10051107', null, 'exacting!!', '2019-01-17 16:04:46');
INSERT INTO `comment` VALUES ('1085810520604413952', '10051179', null, 'Hallo', '2019-01-17 16:06:16');
INSERT INTO `comment` VALUES ('1085811103839162368', '10051176', null, 'Test', '2019-01-17 16:08:35');
INSERT INTO `comment` VALUES ('1085811285381222400', '10051158', null, 'Wow!', '2019-01-17 16:09:18');
INSERT INTO `comment` VALUES ('1085811410241458176', '10051149', null, 'Enjoy the IoT!', '2019-01-17 16:09:48');
INSERT INTO `comment` VALUES ('1085812091811663872', '10051107', null, 'test', '2019-01-17 16:12:31');
INSERT INTO `comment` VALUES ('1085818807848669184', '10051107', null, 'test', '2019-01-17 16:39:12');
INSERT INTO `comment` VALUES ('1085819335626330112', '10051179', null, 'Test', '2019-01-17 16:41:18');
INSERT INTO `comment` VALUES ('1085820408202137600', '10051179', null, 'A', '2019-01-17 16:45:34');
INSERT INTO `comment` VALUES ('1085824200511459328', '10051179', null, 'B', '2019-01-17 17:00:38');
INSERT INTO `comment` VALUES ('1085824603995115520', '10051211', null, 'Nice arrangement', '2019-01-17 17:02:14');
INSERT INTO `comment` VALUES ('1085871298481098752', '10051027', null, 'text', '2019-01-17 20:07:47');
INSERT INTO `comment` VALUES ('1085871560708984832', '10051027', null, 'test', '2019-01-17 20:08:49');
INSERT INTO `comment` VALUES ('1085875716119203840', '10051138', null, 'There will be surprise for those who visit Dust Free Booth tomorrow:)', '2019-01-17 20:25:20');
INSERT INTO `comment` VALUES ('1085879434466168832', '10051179', null, 'Test', '2019-01-17 20:40:06');
INSERT INTO `comment` VALUES ('1085903104211292160', '10051129', null, 'A', '2019-01-17 22:14:10');
INSERT INTO `comment` VALUES ('1085903105821904896', '10051176', null, 'B', '2019-01-17 22:14:10');
INSERT INTO `comment` VALUES ('1085903137115607040', '10051126', null, 'B', '2019-01-17 22:14:18');
INSERT INTO `comment` VALUES ('1085903164479246336', '10051179', null, 'B', '2019-01-17 22:14:24');
INSERT INTO `comment` VALUES ('1085904178259300352', '10051129', null, 'B', '2019-01-17 22:18:26');
INSERT INTO `comment` VALUES ('1085904182592016384', '10051176', null, 'B', '2019-01-17 22:18:27');
INSERT INTO `comment` VALUES ('1085904184965992448', '10051126', null, 'B', '2019-01-17 22:18:27');
INSERT INTO `comment` VALUES ('1085905044332744704', '10051126', null, 'C', '2019-01-17 22:21:52');
INSERT INTO `comment` VALUES ('1085905078000422912', '10051129', null, 'B', '2019-01-17 22:22:00');
INSERT INTO `comment` VALUES ('1085905173840269312', '10051179', null, 'C', '2019-01-17 22:22:23');
INSERT INTO `comment` VALUES ('1086084522543550464', '10051134', null, 'Welcome to Asia Kick-off 2019 !', '2019-01-18 10:15:03');
INSERT INTO `comment` VALUES ('1086103924722765824', '10051129', null, 'See u all later at product demo session!', '2019-01-18 11:32:09');
INSERT INTO `comment` VALUES ('1086184266477473792', '10051184', null, 'Bravo! Pro Pruner!', '2019-01-18 16:51:24');
INSERT INTO `comment` VALUES ('1086205391068598272', '10051176', null, 'My KUDO card for the whole Ogranization team is “Totally Awesome”\nIt was an amazing event. Thank you!', '2019-01-18 18:15:21');

-- ----------------------------
-- Table structure for device
-- ----------------------------
DROP TABLE IF EXISTS `device`;
CREATE TABLE `device` (
  `id` varchar(50) NOT NULL COMMENT 'ID',
  `rfid` varchar(255) DEFAULT NULL,
  `dev_id` varchar(50) NOT NULL COMMENT '设备EUI,devId',
  `alias` varchar(50) DEFAULT NULL COMMENT '设备别名',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_at` datetime DEFAULT NULL COMMENT '更新时间',
  `indoor_map_id` varchar(100) NOT NULL COMMENT '所属楼层',
  `major` int(255) DEFAULT NULL COMMENT '最近信标major',
  `minor` int(255) DEFAULT NULL COMMENT '最近信标minor',
  `is_offline` int(11) DEFAULT NULL COMMENT '1离线，2在线',
  `is_move` int(11) DEFAULT NULL COMMENT '设备是否移动，1是0否',
  `device_color` varchar(255) DEFAULT NULL COMMENT '卡的颜色,组别,就是user_group_id',
  `step_counter` int(11) DEFAULT NULL COMMENT '计步器',
  PRIMARY KEY (`dev_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设备';

-- ----------------------------
-- Records of device
-- ----------------------------
INSERT INTO `device` VALUES ('000000000000000x', '000000000000000x', '000000000000000x', '测试用', '2018-12-21 16:00:09', '2019-01-16 20:08:31', 'kickoff2019', null, null, '1', '1', '1', '0');
INSERT INTO `device` VALUES ('0000000011030565', '59D615DE012302E0', '0000000011030565', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '4', '10198');
INSERT INTO `device` VALUES ('0000000011030566', '61F315DE012302E0', '0000000011030566', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, null, '1', '1', '4', '0');
INSERT INTO `device` VALUES ('0000000011030567', 'DDC415DE012302E0', '0000000011030567', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '187', '1', '1', '4', '6965');
INSERT INTO `device` VALUES ('0000000011030568', '446E38DE012302E0', '0000000011030568', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '4', '4489');
INSERT INTO `device` VALUES ('0000000011030569', '6FA4B153002302E0', '0000000011030569', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '4', '2239');
INSERT INTO `device` VALUES ('000000001103056A', '1979B053002302E0', '000000001103056A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '4', '2863');
INSERT INTO `device` VALUES ('000000001103056B', 'B9D8AF53002302E0', '000000001103056B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '4', '1385');
INSERT INTO `device` VALUES ('000000001103056C', 'C8E8B153002302E0', '000000001103056C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '4', '1959');
INSERT INTO `device` VALUES ('000000001103056D', 'A20016DE012302E0', '000000001103056D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '4', '4203');
INSERT INTO `device` VALUES ('000000001103056E', 'DEFE15DE012302E0', '000000001103056E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '4', '1825');
INSERT INTO `device` VALUES ('000000001103056F', '4F42AF53002302E0', '000000001103056F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '3202');
INSERT INTO `device` VALUES ('0000000011030570', '8914B253002302E0', '0000000011030570', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '2942');
INSERT INTO `device` VALUES ('0000000011030571', '1E36BA53002302E0', '0000000011030571', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '5', '1378');
INSERT INTO `device` VALUES ('0000000011030572', 'C12CB553002302E0', '0000000011030572', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '1100');
INSERT INTO `device` VALUES ('0000000011030573', '0441B153002302E0', '0000000011030573', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '5', '3493');
INSERT INTO `device` VALUES ('0000000011030574', 'EF82B453002302E0', '0000000011030574', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '5', '1235');
INSERT INTO `device` VALUES ('0000000011030575', '484DB353002302E0', '0000000011030575', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '3033');
INSERT INTO `device` VALUES ('0000000011030576', '3128B253002302E0', '0000000011030576', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '5', '1518');
INSERT INTO `device` VALUES ('0000000011030577', '58A5B853002302E0', '0000000011030577', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '5', '969');
INSERT INTO `device` VALUES ('0000000011030578', 'A332B453002302E0', '0000000011030578', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '5', '3847');
INSERT INTO `device` VALUES ('0000000011030579', 'D23CB653002302E0', '0000000011030579', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '1673');
INSERT INTO `device` VALUES ('000000001103057A', 'B16FB353002302E0', '000000001103057A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '5', '3176');
INSERT INTO `device` VALUES ('000000001103057B', '68AAB453002302E0', '000000001103057B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '3077');
INSERT INTO `device` VALUES ('000000001103057C', 'D43EB853002302E0', '000000001103057C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '251', '1', '1', '5', '1074');
INSERT INTO `device` VALUES ('000000001103057D', '2A32B653002302E0', '000000001103057D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '16168');
INSERT INTO `device` VALUES ('000000001103057E', '511FB653002302E0', '000000001103057E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '5331');
INSERT INTO `device` VALUES ('000000001103057F', '1539B853002302E0', '000000001103057F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '3291');
INSERT INTO `device` VALUES ('0000000011030580', 'A124B453002302E0', '0000000011030580', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '5', '2320');
INSERT INTO `device` VALUES ('0000000011030581', '42ECAF53002302E0', '0000000011030581', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '5', '1275');
INSERT INTO `device` VALUES ('0000000011030582', '6ADDB053002302E0', '0000000011030582', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '5', '4234');
INSERT INTO `device` VALUES ('0000000011030583', 'C527B553002302E0', '0000000011030583', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2602');
INSERT INTO `device` VALUES ('0000000011030584', '98F0B253002302E0', '0000000011030584', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '2375');
INSERT INTO `device` VALUES ('0000000011030585', 'FF14B553002302E0', '0000000011030585', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '1337');
INSERT INTO `device` VALUES ('0000000011030586', '80B1B253002302E0', '0000000011030586', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2902');
INSERT INTO `device` VALUES ('0000000011030587', '5B80B653002302E0', '0000000011030587', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '3489');
INSERT INTO `device` VALUES ('0000000011030588', 'B150B653002302E0', '0000000011030588', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '1250');
INSERT INTO `device` VALUES ('0000000011030589', '1276B253002302E0', '0000000011030589', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '3255');
INSERT INTO `device` VALUES ('000000001103058A', 'F4F9B453002302E0', '000000001103058A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '3631');
INSERT INTO `device` VALUES ('000000001103058B', '44CFB353002302E0', '000000001103058B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '156', '1', '1', '3', '2576');
INSERT INTO `device` VALUES ('000000001103058C', '71F8B153002302E0', '000000001103058C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '3', '1706');
INSERT INTO `device` VALUES ('000000001103058D', '92ADBA53002302E0', '000000001103058D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '5988');
INSERT INTO `device` VALUES ('000000001103058E', 'A706B153002302E0', '000000001103058E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '2036');
INSERT INTO `device` VALUES ('000000001103058F', 'FCCDAF53002302E0', '000000001103058F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '4923');
INSERT INTO `device` VALUES ('0000000011030590', '2C2EAF53002302E0', '0000000011030590', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, null, '1', '1', '1', '0');
INSERT INTO `device` VALUES ('0000000011030591', '9DD7B253002302E0', '0000000011030591', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '1', '2657');
INSERT INTO `device` VALUES ('0000000011030592', '3DF4B353002302E0', '0000000011030592', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '1698');
INSERT INTO `device` VALUES ('0000000011030593', '854BB453002302E0', '0000000011030593', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2545');
INSERT INTO `device` VALUES ('0000000011030594', 'BF47B153002302E0', '0000000011030594', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '1701');
INSERT INTO `device` VALUES ('0000000011030595', '38ECB653002302E0', '0000000011030595', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '1567');
INSERT INTO `device` VALUES ('0000000011030596', 'BDCDB853002302E0', '0000000011030596', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2863');
INSERT INTO `device` VALUES ('0000000011030597', 'EA19B653002302E0', '0000000011030597', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2876');
INSERT INTO `device` VALUES ('0000000011030598', '00C9B653002302E0', '0000000011030598', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '4149');
INSERT INTO `device` VALUES ('0000000011030599', 'DAEAAE53002302E0', '0000000011030599', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '7999');
INSERT INTO `device` VALUES ('000000001103059A', '186AB553002302E0', '000000001103059A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '2346');
INSERT INTO `device` VALUES ('000000001103059B', '1731AF53002302E0', '000000001103059B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2721');
INSERT INTO `device` VALUES ('000000001103059C', '3291B553002302E0', '000000001103059C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2416');
INSERT INTO `device` VALUES ('000000001103059D', 'BDD3AF53002302E0', '000000001103059D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '3346');
INSERT INTO `device` VALUES ('000000001103059E', '4473B153002302E0', '000000001103059E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '1', '2101');
INSERT INTO `device` VALUES ('000000001103059F', '75CCB453002302E0', '000000001103059F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2901');
INSERT INTO `device` VALUES ('00000000110305A0', '202EB153002302E0', '00000000110305A0', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '5075');
INSERT INTO `device` VALUES ('00000000110305A1', '19BBB853002302E0', '00000000110305A1', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '5553');
INSERT INTO `device` VALUES ('00000000110305A2', 'A758B053002302E0', '00000000110305A2', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '2885');
INSERT INTO `device` VALUES ('00000000110305A3', 'C579B453002302E0', '00000000110305A3', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3403');
INSERT INTO `device` VALUES ('00000000110305A4', 'BB4CB153002302E0', '00000000110305A4', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '1718');
INSERT INTO `device` VALUES ('00000000110305A5', '70B5B553002302E0', '00000000110305A5', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '2244');
INSERT INTO `device` VALUES ('00000000110305A6', '8D3FB953002302E0', '00000000110305A6', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '1974');
INSERT INTO `device` VALUES ('00000000110305A7', '1578B753002302E0', '00000000110305A7', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '2538');
INSERT INTO `device` VALUES ('00000000110305A8', 'C113B053002302E0', '00000000110305A8', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '1378');
INSERT INTO `device` VALUES ('00000000110305A9', '3D77B453002302E0', '00000000110305A9', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '2439');
INSERT INTO `device` VALUES ('00000000110305AA', '359FB053002302E0', '00000000110305AA', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '2240');
INSERT INTO `device` VALUES ('00000000110305AB', 'EE2DB353002302E0', '00000000110305AB', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '2979');
INSERT INTO `device` VALUES ('00000000110305AC', '5CB0AF53002302E0', '00000000110305AC', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '2123');
INSERT INTO `device` VALUES ('00000000110305AD', '45BDB253002302E0', '00000000110305AD', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3036');
INSERT INTO `device` VALUES ('00000000110305AE', '90A4B453002302E0', '00000000110305AE', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '2489');
INSERT INTO `device` VALUES ('00000000110305AF', '713AB953002302E0', '00000000110305AF', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '2337');
INSERT INTO `device` VALUES ('00000000110305B0', '953EAF53002302E0', '00000000110305B0', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '4095');
INSERT INTO `device` VALUES ('00000000110305B1', 'FC2EB553002302E0', '00000000110305B1', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '1', '2203');
INSERT INTO `device` VALUES ('00000000110305B2', 'E6A4B353002302E0', '00000000110305B2', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2696');
INSERT INTO `device` VALUES ('00000000110305B3', 'E177B053002302E0', '00000000110305B3', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '1285');
INSERT INTO `device` VALUES ('00000000110305B4', '6B6DB953002302E0', '00000000110305B4', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '1', '3033');
INSERT INTO `device` VALUES ('00000000110305B5', 'D3F2B553002302E0', '00000000110305B5', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3231');
INSERT INTO `device` VALUES ('00000000110305B6', 'C874B853002302E0', '00000000110305B6', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, null, '1', '1', '1', '0');
INSERT INTO `device` VALUES ('00000000110305B7', '5CEFB753002302E0', '00000000110305B7', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3489');
INSERT INTO `device` VALUES ('00000000110305B8', 'D41EB353002302E0', '00000000110305B8', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '2575');
INSERT INTO `device` VALUES ('00000000110305B9', 'E1F4B753002302E0', '00000000110305B9', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '4148');
INSERT INTO `device` VALUES ('00000000110305BA', '8866B353002302E0', '00000000110305BA', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '2142');
INSERT INTO `device` VALUES ('00000000110305BB', 'E830B353002302E0', '00000000110305BB', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '3059');
INSERT INTO `device` VALUES ('00000000110305BC', '79B3B953002302E0', '00000000110305BC', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2914');
INSERT INTO `device` VALUES ('00000000110305BD', 'F3F7B153002302E0', '00000000110305BD', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '2246');
INSERT INTO `device` VALUES ('00000000110305BE', 'CD4CB653002302E0', '00000000110305BE', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3946');
INSERT INTO `device` VALUES ('00000000110305BF', '9CDBB953002302E0', '00000000110305BF', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '2613');
INSERT INTO `device` VALUES ('00000000110305C0', '5A10B453002302E0', '00000000110305C0', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '4771');
INSERT INTO `device` VALUES ('00000000110305C1', '963AB353002302E0', '00000000110305C1', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '4045');
INSERT INTO `device` VALUES ('00000000110305C2', '4491B253002302E0', '00000000110305C2', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '1512');
INSERT INTO `device` VALUES ('00000000110305C3', 'D371B253002302E0', '00000000110305C3', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '2551');
INSERT INTO `device` VALUES ('00000000110305C4', 'AE41B253002302E0', '00000000110305C4', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '155', '1', '1', '1', '1358');
INSERT INTO `device` VALUES ('00000000110305C5', 'B9D9B653002302E0', '00000000110305C5', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '2954');
INSERT INTO `device` VALUES ('00000000110305C6', '1304B353002302E0', '00000000110305C6', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '4107');
INSERT INTO `device` VALUES ('00000000110305C7', '6B2CB653002302E0', '00000000110305C7', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3531');
INSERT INTO `device` VALUES ('00000000110305C8', '7675B353002302E0', '00000000110305C8', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '3460');
INSERT INTO `device` VALUES ('00000000110305C9', '6494B653002302E0', '00000000110305C9', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '5704');
INSERT INTO `device` VALUES ('00000000110305CA', 'DE63B053002302E0', '00000000110305CA', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2592');
INSERT INTO `device` VALUES ('00000000110305CB', '13B8B153002302E0', '00000000110305CB', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '2859');
INSERT INTO `device` VALUES ('00000000110305CC', '3FDDB653002302E0', '00000000110305CC', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3281');
INSERT INTO `device` VALUES ('00000000110305CD', '42EDB653002302E0', '00000000110305CD', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '1892');
INSERT INTO `device` VALUES ('00000000110305CE', 'DCA8B653002302E0', '00000000110305CE', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '1482');
INSERT INTO `device` VALUES ('00000000110305CF', '19A5AF53002302E0', '00000000110305CF', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '250', '1', '1', '1', '2043');
INSERT INTO `device` VALUES ('00000000110305D0', '6964B753002302E0', '00000000110305D0', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '1638');
INSERT INTO `device` VALUES ('00000000110305D1', '6288AF53002302E0', '00000000110305D1', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '4451');
INSERT INTO `device` VALUES ('00000000110305D2', '8974AF53002302E0', '00000000110305D2', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2901');
INSERT INTO `device` VALUES ('00000000110305D3', '65E7AE53002302E0', '00000000110305D3', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, null, '1', '1', '1', '0');
INSERT INTO `device` VALUES ('00000000110305D4', '5515AF53002302E0', '00000000110305D4', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3791');
INSERT INTO `device` VALUES ('00000000110305D5', '0A8BB053002302E0', '00000000110305D5', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3949');
INSERT INTO `device` VALUES ('00000000110305D6', '1CBCB353002302E0', '00000000110305D6', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3072');
INSERT INTO `device` VALUES ('00000000110305D7', '3065B653002302E0', '00000000110305D7', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '4236');
INSERT INTO `device` VALUES ('00000000110305D8', 'D8A2AF53002302E0', '00000000110305D8', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '156', '1', '1', '1', '4373');
INSERT INTO `device` VALUES ('00000000110305D9', '80EFB353002302E0', '00000000110305D9', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '1264');
INSERT INTO `device` VALUES ('00000000110305DA', 'F760B853002302E0', '00000000110305DA', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2832');
INSERT INTO `device` VALUES ('00000000110305DB', '6D50B253002302E0', '00000000110305DB', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '1', '1152');
INSERT INTO `device` VALUES ('00000000110305DC', 'A6F6AE53002302E0', '00000000110305DC', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3084');
INSERT INTO `device` VALUES ('00000000110305DD', '7C08B053002302E0', '00000000110305DD', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '1448');
INSERT INTO `device` VALUES ('00000000110305DE', '9D0AB453002302E0', '00000000110305DE', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '1621');
INSERT INTO `device` VALUES ('00000000110305DF', '500CB353002302E0', '00000000110305DF', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '1', '1191');
INSERT INTO `device` VALUES ('00000000110305E0', '93FFB053002302E0', '00000000110305E0', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '1', '2813');
INSERT INTO `device` VALUES ('00000000110305E1', '94B0BA53002302E0', '00000000110305E1', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '2633');
INSERT INTO `device` VALUES ('00000000110305E2', 'FFB7B953002302E0', '00000000110305E2', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '3752');
INSERT INTO `device` VALUES ('00000000110305E3', 'EE0DB853002302E0', '00000000110305E3', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '2256');
INSERT INTO `device` VALUES ('00000000110305E4', 'B4F4B153002302E0', '00000000110305E4', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '1', '4471');
INSERT INTO `device` VALUES ('00000000110305E5', 'A5F2B253002302E0', '00000000110305E5', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '217', '1', '1', '1', '3195');
INSERT INTO `device` VALUES ('00000000110305E6', '738FB553002302E0', '00000000110305E6', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '217', '1', '1', '1', '2087');
INSERT INTO `device` VALUES ('00000000110305E7', '1D72B053002302E0', '00000000110305E7', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '217', '1', '1', '2', '2352');
INSERT INTO `device` VALUES ('00000000110305E8', 'E7E9B753002302E0', '00000000110305E8', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '224', '1', '1', '2', '2819');
INSERT INTO `device` VALUES ('00000000110305E9', 'F8C7B653002302E0', '00000000110305E9', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '3628');
INSERT INTO `device` VALUES ('00000000110305EA', '95E2B053002302E0', '00000000110305EA', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2933');
INSERT INTO `device` VALUES ('00000000110305EB', 'DCB7B853002302E0', '00000000110305EB', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2677');
INSERT INTO `device` VALUES ('00000000110305EC', '6FFAB053002302E0', '00000000110305EC', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '4154');
INSERT INTO `device` VALUES ('00000000110305ED', 'B894B253002302E0', '00000000110305ED', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '3094');
INSERT INTO `device` VALUES ('00000000110305EE', '02E0B353002302E0', '00000000110305EE', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '2', '3019');
INSERT INTO `device` VALUES ('00000000110305EF', 'F1E1B153002302E0', '00000000110305EF', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '1789');
INSERT INTO `device` VALUES ('00000000110305F0', 'D096B453002302E0', '00000000110305F0', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '2', '627');
INSERT INTO `device` VALUES ('00000000110305F1', 'A785B653002302E0', '00000000110305F1', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '1503');
INSERT INTO `device` VALUES ('00000000110305F2', '058FB253002302E0', '00000000110305F2', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2909');
INSERT INTO `device` VALUES ('00000000110305F3', 'F7C3B453002302E0', '00000000110305F3', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2494');
INSERT INTO `device` VALUES ('00000000110305F4', 'EB89B453002302E0', '00000000110305F4', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '1680');
INSERT INTO `device` VALUES ('00000000110305F5', '1E29B453002302E0', '00000000110305F5', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '1914');
INSERT INTO `device` VALUES ('00000000110305F6', '31ABB553002302E0', '00000000110305F6', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2668');
INSERT INTO `device` VALUES ('00000000110305F7', '22BBB653002302E0', '00000000110305F7', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '2962');
INSERT INTO `device` VALUES ('00000000110305F8', '17D2B553002302E0', '00000000110305F8', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '1949');
INSERT INTO `device` VALUES ('00000000110305F9', 'B683B553002302E0', '00000000110305F9', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2654');
INSERT INTO `device` VALUES ('00000000110305FA', 'EDCAB553002302E0', '00000000110305FA', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2988');
INSERT INTO `device` VALUES ('00000000110305FB', 'A29DB353002302E0', '00000000110305FB', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2915');
INSERT INTO `device` VALUES ('00000000110305FC', '0F2FB753002302E0', '00000000110305FC', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2675');
INSERT INTO `device` VALUES ('00000000110305FD', 'A9CCB053002302E0', '00000000110305FD', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '2', '3002');
INSERT INTO `device` VALUES ('00000000110305FE', 'C5DAB853002302E0', '00000000110305FE', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2810');
INSERT INTO `device` VALUES ('00000000110305FF', 'F957B453002302E0', '00000000110305FF', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '3566');
INSERT INTO `device` VALUES ('0000000011030600', 'E2CEB753002302E0', '0000000011030600', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2912');
INSERT INTO `device` VALUES ('0000000011030601', 'CD53B853002302E0', '0000000011030601', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2165');
INSERT INTO `device` VALUES ('0000000011030602', '1208B853002302E0', '0000000011030602', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2386');
INSERT INTO `device` VALUES ('0000000011030603', '3EEEB853002302E0', '0000000011030603', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '4536');
INSERT INTO `device` VALUES ('0000000011030604', '9E93B853002302E0', '0000000011030604', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '2263');
INSERT INTO `device` VALUES ('0000000011030605', 'B346B653002302E0', '0000000011030605', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '3190');
INSERT INTO `device` VALUES ('0000000011030606', 'AF0CB653002302E0', '0000000011030606', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '155', '1', '1', '2', '1371');
INSERT INTO `device` VALUES ('0000000011030607', '7A15B053002302E0', '0000000011030607', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2533');
INSERT INTO `device` VALUES ('0000000011030608', 'BA5FB453002302E0', '0000000011030608', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2517');
INSERT INTO `device` VALUES ('0000000011030609', '1927B153002302E0', '0000000011030609', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '7211');
INSERT INTO `device` VALUES ('000000001103060A', '7C69B453002302E0', '000000001103060A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '3123');
INSERT INTO `device` VALUES ('000000001103060B', '4F1DB753002302E0', '000000001103060B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '3078');
INSERT INTO `device` VALUES ('000000001103060C', '8A4FB653002302E0', '000000001103060C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '2997');
INSERT INTO `device` VALUES ('000000001103060D', '8703B553002302E0', '000000001103060D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '2', '5905');
INSERT INTO `device` VALUES ('000000001103060E', '20ADB653002302E0', '000000001103060E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '4274');
INSERT INTO `device` VALUES ('000000001103060F', 'DD9BB853002302E0', '000000001103060F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '3214');
INSERT INTO `device` VALUES ('0000000011030610', '1294B153002302E0', '0000000011030610', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '3443');
INSERT INTO `device` VALUES ('0000000011030611', 'CD2DB253002302E0', '0000000011030611', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2497');
INSERT INTO `device` VALUES ('0000000011030612', '2909AF53002302E0', '0000000011030612', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '3803');
INSERT INTO `device` VALUES ('0000000011030613', 'AC57B253002302E0', '0000000011030613', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '3051');
INSERT INTO `device` VALUES ('0000000011030614', '5F8AAF53002302E0', '0000000011030614', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2323');
INSERT INTO `device` VALUES ('0000000011030615', 'E0C7B953002302E0', '0000000011030615', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '4211');
INSERT INTO `device` VALUES ('0000000011030616', '74DFB153002302E0', '0000000011030616', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '4510');
INSERT INTO `device` VALUES ('0000000011030617', '103EB353002302E0', '0000000011030617', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2139');
INSERT INTO `device` VALUES ('0000000011030618', '6848B753002302E0', '0000000011030618', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '1996');
INSERT INTO `device` VALUES ('0000000011030619', '06CBB853002302E0', '0000000011030619', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2182');
INSERT INTO `device` VALUES ('000000001103061A', '3B6AB453002302E0', '000000001103061A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '2', '3848');
INSERT INTO `device` VALUES ('000000001103061B', '1387B453002302E0', '000000001103061B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '3009');
INSERT INTO `device` VALUES ('000000001103061C', '23C9B753002302E0', '000000001103061C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '4030');
INSERT INTO `device` VALUES ('000000001103061D', '916AB753002302E0', '000000001103061D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '2', '2174');
INSERT INTO `device` VALUES ('000000001103061E', '7D5ABA53002302E0', '000000001103061E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '2', '4243');
INSERT INTO `device` VALUES ('000000001103061F', '5C8EB353002302E0', '000000001103061F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '1260');
INSERT INTO `device` VALUES ('0000000011030620', '9520B853002302E0', '0000000011030620', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '2', '2363');
INSERT INTO `device` VALUES ('0000000011030621', '2C30B853002302E0', '0000000011030621', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2119');
INSERT INTO `device` VALUES ('0000000011030622', '48D1BA53002302E0', '0000000011030622', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2655');
INSERT INTO `device` VALUES ('0000000011030623', '2D1CB853002302E0', '0000000011030623', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2365');
INSERT INTO `device` VALUES ('0000000011030624', '4582B753002302E0', '0000000011030624', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '2923');
INSERT INTO `device` VALUES ('0000000011030625', 'D49DB453002302E0', '0000000011030625', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2164');
INSERT INTO `device` VALUES ('0000000011030626', 'DB99B653002302E0', '0000000011030626', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '5304');
INSERT INTO `device` VALUES ('0000000011030627', 'F6B1B553002302E0', '0000000011030627', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '6165');
INSERT INTO `device` VALUES ('0000000011030628', '3850B453002302E0', '0000000011030628', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '1891');
INSERT INTO `device` VALUES ('0000000011030629', 'B022B753002302E0', '0000000011030629', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2180');
INSERT INTO `device` VALUES ('000000001103062A', '88E5B453002302E0', '000000001103062A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2299');
INSERT INTO `device` VALUES ('000000001103062B', '8ACCB153002302E0', '000000001103062B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '1984');
INSERT INTO `device` VALUES ('000000001103062C', '2BBDBA53002302E0', '000000001103062C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '3525');
INSERT INTO `device` VALUES ('000000001103062D', '35FEB453002302E0', '000000001103062D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2111');
INSERT INTO `device` VALUES ('000000001103062E', '88DAB153002302E0', '000000001103062E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '2551');
INSERT INTO `device` VALUES ('000000001103062F', '9BF4AE53002302E0', '000000001103062F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2711');
INSERT INTO `device` VALUES ('0000000011030630', 'C65CBA53002302E0', '0000000011030630', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '2', '6163');
INSERT INTO `device` VALUES ('0000000011030631', '6E4AB953002302E0', '0000000011030631', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '3333');
INSERT INTO `device` VALUES ('0000000011030632', 'AD7BB253002302E0', '0000000011030632', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '1287');
INSERT INTO `device` VALUES ('0000000011030633', '1D4DB553002302E0', '0000000011030633', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '3481');
INSERT INTO `device` VALUES ('0000000011030634', '40FBB653002302E0', '0000000011030634', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '2386');
INSERT INTO `device` VALUES ('0000000011030635', '51FDB553002302E0', '0000000011030635', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '4046');
INSERT INTO `device` VALUES ('0000000011030636', '495EB653002302E0', '0000000011030636', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '3321');
INSERT INTO `device` VALUES ('0000000011030637', 'F47AB353002302E0', '0000000011030637', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '3561');
INSERT INTO `device` VALUES ('0000000011030638', '9832BA53002302E0', '0000000011030638', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '2', '3050');
INSERT INTO `device` VALUES ('0000000011030639', '07A6B753002302E0', '0000000011030639', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2517');
INSERT INTO `device` VALUES ('000000001103063A', '20B2B853002302E0', '000000001103063A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '5178');
INSERT INTO `device` VALUES ('000000001103063B', '8693B753002302E0', '000000001103063B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '3082');
INSERT INTO `device` VALUES ('000000001103063C', '4412B553002302E0', '000000001103063C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '3708');
INSERT INTO `device` VALUES ('000000001103063D', 'ED17B353002302E0', '000000001103063D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2875');
INSERT INTO `device` VALUES ('000000001103063E', 'C8D7B453002302E0', '000000001103063E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '2', '2906');
INSERT INTO `device` VALUES ('000000001103063F', 'A615B453002302E0', '000000001103063F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '2', '2606');
INSERT INTO `device` VALUES ('0000000011030640', 'F8D8B853002302E0', '0000000011030640', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '2', '3518');
INSERT INTO `device` VALUES ('0000000011030641', '9901B453002302E0', '0000000011030641', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '3', '2001');
INSERT INTO `device` VALUES ('0000000011030642', '3B55B153002302E0', '0000000011030642', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '217', '1', '1', '3', '2523');
INSERT INTO `device` VALUES ('0000000011030643', 'F8C6AF53002302E0', '0000000011030643', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '3', '5578');
INSERT INTO `device` VALUES ('0000000011030644', '4FA1B553002302E0', '0000000011030644', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3276');
INSERT INTO `device` VALUES ('0000000011030645', '8053B153002302E0', '0000000011030645', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3713');
INSERT INTO `device` VALUES ('0000000011030646', '46E7AF53002302E0', '0000000011030646', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '3', '1408');
INSERT INTO `device` VALUES ('0000000011030647', 'D262B753002302E0', '0000000011030647', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '3', '2725');
INSERT INTO `device` VALUES ('0000000011030648', '6E0AAF53002302E0', '0000000011030648', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '3', '3033');
INSERT INTO `device` VALUES ('0000000011030649', '4769BA53002302E0', '0000000011030649', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3284');
INSERT INTO `device` VALUES ('000000001103064A', 'C295B253002302E0', '000000001103064A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '3', '2662');
INSERT INTO `device` VALUES ('000000001103064B', 'BF26B553002302E0', '000000001103064B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '250', '1', '1', '3', '2178');
INSERT INTO `device` VALUES ('000000001103064C', '7759B353002302E0', '000000001103064C', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '217', '1', '1', '3', '3068');
INSERT INTO `device` VALUES ('000000001103064D', '2375B553002302E0', '000000001103064D', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '160', '1', '1', '3', '1475');
INSERT INTO `device` VALUES ('000000001103064E', '3E2CB053002302E0', '000000001103064E', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '217', '1', '1', '3', '1926');
INSERT INTO `device` VALUES ('000000001103064F', '6E34B353002302E0', '000000001103064F', null, null, '2019-01-21 09:41:59', 'kickoff2019', null, '217', '1', '1', '3', '2267');
INSERT INTO `device` VALUES ('0000000011030650', 'DF70B553002302E0', '0000000011030650', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3991');
INSERT INTO `device` VALUES ('0000000011030651', '42D2B353002302E0', '0000000011030651', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, null, '1', '1', '3', '0');
INSERT INTO `device` VALUES ('0000000011030652', 'D90CB153002302E0', '0000000011030652', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3512');
INSERT INTO `device` VALUES ('0000000011030653', '84C4B853002302E0', '0000000011030653', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3138');
INSERT INTO `device` VALUES ('0000000011030654', '7779B853002302E0', '0000000011030654', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2876');
INSERT INTO `device` VALUES ('0000000011030655', '9231B353002302E0', '0000000011030655', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '3', '4332');
INSERT INTO `device` VALUES ('0000000011030656', 'F9EBB653002302E0', '0000000011030656', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2442');
INSERT INTO `device` VALUES ('0000000011030657', '515EB953002302E0', '0000000011030657', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3227');
INSERT INTO `device` VALUES ('0000000011030658', 'D32FB353002302E0', '0000000011030658', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3074');
INSERT INTO `device` VALUES ('0000000011030659', '437DB453002302E0', '0000000011030659', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3935');
INSERT INTO `device` VALUES ('000000001103065A', '7EFCB353002302E0', '000000001103065A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '3', '2580');
INSERT INTO `device` VALUES ('000000001103065B', '35A0B553002302E0', '000000001103065B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '2731');
INSERT INTO `device` VALUES ('000000001103065C', 'BA60B153002302E0', '000000001103065C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3607');
INSERT INTO `device` VALUES ('000000001103065D', 'B234B753002302E0', '000000001103065D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2732');
INSERT INTO `device` VALUES ('000000001103065E', '3117B753002302E0', '000000001103065E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '3674');
INSERT INTO `device` VALUES ('000000001103065F', '3EAFB753002302E0', '000000001103065F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '3106');
INSERT INTO `device` VALUES ('0000000011030660', 'AD99B153002302E0', '0000000011030660', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '3099');
INSERT INTO `device` VALUES ('0000000011030661', '4EB2B053002302E0', '0000000011030661', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '1111');
INSERT INTO `device` VALUES ('0000000011030662', '7BBAB753002302E0', '0000000011030662', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '156', '1', '1', '3', '2566');
INSERT INTO `device` VALUES ('0000000011030663', 'C59BB753002302E0', '0000000011030663', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3057');
INSERT INTO `device` VALUES ('0000000011030664', 'A911B653002302E0', '0000000011030664', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '3158');
INSERT INTO `device` VALUES ('0000000011030665', '74BEB553002302E0', '0000000011030665', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2780');
INSERT INTO `device` VALUES ('0000000011030666', 'D7C6B053002302E0', '0000000011030666', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '2161');
INSERT INTO `device` VALUES ('0000000011030667', '864EB153002302E0', '0000000011030667', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '3', '1491');
INSERT INTO `device` VALUES ('0000000011030668', '68CBB053002302E0', '0000000011030668', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3931');
INSERT INTO `device` VALUES ('0000000011030669', '2DDEB053002302E0', '0000000011030669', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '2087');
INSERT INTO `device` VALUES ('000000001103066A', '6FC5B553002302E0', '000000001103066A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '155', '1', '1', '3', '3315');
INSERT INTO `device` VALUES ('000000001103066B', 'EA18AF53002302E0', '000000001103066B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '1627');
INSERT INTO `device` VALUES ('000000001103066C', '09CFBA53002302E0', '000000001103066C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '3600');
INSERT INTO `device` VALUES ('000000001103066D', '0AEAB453002302E0', '000000001103066D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '2496');
INSERT INTO `device` VALUES ('000000001103066E', '8439B553002302E0', '000000001103066E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '1635');
INSERT INTO `device` VALUES ('000000001103066F', '3CE7B653002302E0', '000000001103066F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '156', '1', '1', '3', '1647');
INSERT INTO `device` VALUES ('0000000011030670', 'FD02B553002302E0', '0000000011030670', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '4014');
INSERT INTO `device` VALUES ('0000000011030671', '8F36B753002302E0', '0000000011030671', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2967');
INSERT INTO `device` VALUES ('0000000011030672', '2425B153002302E0', '0000000011030672', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '3', '2615');
INSERT INTO `device` VALUES ('0000000011030673', '7D45B453002302E0', '0000000011030673', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2834');
INSERT INTO `device` VALUES ('0000000011030674', 'EBD7B553002302E0', '0000000011030674', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '2377');
INSERT INTO `device` VALUES ('0000000011030675', '552BB353002302E0', '0000000011030675', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3329');
INSERT INTO `device` VALUES ('0000000011030676', 'C216B553002302E0', '0000000011030676', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3756');
INSERT INTO `device` VALUES ('0000000011030677', 'CBB3B553002302E0', '0000000011030677', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3154');
INSERT INTO `device` VALUES ('0000000011030678', 'D02AB653002302E0', '0000000011030678', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '3103');
INSERT INTO `device` VALUES ('0000000011030679', '6A01AF53002302E0', '0000000011030679', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '250', '1', '1', '3', '3686');
INSERT INTO `device` VALUES ('000000001103067A', '1000AF53002302E0', '000000001103067A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2609');
INSERT INTO `device` VALUES ('000000001103067B', '24F9AE53002302E0', '000000001103067B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2869');
INSERT INTO `device` VALUES ('000000001103067C', '82A7B253002302E0', '000000001103067C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2753');
INSERT INTO `device` VALUES ('000000001103067D', 'F968B153002302E0', '000000001103067D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '191', '1', '1', '3', '1580');
INSERT INTO `device` VALUES ('000000001103067E', '47ABB253002302E0', '000000001103067E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2479');
INSERT INTO `device` VALUES ('000000001103067F', '4E0EB253002302E0', '000000001103067F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3154');
INSERT INTO `device` VALUES ('0000000011030680', '4A5BB353002302E0', '0000000011030680', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '3', '1748');
INSERT INTO `device` VALUES ('0000000011030681', '36FBB153002302E0', '0000000011030681', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '161', '1', '1', '3', '4349');
INSERT INTO `device` VALUES ('0000000011030682', '764AB653002302E0', '0000000011030682', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '245', '1', '1', '3', '3454');
INSERT INTO `device` VALUES ('0000000011030683', 'FFC9B353002302E0', '0000000011030683', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, null, '1', '1', '3', '0');
INSERT INTO `device` VALUES ('0000000011030684', 'F87BB453002302E0', '0000000011030684', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '1981');
INSERT INTO `device` VALUES ('0000000011030685', 'B7AFB553002302E0', '0000000011030685', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '3290');
INSERT INTO `device` VALUES ('0000000011030686', '6F9BB453002302E0', '0000000011030686', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '3244');
INSERT INTO `device` VALUES ('0000000011030687', '25B5B353002302E0', '0000000011030687', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '1802');
INSERT INTO `device` VALUES ('0000000011030688', '0FF2B153002302E0', '0000000011030688', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '5009');
INSERT INTO `device` VALUES ('0000000011030689', '8D9CB553002302E0', '0000000011030689', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '228', '1', '1', '3', '2322');
INSERT INTO `device` VALUES ('000000001103068A', 'A6B6B853002302E0', '000000001103068A', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '3', '2316');
INSERT INTO `device` VALUES ('000000001103068B', 'B7F1B453002302E0', '000000001103068B', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '3', '2483');
INSERT INTO `device` VALUES ('000000001103068C', '1C5EB053002302E0', '000000001103068C', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, null, '1', '1', '3', '0');
INSERT INTO `device` VALUES ('000000001103068D', 'DEBFAF53002302E0', '000000001103068D', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '5039');
INSERT INTO `device` VALUES ('000000001103068E', 'E80EAF53002302E0', '000000001103068E', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '1676');
INSERT INTO `device` VALUES ('000000001103068F', '1527AF53002302E0', '000000001103068F', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2522');
INSERT INTO `device` VALUES ('0000000011030690', 'F010B753002302E0', '0000000011030690', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '3', '2898');
INSERT INTO `device` VALUES ('0000000011030691', 'AE21AF53002302E0', '0000000011030691', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '217', '1', '1', '5', '4945');
INSERT INTO `device` VALUES ('0000000011030692', 'F9B5B753002302E0', '0000000011030692', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '251', '1', '1', '5', '1180');
INSERT INTO `device` VALUES ('0000000011030693', 'F64CB853002302E0', '0000000011030693', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '5', '3969');
INSERT INTO `device` VALUES ('0000000011030694', 'AE7EB753002302E0', '0000000011030694', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '224', '1', '1', '5', '5310');
INSERT INTO `device` VALUES ('0000000011030695', 'A992B153002302E0', '0000000011030695', null, null, '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '5', '3423');
INSERT INTO `device` VALUES ('0000000011030696', '000000000000000x', '0000000011030696', 'anquanmao', '2018-12-21 16:00:09', '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '0');
INSERT INTO `device` VALUES ('0000000011030697', '000000000000000x', '0000000011030697', 'anquanmao', '2018-12-21 16:00:09', '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '0');
INSERT INTO `device` VALUES ('0000000011030698', '000000000000000x', '0000000011030698', 'anquanmao', '2018-12-21 16:00:09', '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '0');
INSERT INTO `device` VALUES ('0000000011030699', '000000000000000x', '0000000011030699', 'anquanmao', '2018-12-21 16:00:09', '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '0');
INSERT INTO `device` VALUES ('000000001103069A', '000000000000000x', '000000001103069A', 'anquanmao', '2018-12-21 16:00:09', '2019-01-21 09:42:00', 'kickoff2019', null, '160', '1', '1', '1', '0');

-- ----------------------------
-- Table structure for device-bak
-- ----------------------------
DROP TABLE IF EXISTS `device-bak`;
CREATE TABLE `device-bak` (
  `id` varchar(50) NOT NULL COMMENT 'ID',
  `rfid` varchar(255) DEFAULT NULL,
  `dev_id` varchar(50) NOT NULL COMMENT '设备EUI,devId',
  `alias` varchar(50) DEFAULT NULL COMMENT '设备别名',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_at` datetime DEFAULT NULL COMMENT '更新时间',
  `indoor_map_id` varchar(100) NOT NULL COMMENT '所属楼层',
  `major` int(255) DEFAULT NULL COMMENT '最近信标major',
  `minor` int(255) DEFAULT NULL COMMENT '最近信标minor',
  `is_offline` int(11) DEFAULT NULL COMMENT '1离线，2在线',
  `is_move` int(11) DEFAULT NULL COMMENT '设备是否移动，1是0否',
  `device_color` varchar(255) DEFAULT NULL COMMENT '卡的颜色,组别,就是user_group_id',
  `step_counter` int(11) DEFAULT NULL COMMENT '计步器',
  PRIMARY KEY (`dev_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设备';

-- ----------------------------
-- Records of device-bak
-- ----------------------------
INSERT INTO `device-bak` VALUES ('004A770211030565', 'E0022301DE1600A2', '004A770211030565', '', '2018-12-21 16:00:09', '2019-01-10 16:15:41', 'kickoff2019', null, '155', '1', '1', '1', '53');
INSERT INTO `device-bak` VALUES ('004A770211030566', '', '004A770211030566', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '156', '0', '1', '1', '43');
INSERT INTO `device-bak` VALUES ('004A770211030567', '', '004A770211030567', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '156', '0', '1', '1', '46');
INSERT INTO `device-bak` VALUES ('004A770211030568', '', '004A770211030568', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '23');
INSERT INTO `device-bak` VALUES ('004A770211030569', '', '004A770211030569', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '6');
INSERT INTO `device-bak` VALUES ('004A77021103056A', '', '004A77021103056A', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '35');
INSERT INTO `device-bak` VALUES ('004A77021103056B', '', '004A77021103056B', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '19');
INSERT INTO `device-bak` VALUES ('004A77021103056C', '', '004A77021103056C', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '30');
INSERT INTO `device-bak` VALUES ('004A77021103056D', '', '004A77021103056D', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '20');
INSERT INTO `device-bak` VALUES ('004A77021103056E', '', '004A77021103056E', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '5');
INSERT INTO `device-bak` VALUES ('004A77021103056F', '', '004A77021103056F', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '7');
INSERT INTO `device-bak` VALUES ('004A770211030570', '', '004A770211030570', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '98');
INSERT INTO `device-bak` VALUES ('004A770211030571', '', '004A770211030571', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '30');
INSERT INTO `device-bak` VALUES ('004A770211030572', '', '004A770211030572', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '31');
INSERT INTO `device-bak` VALUES ('004A770211030573', '', '004A770211030573', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '33');
INSERT INTO `device-bak` VALUES ('004A770211030574', '', '004A770211030574', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '200');
INSERT INTO `device-bak` VALUES ('004A770211030575', '', '004A770211030575', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '231');
INSERT INTO `device-bak` VALUES ('004A770211030576', '', '004A770211030576', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '64');
INSERT INTO `device-bak` VALUES ('004A770211030577', '', '004A770211030577', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '79');
INSERT INTO `device-bak` VALUES ('004A770211030578', '', '004A770211030578', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '50');
INSERT INTO `device-bak` VALUES ('004A770211030579', '', '004A770211030579', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '944');
INSERT INTO `device-bak` VALUES ('004A77021103057A', '', '004A77021103057A', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '102');
INSERT INTO `device-bak` VALUES ('004A77021103057B', '', '004A77021103057B', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '68');
INSERT INTO `device-bak` VALUES ('004A77021103057C', '', '004A77021103057C', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '65');
INSERT INTO `device-bak` VALUES ('004A77021103057D', '', '004A77021103057D', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '65');
INSERT INTO `device-bak` VALUES ('004A77021103057E', '', '004A77021103057E', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '117');
INSERT INTO `device-bak` VALUES ('004A77021103057F', '', '004A77021103057F', '', '2018-12-21 16:00:09', '2019-01-10 14:09:10', 'kickoff2019', '14', '155', '0', '1', '1', '14');
INSERT INTO `device-bak` VALUES ('004A770211030580', '', '004A770211030580', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '28');
INSERT INTO `device-bak` VALUES ('004A770211030581', '', '004A770211030581', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '529');
INSERT INTO `device-bak` VALUES ('004A770211030582', '', '004A770211030582', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '155', '0', '1', '1', '24');
INSERT INTO `device-bak` VALUES ('004A770211030583', '', '004A770211030583', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '228', '0', '1', '1', '26');
INSERT INTO `device-bak` VALUES ('004A770211030584', '', '004A770211030584', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '228', '0', '1', '1', '7');
INSERT INTO `device-bak` VALUES ('004A770211030585', '', '004A770211030585', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '228', '0', '1', '1', '67');
INSERT INTO `device-bak` VALUES ('004A770211030586', '', '004A770211030586', '', '2018-12-21 16:00:09', '2019-01-10 17:10:59', 'kickoff2019', '14', '228', '0', '1', '1', '93');
INSERT INTO `device-bak` VALUES ('004A770211030587', '', '004A770211030587', '', '2018-12-21 16:00:09', '2019-01-09 17:05:59', 'kickoff2019', '14', '228', '0', '1', '1', '74');
INSERT INTO `device-bak` VALUES ('004A770211030588', '', '004A770211030588', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '228', '0', '1', '1', '24');
INSERT INTO `device-bak` VALUES ('004A770211030589', '', '004A770211030589', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '228', '0', '1', '1', null);
INSERT INTO `device-bak` VALUES ('004A77021103058A', '', '004A77021103058A', '', '2018-12-21 16:00:09', '2019-01-09 17:03:36', 'kickoff2019', '14', '228', '0', '1', '1', '10');
INSERT INTO `device-bak` VALUES ('004A77021103058B', '', '004A77021103058B', '', '2018-12-21 16:00:09', '2019-01-09 17:07:32', 'kickoff2019', '14', '228', '0', '1', '1', '82');
INSERT INTO `device-bak` VALUES ('004A77021103058C', '', '004A77021103058C', '', '2018-12-21 16:00:09', '2019-01-09 17:12:18', 'kickoff2019', '14', '228', '0', '1', '1', '122');
INSERT INTO `device-bak` VALUES ('004A77021103058D', '', '004A77021103058D', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '228', '0', '1', '1', null);
INSERT INTO `device-bak` VALUES ('004A77021103058E', '', '004A77021103058E', '', '2018-12-21 16:00:09', '2019-01-09 17:10:09', 'kickoff2019', '14', '228', '0', '1', '1', '74');
INSERT INTO `device-bak` VALUES ('004A77021103058F', '', '004A77021103058F', '', '2018-12-21 16:00:09', '2019-01-09 17:06:17', 'kickoff2019', '14', '228', '0', '1', '1', '16');
INSERT INTO `device-bak` VALUES ('004A770211030590', '', '004A770211030590', '', '2018-12-21 16:00:09', '2019-01-09 17:01:49', 'kickoff2019', '14', '228', '0', '1', '1', '52');
INSERT INTO `device-bak` VALUES ('004A770211030591', '', '004A770211030591', '', '2018-12-21 16:00:09', '2019-01-09 17:01:41', 'kickoff2019', '14', '228', '0', '1', '1', '61');
INSERT INTO `device-bak` VALUES ('004A770211030592', '', '004A770211030592', '', '2018-12-21 16:00:09', '2019-01-09 16:38:19', 'kickoff2019', '14', '228', '0', '1', '1', '66');
INSERT INTO `device-bak` VALUES ('004A770211030593', '', '004A770211030593', '', '2018-12-21 16:00:09', '2019-01-09 17:10:20', 'kickoff2019', '14', '228', '0', '1', '1', '13');
INSERT INTO `device-bak` VALUES ('004A770211030594', '', '004A770211030594', '', '2018-12-21 16:00:09', '2019-01-09 17:10:52', 'kickoff2019', '14', '228', '0', '1', '1', '131');
INSERT INTO `device-bak` VALUES ('004A770211030595', '', '004A770211030595', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '228', '0', '1', '1', null);
INSERT INTO `device-bak` VALUES ('004A770211030596', '', '004A770211030596', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '228', '0', '1', '1', '26');
INSERT INTO `device-bak` VALUES ('004A770211030597', '', '004A770211030597', '', '2018-12-21 16:00:09', '2019-01-09 17:04:17', 'kickoff2019', '14', '228', '0', '1', '1', '34');
INSERT INTO `device-bak` VALUES ('004A770211030598', '', '004A770211030598', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '228', '0', '1', '1', null);
INSERT INTO `device-bak` VALUES ('004A770211030599', '', '004A770211030599', '', '2018-12-21 16:00:09', '2019-01-09 17:04:54', 'kickoff2019', '14', '228', '0', '1', '1', '5');
INSERT INTO `device-bak` VALUES ('004A77021103059A', '', '004A77021103059A', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '228', '0', '1', '1', '7');
INSERT INTO `device-bak` VALUES ('004A77021103059B', '', '004A77021103059B', '', '2018-12-21 16:00:09', '2019-01-09 17:06:37', 'kickoff2019', '14', '228', '0', '1', '1', '30');
INSERT INTO `device-bak` VALUES ('004A77021103059C', '', '004A77021103059C', '', '2018-12-21 16:00:09', '2019-01-09 17:13:00', 'kickoff2019', '14', '228', '0', '1', '1', '50');
INSERT INTO `device-bak` VALUES ('004A77021103059D', '', '004A77021103059D', '', '2018-12-21 16:00:09', '2019-01-09 17:11:53', 'kickoff2019', '14', '228', '0', '1', '1', '38');
INSERT INTO `device-bak` VALUES ('004A77021103059E', '', '004A77021103059E', '', '2018-12-21 16:00:09', '2019-01-09 17:13:30', 'kickoff2019', '14', '228', '0', '1', '1', '84');
INSERT INTO `device-bak` VALUES ('004A77021103059F', '', '004A77021103059F', '', '2018-12-21 16:00:09', '2019-01-09 16:36:25', 'kickoff2019', '14', '228', '0', '1', '1', '87');
INSERT INTO `device-bak` VALUES ('004A7702110305A0', '', '004A7702110305A0', '', '2018-12-21 16:00:09', '2019-01-09 17:09:10', 'kickoff2019', '14', '228', '0', '1', '1', '56');
INSERT INTO `device-bak` VALUES ('004A7702110305A1', '', '004A7702110305A1', '', '2018-12-21 16:00:09', '2019-01-09 17:08:08', 'kickoff2019', '14', '152', '0', '1', '1', '55');
INSERT INTO `device-bak` VALUES ('004A7702110305A2', '', '004A7702110305A2', '', '2018-12-21 16:00:09', '2019-01-09 17:09:36', 'kickoff2019', '14', '152', '0', '1', '1', '417');
INSERT INTO `device-bak` VALUES ('004A7702110305A3', '', '004A7702110305A3', '', '2018-12-21 16:00:09', '2019-01-09 17:12:06', 'kickoff2019', '14', '152', '0', '1', '1', '63');
INSERT INTO `device-bak` VALUES ('004A7702110305A4', '', '004A7702110305A4', '', '2018-12-21 16:00:09', '2019-01-09 17:04:39', 'kickoff2019', '14', '152', '0', '1', '1', '5');
INSERT INTO `device-bak` VALUES ('004A7702110305A5', '', '004A7702110305A5', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '152', '0', '1', '1', null);
INSERT INTO `device-bak` VALUES ('004A7702110305A6', '', '004A7702110305A6', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '152', '0', '1', '1', '42');
INSERT INTO `device-bak` VALUES ('004A7702110305A7', '', '004A7702110305A7', '', '2018-12-21 16:00:09', '2019-01-09 17:05:10', 'kickoff2019', '14', '152', '0', '1', '1', '67');
INSERT INTO `device-bak` VALUES ('004A7702110305A8', '', '004A7702110305A8', '', '2018-12-21 16:00:09', '2019-01-09 17:06:13', 'kickoff2019', '14', '152', '0', '1', '1', '71');
INSERT INTO `device-bak` VALUES ('004A7702110305A9', '', '004A7702110305A9', '', '2018-12-21 16:00:09', '2019-01-09 17:11:29', 'kickoff2019', '14', '152', '0', '1', '1', '59');
INSERT INTO `device-bak` VALUES ('004A7702110305AA', '', '004A7702110305AA', '', '2018-12-21 16:00:09', '2019-01-09 17:03:23', 'kickoff2019', '14', '152', '0', '1', '1', '45');
INSERT INTO `device-bak` VALUES ('004A7702110305AB', '', '004A7702110305AB', '', '2018-12-21 16:00:09', '2019-01-09 17:09:38', 'kickoff2019', '14', '152', '0', '1', '1', '54');
INSERT INTO `device-bak` VALUES ('004A7702110305AC', '', '004A7702110305AC', '', '2018-12-21 16:00:09', '2019-01-10 16:53:16', 'kickoff2019', '14', '152', '0', '1', '1', '217');
INSERT INTO `device-bak` VALUES ('004A7702110305AD', '', '004A7702110305AD', '', '2018-12-21 16:00:09', '2019-01-09 17:12:11', 'kickoff2019', '14', '152', '0', '1', '1', '108');
INSERT INTO `device-bak` VALUES ('004A7702110305AE', '', '004A7702110305AE', '', '2018-12-21 16:00:09', '2019-01-09 17:10:36', 'kickoff2019', '14', '152', '0', '1', '1', '194');
INSERT INTO `device-bak` VALUES ('004A7702110305AF', '', '004A7702110305AF', '', '2018-12-21 16:00:09', '2019-01-09 17:04:54', 'kickoff2019', '14', '152', '0', '1', '1', '145');
INSERT INTO `device-bak` VALUES ('004A7702110305B0', '', '004A7702110305B0', '', '2018-12-21 16:00:09', '2019-01-09 17:05:03', 'kickoff2019', '14', '152', '0', '1', '1', '28');
INSERT INTO `device-bak` VALUES ('004A7702110305B1', '', '004A7702110305B1', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '152', '0', '1', '1', '66');
INSERT INTO `device-bak` VALUES ('004A7702110305B2', '', '004A7702110305B2', '', '2018-12-21 16:00:09', '2019-01-09 16:48:58', 'kickoff2019', '14', '152', '0', '1', '1', '62');
INSERT INTO `device-bak` VALUES ('004A7702110305B3', '', '004A7702110305B3', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '152', '0', '1', '1', null);
INSERT INTO `device-bak` VALUES ('004A7702110305B4', '', '004A7702110305B4', '', '2018-12-21 16:00:09', '2019-01-09 17:11:53', 'kickoff2019', '14', '152', '0', '1', '1', '63');
INSERT INTO `device-bak` VALUES ('004A7702110305B5', '', '004A7702110305B5', '', '2018-12-21 16:00:09', '2019-01-09 17:11:50', 'kickoff2019', '14', '152', '0', '1', '1', '42');
INSERT INTO `device-bak` VALUES ('004A7702110305B6', '', '004A7702110305B6', '', '2018-12-21 16:00:09', '2019-01-09 17:10:00', 'kickoff2019', '14', '152', '0', '1', '1', '51');
INSERT INTO `device-bak` VALUES ('004A7702110305B7', '', '004A7702110305B7', '', '2018-12-21 16:00:09', '2019-01-10 16:35:22', 'kickoff2019', '14', '152', '0', '0', '1', '39');
INSERT INTO `device-bak` VALUES ('004A7702110305B8', '', '004A7702110305B8', '', '2018-12-21 16:00:09', '2019-01-09 17:05:05', 'kickoff2019', '14', '152', '0', '1', '1', '250');
INSERT INTO `device-bak` VALUES ('004A7702110305B9', '', '004A7702110305B9', '', '2018-12-21 16:00:09', '2019-01-09 17:10:14', 'kickoff2019', '14', '152', '0', '1', '1', '278');
INSERT INTO `device-bak` VALUES ('004A7702110305BA', '', '004A7702110305BA', '', '2018-12-21 16:00:09', '2019-01-09 17:13:30', 'kickoff2019', '14', '152', '0', '1', '1', '204');
INSERT INTO `device-bak` VALUES ('004A7702110305BB', '', '004A7702110305BB', '', '2018-12-21 16:00:09', '2019-01-09 17:10:37', 'kickoff2019', '14', '152', '0', '1', '1', '202');
INSERT INTO `device-bak` VALUES ('004A7702110305BC', '', '004A7702110305BC', '', '2018-12-21 16:00:09', '2019-01-09 17:11:55', 'kickoff2019', '14', '152', '0', '1', '1', '53');
INSERT INTO `device-bak` VALUES ('004A7702110305BD', '', '004A7702110305BD', '', '2018-12-21 16:00:09', '2019-01-09 17:11:45', 'kickoff2019', '14', '152', '0', '1', '1', '22');
INSERT INTO `device-bak` VALUES ('004A7702110305BE', '', '004A7702110305BE', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '152', '0', '1', '1', null);
INSERT INTO `device-bak` VALUES ('004A7702110305BF', '', '004A7702110305BF', '', '2018-12-21 16:00:09', '2019-01-09 17:12:59', 'kickoff2019', '14', '155', '0', '1', '1', '83');
INSERT INTO `device-bak` VALUES ('004A7702110305C0', '', '004A7702110305C0', '', '2018-12-21 16:00:09', '2019-01-09 17:12:24', 'kickoff2019', '14', '155', '0', '1', '1', '58');
INSERT INTO `device-bak` VALUES ('004A7702110305C1', '', '004A7702110305C1', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '1', null);
INSERT INTO `device-bak` VALUES ('004A7702110305C2', '', '004A7702110305C2', '', '2018-12-21 16:00:09', '2019-01-09 17:09:58', 'kickoff2019', '14', '155', '0', '1', '1', '43');
INSERT INTO `device-bak` VALUES ('004A7702110305C3', '', '004A7702110305C3', '', '2018-12-21 16:00:09', '2019-01-09 16:42:15', 'kickoff2019', '14', '155', '0', '1', '1', '66');
INSERT INTO `device-bak` VALUES ('004A7702110305C4', '', '004A7702110305C4', '', '2018-12-21 16:00:09', '2019-01-09 17:09:41', 'kickoff2019', '14', '155', '0', '1', '1', '195');
INSERT INTO `device-bak` VALUES ('004A7702110305C5', '', '004A7702110305C5', '', '2018-12-21 16:00:09', '2019-01-09 17:11:54', 'kickoff2019', '14', '155', '0', '1', '1', '57');
INSERT INTO `device-bak` VALUES ('004A7702110305C6', '', '004A7702110305C6', '', '2018-12-21 16:00:09', '2019-01-09 16:38:17', 'kickoff2019', '14', '155', '0', '1', '1', '70');
INSERT INTO `device-bak` VALUES ('004A7702110305C7', '', '004A7702110305C7', '', '2018-12-21 16:00:09', '2019-01-09 17:11:57', 'kickoff2019', '14', '155', '0', '1', '1', '97');
INSERT INTO `device-bak` VALUES ('004A7702110305C8', '', '004A7702110305C8', '', '2018-12-21 16:00:09', '2019-01-09 17:12:20', 'kickoff2019', '14', '155', '0', '1', '1', '47');
INSERT INTO `device-bak` VALUES ('004A7702110305C9', '', '004A7702110305C9', '', '2018-12-21 16:00:09', '2019-01-09 16:37:42', 'kickoff2019', '14', '155', '0', '1', '2', '55');
INSERT INTO `device-bak` VALUES ('004A7702110305CA', '', '004A7702110305CA', '', '2018-12-21 16:00:09', '2019-01-09 17:09:42', 'kickoff2019', '14', '155', '0', '1', '2', '27');
INSERT INTO `device-bak` VALUES ('004A7702110305CB', '', '004A7702110305CB', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', null);
INSERT INTO `device-bak` VALUES ('004A7702110305CC', '', '004A7702110305CC', '', '2018-12-21 16:00:09', '2019-01-09 17:11:53', 'kickoff2019', '14', '155', '0', '1', '2', '72');
INSERT INTO `device-bak` VALUES ('004A7702110305CD', '', '004A7702110305CD', '', '2018-12-21 16:00:09', '2019-01-09 17:09:06', 'kickoff2019', '14', '155', '0', '1', '2', '32');
INSERT INTO `device-bak` VALUES ('004A7702110305CE', '', '004A7702110305CE', '', '2018-12-21 16:00:09', '2019-01-09 16:29:59', 'kickoff2019', '14', '155', '0', '1', '2', '122');
INSERT INTO `device-bak` VALUES ('004A7702110305CF', '', '004A7702110305CF', '', '2018-12-21 16:00:09', '2019-01-09 17:07:58', 'kickoff2019', '14', '155', '0', '1', '2', '37');
INSERT INTO `device-bak` VALUES ('004A7702110305D0', '', '004A7702110305D0', '', '2018-12-21 16:00:09', '2019-01-09 16:31:02', 'kickoff2019', '14', '155', '0', '1', '2', '309');
INSERT INTO `device-bak` VALUES ('004A7702110305D1', '', '004A7702110305D1', '', '2018-12-21 16:00:09', '2019-01-09 17:04:25', 'kickoff2019', '14', '155', '0', '1', '2', '176');
INSERT INTO `device-bak` VALUES ('004A7702110305D2', '', '004A7702110305D2', '', '2018-12-21 16:00:09', '2019-01-09 17:13:00', 'kickoff2019', '14', '155', '0', '1', '2', '130');
INSERT INTO `device-bak` VALUES ('004A7702110305D3', '', '004A7702110305D3', '', '2018-12-21 16:00:09', '2019-01-09 17:08:02', 'kickoff2019', '14', '155', '0', '1', '2', '59');
INSERT INTO `device-bak` VALUES ('004A7702110305D4', '', '004A7702110305D4', '', '2018-12-21 16:00:09', '2019-01-09 17:13:37', 'kickoff2019', '14', '155', '0', '1', '2', '118');
INSERT INTO `device-bak` VALUES ('004A7702110305D5', '', '004A7702110305D5', '', '2018-12-21 16:00:09', '2019-01-09 17:08:22', 'kickoff2019', '14', '155', '0', '1', '2', '110');
INSERT INTO `device-bak` VALUES ('004A7702110305D6', '', '004A7702110305D6', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', '14');
INSERT INTO `device-bak` VALUES ('004A7702110305D7', '', '004A7702110305D7', '', '2018-12-21 16:00:09', '2019-01-09 17:11:36', 'kickoff2019', '14', '155', '0', '1', '2', '106');
INSERT INTO `device-bak` VALUES ('004A7702110305D8', '', '004A7702110305D8', '', '2018-12-21 16:00:09', '2019-01-09 17:11:21', 'kickoff2019', '14', '155', '0', '1', '2', '33');
INSERT INTO `device-bak` VALUES ('004A7702110305D9', '', '004A7702110305D9', '', '2018-12-21 16:00:09', '2019-01-09 17:11:44', 'kickoff2019', '14', '155', '0', '1', '2', '33');
INSERT INTO `device-bak` VALUES ('004A7702110305DA', '', '004A7702110305DA', '', '2018-12-21 16:00:09', '2019-01-09 17:11:45', 'kickoff2019', '14', '155', '0', '1', '2', '27');
INSERT INTO `device-bak` VALUES ('004A7702110305DB', '', '004A7702110305DB', '', '2018-12-21 16:00:09', '2019-01-10 16:51:26', 'kickoff2019', '14', '155', '0', '1', '2', '272');
INSERT INTO `device-bak` VALUES ('004A7702110305DC', '', '004A7702110305DC', '', '2018-12-21 16:00:09', '2019-01-09 17:07:06', 'kickoff2019', '14', '155', '0', '1', '2', '35');
INSERT INTO `device-bak` VALUES ('004A7702110305DD', '', '004A7702110305DD', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', null);
INSERT INTO `device-bak` VALUES ('004A7702110305DE', '', '004A7702110305DE', '', '2018-12-21 16:00:09', '2019-01-09 17:05:54', 'kickoff2019', '14', '155', '0', '1', '2', '72');
INSERT INTO `device-bak` VALUES ('004A7702110305DF', '', '004A7702110305DF', '', '2018-12-21 16:00:09', '2019-01-09 17:11:59', 'kickoff2019', '14', '155', '0', '1', '2', '226');
INSERT INTO `device-bak` VALUES ('004A7702110305E0', '', '004A7702110305E0', '', '2018-12-21 16:00:09', '2019-01-09 17:13:13', 'kickoff2019', '14', '155', '0', '1', '2', '47');
INSERT INTO `device-bak` VALUES ('004A7702110305E1', '', '004A7702110305E1', '', '2018-12-21 16:00:09', '2019-01-09 17:10:50', 'kickoff2019', '14', '155', '0', '1', '2', '33');
INSERT INTO `device-bak` VALUES ('004A7702110305E2', '', '004A7702110305E2', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', null);
INSERT INTO `device-bak` VALUES ('004A7702110305E3', '', '004A7702110305E3', '', '2018-12-21 16:00:09', '2019-01-09 17:01:35', 'kickoff2019', '14', '155', '0', '1', '2', '370');
INSERT INTO `device-bak` VALUES ('004A7702110305E4', '', '004A7702110305E4', '', '2018-12-21 16:00:09', '2019-01-09 17:12:41', 'kickoff2019', '14', '155', '0', '1', '2', '137');
INSERT INTO `device-bak` VALUES ('004A7702110305E5', '', '004A7702110305E5', '', '2018-12-21 16:00:09', '2019-01-09 16:27:12', 'kickoff2019', '14', '155', '0', '1', '2', '289');
INSERT INTO `device-bak` VALUES ('004A7702110305E6', '', '004A7702110305E6', '', '2018-12-21 16:00:09', '2019-01-09 16:43:43', 'kickoff2019', '14', '155', '0', '1', '2', '78');
INSERT INTO `device-bak` VALUES ('004A7702110305E7', '', '004A7702110305E7', '', '2018-12-21 16:00:09', '2019-01-09 17:13:39', 'kickoff2019', '14', '155', '0', '1', '2', '95');
INSERT INTO `device-bak` VALUES ('004A7702110305E8', '', '004A7702110305E8', '', '2018-12-21 16:00:09', '2019-01-09 16:35:36', 'kickoff2019', '14', '155', '0', '1', '2', '86');
INSERT INTO `device-bak` VALUES ('004A7702110305E9', '', '004A7702110305E9', '', '2018-12-21 16:00:09', '2019-01-09 17:12:38', 'kickoff2019', '14', '155', '0', '1', '2', '121');
INSERT INTO `device-bak` VALUES ('004A7702110305EA', '', '004A7702110305EA', '', '2018-12-21 16:00:09', '2019-01-09 17:12:15', 'kickoff2019', '14', '155', '0', '1', '2', '82');
INSERT INTO `device-bak` VALUES ('004A7702110305EB', '', '004A7702110305EB', '', '2018-12-21 16:00:09', '2019-01-09 17:07:09', 'kickoff2019', '14', '155', '0', '1', '2', '36');
INSERT INTO `device-bak` VALUES ('004A7702110305EC', '', '004A7702110305EC', '', '2018-12-21 16:00:09', '2019-01-09 17:10:36', 'kickoff2019', '14', '155', '0', '1', '2', '27');
INSERT INTO `device-bak` VALUES ('004A7702110305ED', '', '004A7702110305ED', '', '2018-12-21 16:00:09', '2019-01-09 17:11:26', 'kickoff2019', '14', '155', '0', '1', '2', '30');
INSERT INTO `device-bak` VALUES ('004A7702110305EE', '', '004A7702110305EE', '', '2018-12-21 16:00:09', '2019-01-09 17:10:07', 'kickoff2019', '14', '155', '0', '1', '2', '66');
INSERT INTO `device-bak` VALUES ('004A7702110305EF', '', '004A7702110305EF', '', '2018-12-21 16:00:09', '2019-01-09 17:05:05', 'kickoff2019', '14', '155', '0', '1', '2', '53');
INSERT INTO `device-bak` VALUES ('004A7702110305F0', '', '004A7702110305F0', '', '2018-12-21 16:00:09', '2019-01-09 17:08:22', 'kickoff2019', '14', '155', '0', '1', '2', '64');
INSERT INTO `device-bak` VALUES ('004A7702110305F1', '', '004A7702110305F1', '', '2018-12-21 16:00:09', '2019-01-09 16:59:57', 'kickoff2019', '14', '155', '0', '1', '2', '58');
INSERT INTO `device-bak` VALUES ('004A7702110305F2', '', '004A7702110305F2', '', '2018-12-21 16:00:09', '2019-01-09 17:04:08', 'kickoff2019', '14', '155', '0', '1', '2', '7');
INSERT INTO `device-bak` VALUES ('004A7702110305F3', '', '004A7702110305F3', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', null);
INSERT INTO `device-bak` VALUES ('004A7702110305F4', '', '004A7702110305F4', '', '2018-12-21 16:00:09', '2019-01-09 17:07:46', 'kickoff2019', '14', '155', '0', '1', '2', '83');
INSERT INTO `device-bak` VALUES ('004A7702110305F5', '', '004A7702110305F5', '', '2018-12-21 16:00:09', '2019-01-09 17:13:38', 'kickoff2019', '14', '155', '0', '1', '2', '127');
INSERT INTO `device-bak` VALUES ('004A7702110305F6', '', '004A7702110305F6', '', '2018-12-21 16:00:09', '2019-01-09 17:13:15', 'kickoff2019', '14', '155', '0', '1', '2', '5');
INSERT INTO `device-bak` VALUES ('004A7702110305F7', '', '004A7702110305F7', '', '2018-12-21 16:00:09', '2019-01-09 16:49:51', 'kickoff2019', '14', '155', '0', '1', '2', '15');
INSERT INTO `device-bak` VALUES ('004A7702110305F8', '', '004A7702110305F8', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', '38');
INSERT INTO `device-bak` VALUES ('004A7702110305F9', '', '004A7702110305F9', '', '2018-12-21 16:00:09', '2019-01-09 16:33:11', 'kickoff2019', '14', '155', '0', '1', '2', '82');
INSERT INTO `device-bak` VALUES ('004A7702110305FA', '', '004A7702110305FA', '', '2018-12-21 16:00:09', '2019-01-09 17:08:55', 'kickoff2019', '14', '155', '0', '1', '2', '188');
INSERT INTO `device-bak` VALUES ('004A7702110305FB', '', '004A7702110305FB', '', '2018-12-21 16:00:09', '2019-01-09 17:12:57', 'kickoff2019', '14', '155', '0', '1', '2', '42');
INSERT INTO `device-bak` VALUES ('004A7702110305FC', '', '004A7702110305FC', '', '2018-12-21 16:00:09', '2019-01-09 17:09:36', 'kickoff2019', '14', '155', '0', '1', '2', '71');
INSERT INTO `device-bak` VALUES ('004A7702110305FD', '', '004A7702110305FD', '', '2018-12-21 16:00:09', '2019-01-09 17:13:00', 'kickoff2019', '14', '155', '0', '1', '2', '181');
INSERT INTO `device-bak` VALUES ('004A7702110305FE', '', '004A7702110305FE', '', '2018-12-21 16:00:09', '2019-01-09 17:05:43', 'kickoff2019', '14', '155', '0', '1', '2', '40');
INSERT INTO `device-bak` VALUES ('004A7702110305FF', '', '004A7702110305FF', '', '2018-12-21 16:00:09', '2019-01-09 17:08:42', 'kickoff2019', '14', '155', '0', '1', '2', '277');
INSERT INTO `device-bak` VALUES ('004A770211030600', '', '004A770211030600', '', '2018-12-21 16:00:09', '2019-01-10 16:53:45', 'kickoff2019', '14', '155', '0', '1', '2', '197');
INSERT INTO `device-bak` VALUES ('004A770211030601', '', '004A770211030601', '', '2018-12-21 16:00:09', '2019-01-10 16:53:12', 'kickoff2019', '14', '155', '0', '1', '2', '899');
INSERT INTO `device-bak` VALUES ('004A770211030602', '', '004A770211030602', '', '2018-12-21 16:00:09', '2019-01-10 16:50:58', 'kickoff2019', '14', '155', '0', '1', '2', '149');
INSERT INTO `device-bak` VALUES ('004A770211030603', '', '004A770211030603', '', '2018-12-21 16:00:09', '2019-01-10 16:46:16', 'kickoff2019', '14', '155', '0', '1', '2', '148');
INSERT INTO `device-bak` VALUES ('004A770211030604', '', '004A770211030604', '', '2018-12-21 16:00:09', '2019-01-10 16:46:58', 'kickoff2019', '14', '155', '0', '1', '2', '62');
INSERT INTO `device-bak` VALUES ('004A770211030605', '', '004A770211030605', '', '2018-12-21 16:00:09', '2019-01-10 16:50:56', 'kickoff2019', '14', '155', '0', '1', '2', '141');
INSERT INTO `device-bak` VALUES ('004A770211030606', '', '004A770211030606', '', '2018-12-21 16:00:09', '2019-01-10 16:52:35', 'kickoff2019', '14', '155', '0', '1', '2', '223');
INSERT INTO `device-bak` VALUES ('004A770211030607', '', '004A770211030607', '', '2018-12-21 16:00:09', '2019-01-10 16:49:45', 'kickoff2019', '14', '155', '0', '1', '2', '61');
INSERT INTO `device-bak` VALUES ('004A770211030608', '', '004A770211030608', '', '2018-12-21 16:00:09', '2019-01-10 16:48:12', 'kickoff2019', '14', '155', '0', '1', '2', '60');
INSERT INTO `device-bak` VALUES ('004A770211030609', '', '004A770211030609', '', '2018-12-21 16:00:09', '2019-01-10 16:49:36', 'kickoff2019', '14', '155', '0', '1', '2', '109');
INSERT INTO `device-bak` VALUES ('004A77021103060A', '', '004A77021103060A', '', '2018-12-21 16:00:09', '2019-01-10 16:54:15', 'kickoff2019', '14', '155', '0', '1', '2', '1123');
INSERT INTO `device-bak` VALUES ('004A77021103060B', '', '004A77021103060B', '', '2018-12-21 16:00:09', '2019-01-10 16:55:03', 'kickoff2019', null, '155', '1', '1', '2', '65');
INSERT INTO `device-bak` VALUES ('004A77021103060C', '', '004A77021103060C', '', '2018-12-21 16:00:09', '2019-01-10 16:51:31', 'kickoff2019', '14', '155', '0', '1', '2', '136');
INSERT INTO `device-bak` VALUES ('004A77021103060D', '', '004A77021103060D', '', '2018-12-21 16:00:09', '2019-01-10 16:52:02', 'kickoff2019', '14', '155', '0', '1', '2', '136');
INSERT INTO `device-bak` VALUES ('004A77021103060E', '', '004A77021103060E', '', '2018-12-21 16:00:09', '2019-01-10 16:53:01', 'kickoff2019', '14', '155', '0', '1', '2', '150');
INSERT INTO `device-bak` VALUES ('004A77021103060F', '', '004A77021103060F', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', null);
INSERT INTO `device-bak` VALUES ('004A770211030610', '', '004A770211030610', '', '2018-12-21 16:00:09', '2019-01-10 16:49:24', 'kickoff2019', '14', '155', '0', '1', '2', '97');
INSERT INTO `device-bak` VALUES ('004A770211030611', '', '004A770211030611', '', '2018-12-21 16:00:09', '2019-01-10 16:54:28', 'kickoff2019', '14', '155', '0', '1', '2', '145');
INSERT INTO `device-bak` VALUES ('004A770211030612', '', '004A770211030612', '', '2018-12-21 16:00:09', '2019-01-10 16:47:39', 'kickoff2019', '14', '155', '0', '1', '2', '169');
INSERT INTO `device-bak` VALUES ('004A770211030613', '', '004A770211030613', '', '2018-12-21 16:00:09', '2019-01-10 16:55:10', 'kickoff2019', null, '155', '1', '1', '2', '129');
INSERT INTO `device-bak` VALUES ('004A770211030614', '', '004A770211030614', '', '2018-12-21 16:00:09', '2019-01-10 16:45:33', 'kickoff2019', '14', '155', '0', '1', '2', '86');
INSERT INTO `device-bak` VALUES ('004A770211030615', '', '004A770211030615', '', '2018-12-21 16:00:09', '2019-01-10 16:43:45', 'kickoff2019', '14', '155', '0', '1', '2', '48');
INSERT INTO `device-bak` VALUES ('004A770211030616', '', '004A770211030616', '', '2018-12-21 16:00:09', '2019-01-10 16:52:07', 'kickoff2019', '14', '155', '0', '1', '2', '50');
INSERT INTO `device-bak` VALUES ('004A770211030617', '', '004A770211030617', '', '2018-12-21 16:00:09', '2019-01-10 13:16:24', 'kickoff2019', '14', '155', '0', '1', '2', '7');
INSERT INTO `device-bak` VALUES ('004A770211030618', '', '004A770211030618', '', '2018-12-21 16:00:09', '2019-01-10 16:54:16', 'kickoff2019', '14', '155', '0', '1', '2', '699');
INSERT INTO `device-bak` VALUES ('004A770211030619', '', '004A770211030619', '', '2018-12-21 16:00:09', '2019-01-10 16:53:27', 'kickoff2019', '14', '155', '0', '1', '2', '44');
INSERT INTO `device-bak` VALUES ('004A77021103061A', '', '004A77021103061A', '', '2018-12-21 16:00:09', '2019-01-10 16:49:12', 'kickoff2019', '14', '155', '0', '1', '2', '136');
INSERT INTO `device-bak` VALUES ('004A77021103061B', '', '004A77021103061B', '', '2018-12-21 16:00:09', '2019-01-10 16:50:59', 'kickoff2019', '14', '155', '0', '1', '2', '355');
INSERT INTO `device-bak` VALUES ('004A77021103061C', '', '004A77021103061C', '', '2018-12-21 16:00:09', '2019-01-10 16:54:05', 'kickoff2019', '14', '155', '0', '1', '2', '283');
INSERT INTO `device-bak` VALUES ('004A77021103061D', '', '004A77021103061D', '', '2018-12-21 16:00:09', '2019-01-10 16:51:12', 'kickoff2019', null, '155', '1', '1', '2', '50');
INSERT INTO `device-bak` VALUES ('004A77021103061E', '', '004A77021103061E', '', '2018-12-21 16:00:09', '2019-01-10 13:14:04', 'kickoff2019', '14', '155', '0', '1', '2', '93');
INSERT INTO `device-bak` VALUES ('004A77021103061F', '', '004A77021103061F', '', '2018-12-21 16:00:09', '2019-01-10 16:53:16', 'kickoff2019', '14', '155', '0', '1', '2', '69');
INSERT INTO `device-bak` VALUES ('004A770211030620', '', '004A770211030620', '', '2018-12-21 16:00:09', '2019-01-10 16:52:27', 'kickoff2019', null, '155', '1', '1', '2', '43');
INSERT INTO `device-bak` VALUES ('004A770211030621', '', '004A770211030621', '', '2018-12-21 16:00:09', '2019-01-10 16:51:07', 'kickoff2019', '14', '155', '0', '1', '2', '92');
INSERT INTO `device-bak` VALUES ('004A770211030622', '', '004A770211030622', '', '2018-12-21 16:00:09', '2019-01-10 16:50:49', 'kickoff2019', '14', '155', '0', '1', '2', '800');
INSERT INTO `device-bak` VALUES ('004A770211030623', '', '004A770211030623', '', '2018-12-21 16:00:09', '2019-01-10 16:51:00', 'kickoff2019', '14', '155', '0', '1', '2', '285');
INSERT INTO `device-bak` VALUES ('004A770211030624', '', '004A770211030624', '', '2018-12-21 16:00:09', '2019-01-10 16:46:50', 'kickoff2019', '14', '155', '0', '1', '2', '143');
INSERT INTO `device-bak` VALUES ('004A770211030625', '', '004A770211030625', '', '2018-12-21 16:00:09', '2019-01-10 16:52:34', 'kickoff2019', '14', '155', '0', '1', '2', '185');
INSERT INTO `device-bak` VALUES ('004A770211030626', '', '004A770211030626', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', null);
INSERT INTO `device-bak` VALUES ('004A770211030627', '', '004A770211030627', '', '2018-12-21 16:00:09', '2019-01-10 16:52:54', 'kickoff2019', '14', '155', '0', '1', '2', '43');
INSERT INTO `device-bak` VALUES ('004A770211030628', '', '004A770211030628', '', '2018-12-21 16:00:09', '2019-01-10 16:49:27', 'kickoff2019', '14', '155', '0', '1', '2', '46');
INSERT INTO `device-bak` VALUES ('004A770211030629', '', '004A770211030629', '', '2018-12-21 16:00:09', '2019-01-10 16:55:22', 'kickoff2019', '14', '155', '0', '1', '2', '56');
INSERT INTO `device-bak` VALUES ('004A77021103062A', '', '004A77021103062A', '', '2018-12-21 16:00:09', '2019-01-10 16:55:05', 'kickoff2019', '14', '155', '0', '1', '2', '46');
INSERT INTO `device-bak` VALUES ('004A77021103062B', '', '004A77021103062B', '', '2018-12-21 16:00:09', '2019-01-10 16:49:26', 'kickoff2019', '14', '155', '0', '1', '2', '48');
INSERT INTO `device-bak` VALUES ('004A77021103062C', '', '004A77021103062C', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '2', null);
INSERT INTO `device-bak` VALUES ('004A77021103062D', '', '004A77021103062D', '', '2018-12-21 16:00:09', '2019-01-10 16:44:18', 'kickoff2019', '14', '155', '0', '1', '3', '81');
INSERT INTO `device-bak` VALUES ('004A77021103062E', '', '004A77021103062E', '', '2018-12-21 16:00:09', '2019-01-10 13:09:08', 'kickoff2019', '14', '155', '0', '1', '3', '112');
INSERT INTO `device-bak` VALUES ('004A77021103062F', '', '004A77021103062F', '', '2018-12-21 16:00:09', '2019-01-10 16:54:24', 'kickoff2019', '14', '155', '0', '1', '3', '55');
INSERT INTO `device-bak` VALUES ('004A770211030630', '', '004A770211030630', '', '2018-12-21 16:00:09', '2019-01-10 16:54:50', 'kickoff2019', '14', '155', '0', '1', '3', '1048');
INSERT INTO `device-bak` VALUES ('004A770211030631', '', '004A770211030631', '', '2018-12-21 16:00:09', '2019-01-10 16:53:09', 'kickoff2019', '14', '155', '0', '1', '3', '52');
INSERT INTO `device-bak` VALUES ('004A770211030632', '', '004A770211030632', '', '2018-12-21 16:00:09', '2019-01-10 16:50:55', 'kickoff2019', '14', '155', '0', '1', '3', '1083');
INSERT INTO `device-bak` VALUES ('004A770211030633', '', '004A770211030633', '', '2018-12-21 16:00:09', '2019-01-10 16:50:55', 'kickoff2019', '14', '155', '0', '1', '3', '454');
INSERT INTO `device-bak` VALUES ('004A770211030634', '', '004A770211030634', '', '2018-12-21 16:00:09', '2019-01-10 16:51:16', 'kickoff2019', '14', '155', '0', '1', '3', '38');
INSERT INTO `device-bak` VALUES ('004A770211030635', '', '004A770211030635', '', '2018-12-21 16:00:09', '2019-01-10 16:48:42', 'kickoff2019', '14', '155', '0', '1', '3', '128');
INSERT INTO `device-bak` VALUES ('004A770211030636', '', '004A770211030636', '', '2018-12-21 16:00:09', '2019-01-10 16:53:02', 'kickoff2019', '14', '155', '0', '1', '3', '466');
INSERT INTO `device-bak` VALUES ('004A770211030637', '', '004A770211030637', '', '2018-12-21 16:00:09', '2019-01-10 16:47:58', 'kickoff2019', '14', '155', '0', '1', '3', '135');
INSERT INTO `device-bak` VALUES ('004A770211030638', '', '004A770211030638', '', '2018-12-21 16:00:09', null, 'kickoff2019', '14', '155', '0', '1', '3', null);
INSERT INTO `device-bak` VALUES ('004A770211030639', '', '004A770211030639', '', '2018-12-21 16:00:09', '2019-01-10 16:51:02', 'kickoff2019', '14', '155', '0', '1', '3', '804');
INSERT INTO `device-bak` VALUES ('004A77021103063A', '', '004A77021103063A', '', '2018-12-21 16:00:09', '2019-01-10 16:49:42', 'kickoff2019', null, '155', '1', '1', '3', '317');
INSERT INTO `device-bak` VALUES ('004A77021103063B', '', '004A77021103063B', '', '2018-12-21 16:00:09', '2019-01-10 16:54:06', 'kickoff2019', '14', '155', '0', '1', '3', '131');
INSERT INTO `device-bak` VALUES ('004A77021103063C', '', '004A77021103063C', '', '2018-12-21 16:00:09', '2019-01-10 16:51:58', 'kickoff2019', '14', '155', '0', '1', '3', '111');
INSERT INTO `device-bak` VALUES ('004A77021103063D', '', '004A77021103063D', '', '2018-12-21 16:00:09', '2019-01-10 16:46:39', 'kickoff2019', '14', '155', '0', '1', '3', '206');
INSERT INTO `device-bak` VALUES ('004A77021103063E', '', '004A77021103063E', '', '2018-12-21 16:00:09', '2019-01-10 16:53:44', 'kickoff2019', null, '155', '1', '1', '3', '140');
INSERT INTO `device-bak` VALUES ('004A77021103063F', '', '004A77021103063F', '', '2018-12-21 16:00:09', '2019-01-10 16:49:06', 'kickoff2019', '14', '155', '0', '1', '3', '199');
INSERT INTO `device-bak` VALUES ('004A770211030640', '', '004A770211030640', '', '2018-12-21 16:00:09', '2019-01-10 16:48:49', 'kickoff2019', '14', '155', '0', '1', '3', '175');
INSERT INTO `device-bak` VALUES ('004A770211030641', '', '004A770211030641', '', '2018-12-21 16:00:09', '2019-01-10 16:54:33', 'kickoff2019', '14', '155', '0', '1', '3', '188');
INSERT INTO `device-bak` VALUES ('004A770211030642', '', '004A770211030642', '', '2018-12-21 16:00:09', '2019-01-10 16:39:42', 'kickoff2019', null, '155', '1', '1', '3', '233');
INSERT INTO `device-bak` VALUES ('004A770211030643', '', '004A770211030643', '', '2018-12-21 16:00:09', '2019-01-10 16:55:30', 'kickoff2019', null, '155', '1', '1', '3', '39');
INSERT INTO `device-bak` VALUES ('004A770211030644', '', '004A770211030644', '', '2018-12-21 16:00:09', '2019-01-10 16:44:42', 'kickoff2019', null, '155', '1', '1', '3', null);
INSERT INTO `device-bak` VALUES ('004A770211030645', '', '004A770211030645', '', '2018-12-21 16:00:09', '2019-01-10 16:51:55', 'kickoff2019', '14', '155', '0', '1', '3', '148');
INSERT INTO `device-bak` VALUES ('004A770211030646', '', '004A770211030646', '', '2018-12-21 16:00:09', '2019-01-10 16:52:00', 'kickoff2019', null, '155', '1', '1', '3', '161');
INSERT INTO `device-bak` VALUES ('004A770211030647', '', '004A770211030647', '', '2018-12-21 16:00:09', '2019-01-10 16:54:06', 'kickoff2019', '14', '155', '0', '1', '3', '375');
INSERT INTO `device-bak` VALUES ('004A770211030648', '', '004A770211030648', '', '2018-12-21 16:00:09', '2019-01-10 13:05:20', 'kickoff2019', '14', '155', '0', '1', '3', '97');
INSERT INTO `device-bak` VALUES ('004A770211030649', '', '004A770211030649', '', '2018-12-21 16:00:09', '2019-01-10 16:55:21', 'kickoff2019', null, '155', '1', '1', '3', '38');
INSERT INTO `device-bak` VALUES ('004A77021103064A', '', '004A77021103064A', '', '2018-12-21 16:00:09', '2019-01-10 16:54:20', 'kickoff2019', '14', '155', '0', '1', '3', '134');
INSERT INTO `device-bak` VALUES ('004A77021103064B', '', '004A77021103064B', '', '2018-12-21 16:00:09', '2019-01-10 16:50:39', 'kickoff2019', '14', '155', '0', '1', '3', '302');
INSERT INTO `device-bak` VALUES ('004A77021103064C', '', '004A77021103064C', '', '2018-12-21 16:00:09', '2019-01-10 16:51:27', 'kickoff2019', '14', '155', '0', '1', '3', '157');
INSERT INTO `device-bak` VALUES ('004A77021103064D', '', '004A77021103064D', '', '2018-12-21 16:00:09', '2019-01-10 16:55:08', 'kickoff2019', '14', '155', '0', '1', '3', '180');
INSERT INTO `device-bak` VALUES ('004A77021103064E', '', '004A77021103064E', '', '2018-12-21 16:00:09', '2019-01-10 16:47:10', 'kickoff2019', '14', '155', '0', '1', '3', '51');
INSERT INTO `device-bak` VALUES ('004A77021103064F', '', '004A77021103064F', '', '2018-12-21 16:00:09', '2019-01-10 16:49:52', 'kickoff2019', null, '155', '1', '1', '3', '92');
INSERT INTO `device-bak` VALUES ('004A770211030650', '', '004A770211030650', '', '2018-12-21 16:00:09', '2019-01-10 16:50:46', 'kickoff2019', '14', '155', '0', '1', '3', '128');
INSERT INTO `device-bak` VALUES ('004A770211030651', '', '004A770211030651', '', '2018-12-21 16:00:09', '2019-01-10 16:47:10', 'kickoff2019', '14', '155', '0', '1', '3', '290');
INSERT INTO `device-bak` VALUES ('004A770211030652', '', '004A770211030652', '', '2018-12-21 16:00:09', '2019-01-10 16:53:59', 'kickoff2019', '14', '155', '0', '1', '3', '123');
INSERT INTO `device-bak` VALUES ('004A770211030653', '', '004A770211030653', '', '2018-12-21 16:00:09', '2019-01-10 16:54:53', 'kickoff2019', null, '155', '1', '1', '3', '53');
INSERT INTO `device-bak` VALUES ('004A770211030654', '', '004A770211030654', '', '2018-12-21 16:00:09', '2019-01-10 16:49:54', 'kickoff2019', '14', '155', '0', '1', '3', '119');
INSERT INTO `device-bak` VALUES ('004A770211030655', '', '004A770211030655', '', '2018-12-21 16:00:09', '2019-01-10 16:50:57', 'kickoff2019', '14', '155', '0', '1', '3', '1179');
INSERT INTO `device-bak` VALUES ('004A770211030656', '', '004A770211030656', '', '2018-12-21 16:00:09', '2019-01-10 16:54:39', 'kickoff2019', '14', '155', '0', '1', '3', '131');
INSERT INTO `device-bak` VALUES ('004A770211030657', '', '004A770211030657', '', '2018-12-21 16:00:09', '2019-01-10 16:52:30', 'kickoff2019', '14', '155', '0', '1', '3', '860');
INSERT INTO `device-bak` VALUES ('004A770211030658', '', '004A770211030658', '', '2018-12-21 16:00:09', '2019-01-10 16:49:44', 'kickoff2019', '14', '155', '0', '1', '3', '481');
INSERT INTO `device-bak` VALUES ('004A770211030659', '', '004A770211030659', '', '2018-12-21 16:00:09', '2019-01-10 16:10:50', 'kickoff2019', '14', '155', '0', '1', '3', '245');
INSERT INTO `device-bak` VALUES ('004A77021103065A', '', '004A77021103065A', '', '2018-12-21 16:00:09', '2019-01-10 16:52:24', 'kickoff2019', '14', '155', '0', '1', '3', '69');
INSERT INTO `device-bak` VALUES ('004A77021103065B', '', '004A77021103065B', '', '2018-12-21 16:00:09', '2019-01-10 16:39:42', 'kickoff2019', null, '155', '1', '1', '3', null);
INSERT INTO `device-bak` VALUES ('004A77021103065C', '', '004A77021103065C', '', '2018-12-21 16:00:09', '2019-01-10 16:55:20', 'kickoff2019', '14', '155', '0', '1', '3', '149');
INSERT INTO `device-bak` VALUES ('004A77021103065D', '', '004A77021103065D', '', '2018-12-21 16:00:09', '2019-01-10 14:45:12', 'kickoff2019', '14', '155', '0', '1', '3', '143');
INSERT INTO `device-bak` VALUES ('004A77021103065E', '', '004A77021103065E', '', '2018-12-21 16:00:09', '2019-01-10 16:54:59', 'kickoff2019', '14', '155', '0', '1', '3', '162');
INSERT INTO `device-bak` VALUES ('004A77021103065F', '', '004A77021103065F', '', '2018-12-21 16:00:09', '2019-01-10 16:48:46', 'kickoff2019', '14', '155', '0', '1', '3', '223');
INSERT INTO `device-bak` VALUES ('004A770211030660', '', '004A770211030660', '', '2018-12-21 16:00:09', '2019-01-10 16:50:59', 'kickoff2019', '14', '155', '0', '1', '3', '333');
INSERT INTO `device-bak` VALUES ('004A770211030661', '', '004A770211030661', '', '2018-12-21 16:00:09', '2019-01-10 16:54:13', 'kickoff2019', null, '155', '1', '1', '3', '1166');
INSERT INTO `device-bak` VALUES ('004A770211030662', '', '004A770211030662', '', '2018-12-21 16:00:09', '2019-01-10 16:46:56', 'kickoff2019', '14', '155', '0', '1', '3', '303');
INSERT INTO `device-bak` VALUES ('004A770211030663', '', '004A770211030663', '', '2018-12-21 16:00:09', '2019-01-10 16:46:07', 'kickoff2019', '14', '155', '0', '1', '3', '101');
INSERT INTO `device-bak` VALUES ('004A770211030664', '', '004A770211030664', '', '2018-12-21 16:00:09', '2019-01-10 16:50:59', 'kickoff2019', '14', '155', '0', '1', '3', '523');
INSERT INTO `device-bak` VALUES ('004A770211030665', '', '004A770211030665', '', '2018-12-21 16:00:09', '2019-01-10 16:43:08', 'kickoff2019', '14', '155', '0', '1', '3', '59');
INSERT INTO `device-bak` VALUES ('004A770211030666', '', '004A770211030666', '', '2018-12-21 16:00:09', '2019-01-10 16:53:46', 'kickoff2019', '14', '155', '0', '1', '3', '101');
INSERT INTO `device-bak` VALUES ('004A770211030667', '', '004A770211030667', '', '2018-12-21 16:00:09', '2019-01-10 13:08:59', 'kickoff2019', '14', '155', '0', '1', '3', '133');
INSERT INTO `device-bak` VALUES ('004A770211030668', '', '004A770211030668', '', '2018-12-21 16:00:09', '2019-01-10 16:53:13', 'kickoff2019', '14', '155', '0', '1', '3', '192');
INSERT INTO `device-bak` VALUES ('004A770211030669', '', '004A770211030669', '', '2018-12-21 16:00:09', '2019-01-10 16:51:05', 'kickoff2019', '14', '155', '0', '1', '3', '368');
INSERT INTO `device-bak` VALUES ('004A77021103066A', '', '004A77021103066A', '', '2018-12-21 16:00:09', '2019-01-10 16:54:42', 'kickoff2019', null, '155', '1', '1', '3', '143');
INSERT INTO `device-bak` VALUES ('004A77021103066B', '', '004A77021103066B', '', '2018-12-21 16:00:09', '2019-01-10 16:51:02', 'kickoff2019', '14', '155', '0', '1', '3', '251');
INSERT INTO `device-bak` VALUES ('004A77021103066C', '', '004A77021103066C', '', '2018-12-21 16:00:09', '2019-01-10 16:51:58', 'kickoff2019', '14', '155', '0', '1', '3', '109');
INSERT INTO `device-bak` VALUES ('004A77021103066D', '', '004A77021103066D', '', '2018-12-21 16:00:09', '2019-01-10 16:50:03', 'kickoff2019', '14', '155', '0', '1', '3', '207');
INSERT INTO `device-bak` VALUES ('004A77021103066E', '', '004A77021103066E', '', '2018-12-21 16:00:09', '2019-01-10 16:52:07', 'kickoff2019', '14', '155', '0', '1', '3', '86');
INSERT INTO `device-bak` VALUES ('004A77021103066F', '', '004A77021103066F', '', '2018-12-21 16:00:09', '2019-01-10 16:51:35', 'kickoff2019', '14', '155', '0', '1', '3', '96');
INSERT INTO `device-bak` VALUES ('004A770211030670', '', '004A770211030670', '', '2018-12-21 16:00:09', '2019-01-10 16:50:56', 'kickoff2019', '14', '155', '0', '1', '3', '315');
INSERT INTO `device-bak` VALUES ('004A770211030671', '', '004A770211030671', '', '2018-12-21 16:00:09', '2019-01-10 16:47:27', 'kickoff2019', '14', '155', '0', '1', '3', '751');
INSERT INTO `device-bak` VALUES ('004A770211030672', '', '004A770211030672', '', '2018-12-21 16:00:09', '2019-01-10 16:50:55', 'kickoff2019', '14', '155', '0', '1', '3', '1474');
INSERT INTO `device-bak` VALUES ('004A770211030673', '', '004A770211030673', '', '2018-12-21 16:00:09', '2019-01-10 16:48:53', 'kickoff2019', '14', '155', '0', '1', '3', '69');
INSERT INTO `device-bak` VALUES ('004A770211030674', '', '004A770211030674', '', '2018-12-21 16:00:09', '2019-01-10 16:50:56', 'kickoff2019', '14', '155', '0', '1', '3', '685');
INSERT INTO `device-bak` VALUES ('004A770211030675', '', '004A770211030675', '', '2018-12-21 16:00:09', '2019-01-10 16:50:55', 'kickoff2019', '14', '155', '0', '1', '3', '100');
INSERT INTO `device-bak` VALUES ('004A770211030676', '', '004A770211030676', '', '2018-12-21 16:00:09', '2019-01-10 16:54:21', 'kickoff2019', null, '155', '1', '1', '3', '806');
INSERT INTO `device-bak` VALUES ('004A770211030677', '', '004A770211030677', '', '2018-12-21 16:00:09', '2019-01-10 16:50:57', 'kickoff2019', '14', '155', '0', '1', '3', '321');
INSERT INTO `device-bak` VALUES ('004A770211030678', '', '004A770211030678', '', '2018-12-21 16:00:09', '2019-01-10 16:44:16', 'kickoff2019', '14', '155', '0', '1', '3', '366');
INSERT INTO `device-bak` VALUES ('004A770211030679', '', '004A770211030679', '', '2018-12-21 16:00:09', '2019-01-10 16:52:42', 'kickoff2019', '14', '155', '0', '1', '3', '100');
INSERT INTO `device-bak` VALUES ('004A77021103067A', '', '004A77021103067A', '', '2018-12-21 16:00:09', '2019-01-10 16:53:32', 'kickoff2019', '14', '155', '0', '1', '3', '192');
INSERT INTO `device-bak` VALUES ('004A77021103067B', '', '004A77021103067B', '', '2018-12-21 16:00:09', '2019-01-10 16:51:06', 'kickoff2019', '14', '155', '0', '1', '3', '147');
INSERT INTO `device-bak` VALUES ('004A77021103067C', '', '004A77021103067C', '', '2018-12-21 16:00:09', '2019-01-10 13:10:59', 'kickoff2019', '14', '155', '0', '1', '3', '101');
INSERT INTO `device-bak` VALUES ('004A77021103067D', '', '004A77021103067D', '', '2018-12-21 16:00:09', '2019-01-10 13:15:31', 'kickoff2019', '14', '155', '0', '1', '3', '106');
INSERT INTO `device-bak` VALUES ('004A77021103067E', '', '004A77021103067E', '', '2018-12-21 16:00:09', '2019-01-10 16:54:38', 'kickoff2019', '14', '155', '0', '1', '3', '667');
INSERT INTO `device-bak` VALUES ('004A77021103067F', '', '004A77021103067F', '', '2018-12-21 16:00:09', '2019-01-10 16:49:27', 'kickoff2019', '14', '155', '0', '1', '3', '49');
INSERT INTO `device-bak` VALUES ('004A770211030680', '', '004A770211030680', '', '2018-12-21 16:00:09', '2019-01-10 16:51:16', 'kickoff2019', null, '155', '1', '1', '3', '68');
INSERT INTO `device-bak` VALUES ('004A770211030681', '', '004A770211030681', '', '2018-12-21 16:00:09', '2019-01-10 16:53:27', 'kickoff2019', '14', '155', '0', '1', '3', '174');
INSERT INTO `device-bak` VALUES ('004A770211030682', '', '004A770211030682', '', '2018-12-21 16:00:09', '2019-01-10 16:54:42', 'kickoff2019', null, '155', '1', '1', '3', '181');
INSERT INTO `device-bak` VALUES ('004A770211030683', '', '004A770211030683', '', '2018-12-21 16:00:09', '2019-01-10 16:51:44', 'kickoff2019', '14', '155', '0', '1', '3', '84');
INSERT INTO `device-bak` VALUES ('004A770211030684', '', '004A770211030684', '', '2018-12-21 16:00:09', '2019-01-10 16:43:29', 'kickoff2019', '14', '155', '0', '1', '3', '534');
INSERT INTO `device-bak` VALUES ('004A770211030685', '', '004A770211030685', '', '2018-12-21 16:00:09', '2019-01-10 16:49:54', 'kickoff2019', null, '155', '1', '1', '3', '69');
INSERT INTO `device-bak` VALUES ('004A770211030686', '', '004A770211030686', '', '2018-12-21 16:00:09', '2019-01-10 16:53:24', 'kickoff2019', '14', '155', '0', '1', '3', '166');
INSERT INTO `device-bak` VALUES ('004A770211030687', '', '004A770211030687', '', '2018-12-21 16:00:09', '2019-01-10 16:49:42', 'kickoff2019', null, '155', '1', '1', '3', '215');
INSERT INTO `device-bak` VALUES ('004A770211030688', '', '004A770211030688', '', '2018-12-21 16:00:09', '2019-01-10 16:50:25', 'kickoff2019', '14', '155', '0', '1', '3', '98');
INSERT INTO `device-bak` VALUES ('004A770211030689', '', '004A770211030689', '', '2018-12-21 16:00:09', '2019-01-10 16:48:12', 'kickoff2019', '14', '155', '0', '1', '3', '244');
INSERT INTO `device-bak` VALUES ('004A77021103068A', '', '004A77021103068A', '', '2018-12-21 16:00:09', '2019-01-10 16:50:23', 'kickoff2019', '14', '155', '0', '1', '3', '47');
INSERT INTO `device-bak` VALUES ('004A77021103068B', '', '004A77021103068B', '', '2018-12-21 16:00:09', '2019-01-10 16:48:42', 'kickoff2019', '14', '155', '0', '1', '3', '96');
INSERT INTO `device-bak` VALUES ('004A77021103068C', '', '004A77021103068C', '', '2018-12-21 16:00:09', '2019-01-10 16:47:24', 'kickoff2019', '14', '155', '0', '1', '3', '448');
INSERT INTO `device-bak` VALUES ('004A77021103068D', '', '004A77021103068D', '', '2018-12-21 16:00:09', '2019-01-10 16:51:05', 'kickoff2019', null, '155', '1', '1', '3', '179');
INSERT INTO `device-bak` VALUES ('004A77021103068E', '', '004A77021103068E', '', '2018-12-21 16:00:09', '2019-01-10 16:46:53', 'kickoff2019', '14', '155', '0', '1', '3', '203');
INSERT INTO `device-bak` VALUES ('004A77021103068F', '', '004A77021103068F', '', '2018-12-21 16:00:09', '2019-01-10 16:49:50', 'kickoff2019', '14', '155', '0', '1', '3', '86');
INSERT INTO `device-bak` VALUES ('004A770211030690', '', '004A770211030690', '', '2018-12-21 16:00:09', '2019-01-10 16:52:27', 'kickoff2019', '14', '155', '0', '1', '3', '494');

-- ----------------------------
-- Table structure for device_copy
-- ----------------------------
DROP TABLE IF EXISTS `device_copy`;
CREATE TABLE `device_copy` (
  `id` varchar(50) NOT NULL COMMENT 'ID',
  `rfid` varchar(255) DEFAULT NULL,
  `dev_id` varchar(50) NOT NULL COMMENT '设备EUI,devId',
  `alias` varchar(50) DEFAULT NULL COMMENT '设备别名',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_at` datetime DEFAULT NULL COMMENT '更新时间',
  `indoor_map_id` varchar(100) NOT NULL COMMENT '所属楼层',
  `major` int(255) DEFAULT NULL COMMENT '最近信标major',
  `minor` int(255) DEFAULT NULL COMMENT '最近信标minor',
  `is_offline` int(11) DEFAULT NULL COMMENT '1离线，2在线',
  `is_move` int(11) DEFAULT NULL COMMENT '设备是否移动，1是0否',
  `device_color` varchar(255) DEFAULT NULL COMMENT '卡的颜色,组别,就是user_group_id',
  `step_counter` int(11) DEFAULT NULL COMMENT '计步器',
  PRIMARY KEY (`dev_id`,`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设备';

-- ----------------------------
-- Records of device_copy
-- ----------------------------
INSERT INTO `device_copy` VALUES ('000000000000000x', '02E200447B8650', '000000000000000x', '', '2018-12-21 16:00:09', '2019-01-14 18:39:24', 'kickoff2019', null, null, '0', '1', '1', '2019');
INSERT INTO `device_copy` VALUES ('0000000011030565', 'E0022301DE1600A2', '0000000011030565', '', '2018-12-21 16:00:09', '2019-01-15 14:41:28', 'kickoff2019', '14', '161', '0', '1', '1', '2978');
INSERT INTO `device_copy` VALUES ('0000000011030566', '', '0000000011030566', '', '2018-12-21 16:00:09', '2019-01-15 14:24:52', 'kickoff2019', '14', '161', '0', '0', '1', '2435');
INSERT INTO `device_copy` VALUES ('0000000011030567', '', '0000000011030567', '', '2018-12-21 16:00:09', '2019-01-15 14:25:21', 'kickoff2019', '14', '161', '0', '0', '1', '688');
INSERT INTO `device_copy` VALUES ('0000000011030568', '', '0000000011030568', '', '2018-12-21 16:00:09', '2019-01-15 14:46:48', 'kickoff2019', '14', '161', '0', '0', '1', '1536');
INSERT INTO `device_copy` VALUES ('0000000011030569', '', '0000000011030569', '', '2018-12-21 16:00:09', '2019-01-15 14:47:05', 'kickoff2019', '14', '161', '0', '0', '1', '1815');
INSERT INTO `device_copy` VALUES ('000000001103056A', '', '000000001103056A', '', '2018-12-21 16:00:09', '2019-01-15 14:47:11', 'kickoff2019', '14', '161', '0', '1', '1', '1245');
INSERT INTO `device_copy` VALUES ('000000001103056B', '', '000000001103056B', '', '2018-12-21 16:00:09', '2019-01-15 14:46:42', 'kickoff2019', '14', '161', '0', '1', '1', '2125');
INSERT INTO `device_copy` VALUES ('000000001103056C', '', '000000001103056C', '', '2018-12-21 16:00:09', '2019-01-15 14:48:20', 'kickoff2019', '14', '161', '0', '0', '1', '485');
INSERT INTO `device_copy` VALUES ('000000001103056D', '', '000000001103056D', '', '2018-12-21 16:00:09', '2019-01-15 14:47:54', 'kickoff2019', '14', '161', '0', '0', '1', '1379');
INSERT INTO `device_copy` VALUES ('000000001103056E', '', '000000001103056E', '', '2018-12-21 16:00:09', '2019-01-15 14:47:11', 'kickoff2019', '14', '161', '0', '0', '1', '1192');
INSERT INTO `device_copy` VALUES ('000000001103056F', '', '000000001103056F', '', '2018-12-21 16:00:09', '2019-01-15 14:34:06', 'kickoff2019', '14', '161', '0', '0', '1', '498');
INSERT INTO `device_copy` VALUES ('0000000011030570', '', '0000000011030570', '', '2018-12-21 16:00:09', '2019-01-15 14:34:18', 'kickoff2019', '14', '161', '0', '1', '1', '337');
INSERT INTO `device_copy` VALUES ('0000000011030571', '', '0000000011030571', '', '2018-12-21 16:00:09', '2019-01-15 14:43:35', 'kickoff2019', null, '252', '1', '0', '1', '455');
INSERT INTO `device_copy` VALUES ('0000000011030572', '', '0000000011030572', '', '2018-12-21 16:00:09', '2019-01-15 14:43:35', 'kickoff2019', null, '161', '1', '0', '1', '6');
INSERT INTO `device_copy` VALUES ('0000000011030573', '', '0000000011030573', '', '2018-12-21 16:00:09', '2019-01-14 22:05:44', 'kickoff2019', null, '252', '1', '0', '1', '572');
INSERT INTO `device_copy` VALUES ('0000000011030574', '', '0000000011030574', '', '2018-12-21 16:00:09', '2019-01-14 22:05:44', 'kickoff2019', null, '252', '1', '0', '1', '317');
INSERT INTO `device_copy` VALUES ('0000000011030575', '', '0000000011030575', '', '2018-12-21 16:00:09', '2019-01-15 14:43:35', 'kickoff2019', null, '252', '1', '0', '1', '406');
INSERT INTO `device_copy` VALUES ('0000000011030576', '', '0000000011030576', '', '2018-12-21 16:00:09', '2019-01-15 14:44:18', 'kickoff2019', '14', '161', '0', '1', '1', '6');
INSERT INTO `device_copy` VALUES ('0000000011030577', '', '0000000011030577', '', '2018-12-21 16:00:09', '2019-01-15 14:43:35', 'kickoff2019', null, '252', '1', '0', '1', '11');
INSERT INTO `device_copy` VALUES ('0000000011030578', '', '0000000011030578', '', '2018-12-21 16:00:09', '2019-01-15 14:47:11', 'kickoff2019', '14', '161', '0', '1', '1', '361');
INSERT INTO `device_copy` VALUES ('0000000011030579', '', '0000000011030579', '', '2018-12-21 16:00:09', '2019-01-14 22:00:44', 'kickoff2019', null, '252', '1', '1', '1', '141');
INSERT INTO `device_copy` VALUES ('000000001103057A', '', '000000001103057A', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '0', '1', '285');
INSERT INTO `device_copy` VALUES ('000000001103057B', '', '000000001103057B', '', '2018-12-21 16:00:09', '2019-01-14 22:00:44', 'kickoff2019', null, '252', '1', '0', '1', '251');
INSERT INTO `device_copy` VALUES ('000000001103057C', '', '000000001103057C', '', '2018-12-21 16:00:09', '2019-01-14 22:00:44', 'kickoff2019', null, '252', '1', '0', '1', '255');
INSERT INTO `device_copy` VALUES ('000000001103057D', '', '000000001103057D', '', '2018-12-21 16:00:09', '2019-01-14 22:00:44', 'kickoff2019', null, '252', '1', '0', '1', '166');
INSERT INTO `device_copy` VALUES ('000000001103057E', '', '000000001103057F', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '1', '1', '221');
INSERT INTO `device_copy` VALUES ('000000001103057F', '', '0000000011030580', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', '14', '161', '1', '0', '1', '208');
INSERT INTO `device_copy` VALUES ('0000000011030580', '', '0000000011030581', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '1', '1', '324');
INSERT INTO `device_copy` VALUES ('0000000011030581', '', '0000000011030582', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '1', '1', '322');
INSERT INTO `device_copy` VALUES ('0000000011030582', '', '0000000011030583', '', '2018-12-21 16:00:09', '2019-01-15 14:45:44', 'kickoff2019', '14', '161', '0', '0', '1', '5');
INSERT INTO `device_copy` VALUES ('0000000011030583', '', '0000000011030584', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '0', '1', '387');
INSERT INTO `device_copy` VALUES ('0000000011030584', '', '0000000011030585', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '1', '1', '17');
INSERT INTO `device_copy` VALUES ('0000000011030585', '', '0000000011030586', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '0', '1', '18');
INSERT INTO `device_copy` VALUES ('0000000011030586', '', '0000000011030587', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '1', '1', '18');
INSERT INTO `device_copy` VALUES ('0000000011030587', '', '0000000011030588', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '0', '1', '17');
INSERT INTO `device_copy` VALUES ('0000000011030588', '', '0000000011030589', '', '2018-12-21 16:00:09', '2019-01-15 14:33:35', 'kickoff2019', '14', '161', '1', '1', '1', '13');
INSERT INTO `device_copy` VALUES ('0000000011030589', '', '000000001103058A', '', '2018-12-21 16:00:09', '2019-01-15 14:11:07', 'kickoff2019', '14', '161', '0', '1', '1', '320');
INSERT INTO `device_copy` VALUES ('000000001103058A', '', '000000001103058B', '', '2018-12-21 16:00:09', '2019-01-15 14:44:43', 'kickoff2019', '14', '161', '0', '1', '1', '9');
INSERT INTO `device_copy` VALUES ('000000001103058B', '', '000000001103058C', '', '2018-12-21 16:00:09', '2019-01-14 22:20:43', 'kickoff2019', null, '252', '1', '0', '1', '261');
INSERT INTO `device_copy` VALUES ('000000001103058C', '', '000000001103058D', '', '2018-12-21 16:00:09', '2019-01-15 14:18:40', 'kickoff2019', '14', '161', '0', '0', '1', '29');
INSERT INTO `device_copy` VALUES ('000000001103058D', '', '000000001103058E', '', '2018-12-21 16:00:09', '2019-01-15 14:13:29', 'kickoff2019', '14', '161', '0', '0', '1', '183');
INSERT INTO `device_copy` VALUES ('000000001103058E', '', '000000001103058F', '', '2018-12-21 16:00:09', '2019-01-15 14:29:24', 'kickoff2019', '14', '161', '0', '0', '1', '194');
INSERT INTO `device_copy` VALUES ('000000001103058F', '', '0000000011030590', '', '2018-12-21 16:00:09', '2019-01-15 14:33:57', 'kickoff2019', '14', '161', '0', '0', '1', '11');
INSERT INTO `device_copy` VALUES ('0000000011030590', '', '0000000011030591', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '0', '1', '25');
INSERT INTO `device_copy` VALUES ('0000000011030591', '', '0000000011030592', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '1', '1', '30');
INSERT INTO `device_copy` VALUES ('0000000011030592', '', '0000000011030593', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '0', '1', '15');
INSERT INTO `device_copy` VALUES ('0000000011030593', '', '0000000011030594', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '0', '1', '17');
INSERT INTO `device_copy` VALUES ('0000000011030594', '', '0000000011030595', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '0', '1', '28');
INSERT INTO `device_copy` VALUES ('0000000011030595', '', '0000000011030596', '', '2018-12-21 16:00:09', '2019-01-15 14:43:36', 'kickoff2019', null, '161', '1', '1', '1', '28');
INSERT INTO `device_copy` VALUES ('0000000011030596', '', '0000000011030597', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '0', '1', '89');
INSERT INTO `device_copy` VALUES ('0000000011030597', '', '0000000011030598', '', '2018-12-21 16:00:09', '2019-01-14 22:00:44', 'kickoff2019', null, '252', '1', '0', '1', '174');
INSERT INTO `device_copy` VALUES ('0000000011030598', '', '0000000011030599', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '0', '1', '114');
INSERT INTO `device_copy` VALUES ('0000000011030599', '', '000000001103059A', '', '2018-12-21 16:00:09', '2019-01-14 22:00:44', 'kickoff2019', '14', '161', '1', '0', '1', '170');
INSERT INTO `device_copy` VALUES ('000000001103059A', '', '000000001103059B', '', '2018-12-21 16:00:09', '2019-01-14 22:00:44', 'kickoff2019', null, '252', '1', '1', '1', '128');
INSERT INTO `device_copy` VALUES ('000000001103059B', '', '000000001103059C', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '0', '1', '230');
INSERT INTO `device_copy` VALUES ('000000001103059C', '', '000000001103059D', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '0', '1', '147');
INSERT INTO `device_copy` VALUES ('000000001103059D', '', '000000001103059E', '', '2018-12-21 16:00:09', '2019-01-14 22:00:45', 'kickoff2019', null, '252', '1', '0', '1', '128');
INSERT INTO `device_copy` VALUES ('000000001103059E', '', '000000001103059F', '', '2018-12-21 16:00:09', '2019-01-14 22:00:45', 'kickoff2019', null, '252', '1', '0', '1', '202');
INSERT INTO `device_copy` VALUES ('000000001103059F', '', '00000000110305A0', '', '2018-12-21 16:00:09', '2019-01-14 21:50:44', 'kickoff2019', null, '252', '1', '0', '1', '223');
INSERT INTO `device_copy` VALUES ('00000000110305A0', '', '00000000110305A1', '', '2018-12-21 16:00:09', '2019-01-15 14:46:21', 'kickoff2019', '14', '161', '0', '0', '1', '99');
INSERT INTO `device_copy` VALUES ('00000000110305A1', '', '00000000110305A2', '', '2018-12-21 16:00:09', '2019-01-15 14:39:35', 'kickoff2019', '14', '161', '0', '1', '1', '11');
INSERT INTO `device_copy` VALUES ('00000000110305A2', '', '00000000110305A3', '', '2018-12-21 16:00:09', '2019-01-15 14:46:28', 'kickoff2019', '14', '161', '0', '0', '1', '90');
INSERT INTO `device_copy` VALUES ('00000000110305A3', '', '00000000110305A4', '', '2018-12-21 16:00:09', '2019-01-15 14:16:12', 'kickoff2019', '14', '161', '0', '1', '1', '118');
INSERT INTO `device_copy` VALUES ('00000000110305A4', '', '00000000110305A5', '', '2018-12-21 16:00:09', '2019-01-15 14:46:22', 'kickoff2019', '14', '161', '0', '0', '1', '12');
INSERT INTO `device_copy` VALUES ('00000000110305A5', '', '00000000110305A6', '', '2018-12-21 16:00:09', '2019-01-15 14:16:12', 'kickoff2019', '14', '161', '0', '1', '1', '86');
INSERT INTO `device_copy` VALUES ('00000000110305A6', '', '00000000110305A7', '', '2018-12-21 16:00:09', '2019-01-15 14:46:00', 'kickoff2019', '14', '161', '0', '0', '1', '7');
INSERT INTO `device_copy` VALUES ('00000000110305A7', '', '00000000110305A8', '', '2018-12-21 16:00:09', '2019-01-15 14:24:46', 'kickoff2019', '14', '161', '0', '0', '1', '15');
INSERT INTO `device_copy` VALUES ('00000000110305A8', '', '00000000110305A9', '', '2018-12-21 16:00:09', '2019-01-15 14:24:25', 'kickoff2019', '14', '161', '0', '0', '1', '8');
INSERT INTO `device_copy` VALUES ('00000000110305A9', '', '00000000110305AA', '', '2018-12-21 16:00:09', '2019-01-15 14:16:18', 'kickoff2019', '14', '161', '0', '0', '1', '169');
INSERT INTO `device_copy` VALUES ('00000000110305AA', '', '00000000110305AB', '', '2018-12-21 16:00:09', '2019-01-15 14:12:37', 'kickoff2019', null, '252', '1', '0', '1', '114');
INSERT INTO `device_copy` VALUES ('00000000110305AB', '', '00000000110305AD', '', '2018-12-21 16:00:09', '2019-01-15 14:12:37', 'kickoff2019', '14', '161', '1', '1', '1', '117');
INSERT INTO `device_copy` VALUES ('00000000110305AC', '', '00000000110305AE', '', '2018-12-21 16:00:09', '2019-01-15 14:09:36', 'kickoff2019', '14', '161', '0', '1', '1', '50');
INSERT INTO `device_copy` VALUES ('00000000110305AD', '', '00000000110305AF', '', '2018-12-21 16:00:09', '2019-01-15 14:16:07', 'kickoff2019', '14', '161', '0', '0', '1', '87');
INSERT INTO `device_copy` VALUES ('00000000110305AE', '', '00000000110305B0', '', '2018-12-21 16:00:09', '2019-01-15 14:15:58', 'kickoff2019', '14', '161', '0', '0', '1', '57');
INSERT INTO `device_copy` VALUES ('00000000110305AF', '', '00000000110305B1', '', '2018-12-21 16:00:09', '2019-01-15 14:12:37', 'kickoff2019', null, '252', '1', '0', '1', '61');
INSERT INTO `device_copy` VALUES ('00000000110305B0', '', '00000000110305B2', '', '2018-12-21 16:00:09', '2019-01-15 14:12:37', 'kickoff2019', null, '252', '1', '0', '1', '48');
INSERT INTO `device_copy` VALUES ('00000000110305B1', '', '00000000110305B3', '', '2018-12-21 16:00:09', '2019-01-15 14:47:48', 'kickoff2019', '14', '161', '0', '1', '1', '50');
INSERT INTO `device_copy` VALUES ('00000000110305B2', '', '00000000110305B4', '', '2018-12-21 16:00:09', '2019-01-15 14:45:54', 'kickoff2019', '14', '161', '0', '0', '1', '107');
INSERT INTO `device_copy` VALUES ('00000000110305B3', '', '00000000110305B5', '', '2018-12-21 16:00:09', '2019-01-15 14:46:08', 'kickoff2019', '14', '161', '0', '0', '1', '7');
INSERT INTO `device_copy` VALUES ('00000000110305B4', '', '00000000110305B6', '', '2018-12-21 16:00:09', '2019-01-15 14:18:07', 'kickoff2019', '14', '161', '1', '1', '1', '8');
INSERT INTO `device_copy` VALUES ('00000000110305B5', '', '00000000110305B7', '', '2018-12-21 16:00:09', '2019-01-15 14:18:07', 'kickoff2019', null, '252', '1', '0', '1', '165');
INSERT INTO `device_copy` VALUES ('00000000110305B6', '', '00000000110305B8', '', '2018-12-21 16:00:09', '2019-01-15 14:18:07', 'kickoff2019', '14', '161', '1', '1', '1', '8');
INSERT INTO `device_copy` VALUES ('00000000110305B7', '', '00000000110305B9', '', '2018-12-21 16:00:09', '2019-01-15 14:18:07', 'kickoff2019', '14', '161', '1', '0', '1', '78');
INSERT INTO `device_copy` VALUES ('00000000110305B8', '', '00000000110305BA', '', '2018-12-21 16:00:09', '2019-01-15 14:18:07', 'kickoff2019', null, '252', '1', '0', '1', '122');
INSERT INTO `device_copy` VALUES ('00000000110305B9', '', '00000000110305BB', '', '2018-12-21 16:00:09', '2019-01-15 14:18:07', 'kickoff2019', '14', '161', '1', '1', '1', '95');
INSERT INTO `device_copy` VALUES ('00000000110305BA', '', '00000000110305BC', '', '2018-12-21 16:00:09', '2019-01-15 14:18:07', 'kickoff2019', null, '252', '1', '0', '1', '87');
INSERT INTO `device_copy` VALUES ('00000000110305BB', '', '00000000110305BD', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', null, '252', '1', '0', '1', '104');
INSERT INTO `device_copy` VALUES ('00000000110305BC', '', '00000000110305BE', '', '2018-12-21 16:00:09', '2019-01-15 14:17:30', 'kickoff2019', '14', '161', '0', '0', '1', '7');
INSERT INTO `device_copy` VALUES ('00000000110305BD', '', '00000000110305BF', '', '2018-12-21 16:00:09', '2019-01-15 14:10:37', 'kickoff2019', '14', '161', '0', '0', '1', '307');
INSERT INTO `device_copy` VALUES ('00000000110305BE', '', '00000000110305C0', '', '2018-12-21 16:00:09', '2019-01-15 14:37:21', 'kickoff2019', '14', '161', '0', '1', '1', '173');
INSERT INTO `device_copy` VALUES ('00000000110305BF', '', '00000000110305C1', '', '2018-12-21 16:00:09', '2019-01-15 14:41:35', 'kickoff2019', '14', '161', '0', '1', '1', '147');
INSERT INTO `device_copy` VALUES ('00000000110305C0', '', '00000000110305C2', '', '2018-12-21 16:00:09', '2019-01-15 14:13:06', 'kickoff2019', null, '252', '1', '0', '1', '168');
INSERT INTO `device_copy` VALUES ('00000000110305C1', '', '00000000110305C3', '', '2018-12-21 16:00:09', '2019-01-15 14:18:00', 'kickoff2019', '14', '161', '0', '0', '1', '111');
INSERT INTO `device_copy` VALUES ('00000000110305C2', '', '00000000110305C4', '', '2018-12-21 16:00:09', '2019-01-15 14:09:06', 'kickoff2019', '14', '161', '0', '0', '1', '130');
INSERT INTO `device_copy` VALUES ('00000000110305C3', '', '00000000110305C5', '', '2018-12-21 16:00:09', '2019-01-15 14:46:14', 'kickoff2019', '14', '161', '0', '0', '1', '217');
INSERT INTO `device_copy` VALUES ('00000000110305C4', '', '00000000110305C6', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', null, '252', '1', '0', '1', '110');
INSERT INTO `device_copy` VALUES ('00000000110305C5', '', '00000000110305C7', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', null, '252', '1', '0', '1', '166');
INSERT INTO `device_copy` VALUES ('00000000110305C6', '', '00000000110305C8', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', '14', '161', '1', '1', '1', '206');
INSERT INTO `device_copy` VALUES ('00000000110305C7', '', '00000000110305C9', '', '2018-12-21 16:00:09', '2019-01-15 14:43:27', 'kickoff2019', '14', '161', '0', '1', '2', '54');
INSERT INTO `device_copy` VALUES ('00000000110305C8', '', '00000000110305CA', '', '2018-12-21 16:00:09', '2019-01-15 14:47:28', 'kickoff2019', '14', '161', '0', '0', '2', '46');
INSERT INTO `device_copy` VALUES ('00000000110305C9', '', '00000000110305CC', '', '2018-12-21 16:00:09', '2019-01-14 22:00:46', 'kickoff2019', null, '252', '1', '0', '2', '837');
INSERT INTO `device_copy` VALUES ('00000000110305CA', '', '00000000110305CD', '', '2018-12-21 16:00:09', '2019-01-15 14:15:43', 'kickoff2019', '14', '161', '0', '1', '2', '6');
INSERT INTO `device_copy` VALUES ('00000000110305CB', '', '00000000110305CE', '', '2018-12-21 16:00:09', '2019-01-14 22:00:46', 'kickoff2019', null, '252', '1', '0', '2', '450');
INSERT INTO `device_copy` VALUES ('00000000110305CC', '', '00000000110305CF', '', '2018-12-21 16:00:09', '2019-01-14 22:00:46', 'kickoff2019', null, '252', '1', '0', '2', '585');
INSERT INTO `device_copy` VALUES ('00000000110305CD', '', '00000000110305D0', '', '2018-12-21 16:00:09', '2019-01-15 14:15:47', 'kickoff2019', null, '252', '1', '0', '2', '12');
INSERT INTO `device_copy` VALUES ('00000000110305CE', '', '00000000110305D1', '', '2018-12-21 16:00:09', '2019-01-14 22:00:46', 'kickoff2019', null, '252', '1', '0', '2', '410');
INSERT INTO `device_copy` VALUES ('00000000110305CF', '', '00000000110305D2', '', '2018-12-21 16:00:09', '2019-01-15 14:47:16', 'kickoff2019', '14', '161', '0', '1', '2', '35');
INSERT INTO `device_copy` VALUES ('00000000110305D0', '', '00000000110305D3', '', '2018-12-21 16:00:09', '2019-01-15 14:19:06', 'kickoff2019', '14', '161', '0', '0', '2', '5');
INSERT INTO `device_copy` VALUES ('00000000110305D1', '', '00000000110305D4', '', '2018-12-21 16:00:09', '2019-01-15 14:15:43', 'kickoff2019', '14', '161', '0', '1', '2', '115');
INSERT INTO `device_copy` VALUES ('00000000110305D2', '', '00000000110305D5', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', null, '252', '1', '0', '2', '119');
INSERT INTO `device_copy` VALUES ('00000000110305D3', '', '00000000110305D6', '', '2018-12-21 16:00:09', '2019-01-15 14:45:20', 'kickoff2019', '14', '161', '0', '1', '2', '5');
INSERT INTO `device_copy` VALUES ('00000000110305D4', '', '00000000110305D7', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', null, '252', '1', '0', '2', '110');
INSERT INTO `device_copy` VALUES ('00000000110305D5', '', '00000000110305D8', '', '2018-12-21 16:00:09', '2019-01-15 14:17:20', 'kickoff2019', '14', '161', '0', '1', '2', '6');
INSERT INTO `device_copy` VALUES ('00000000110305D6', '', '00000000110305D9', '', '2018-12-21 16:00:09', '2019-01-15 14:47:16', 'kickoff2019', '14', '161', '0', '1', '2', '6');
INSERT INTO `device_copy` VALUES ('00000000110305D7', '', '00000000110305DA', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', null, '252', '1', '0', '2', '95');
INSERT INTO `device_copy` VALUES ('00000000110305D8', '', '00000000110305DC', '', '2018-12-21 16:00:09', '2019-01-15 14:47:38', 'kickoff2019', '14', '161', '0', '1', '2', '117');
INSERT INTO `device_copy` VALUES ('00000000110305D9', '', '00000000110305DD', '', '2018-12-21 16:00:09', '2019-01-15 14:46:53', 'kickoff2019', '14', '161', '0', '1', '2', '14');
INSERT INTO `device_copy` VALUES ('00000000110305DA', '', '00000000110305DE', '', '2018-12-21 16:00:09', '2019-01-15 14:24:46', 'kickoff2019', '14', '161', '0', '0', '2', '12');
INSERT INTO `device_copy` VALUES ('00000000110305DB', '', '00000000110305DF', '', '2018-12-21 16:00:09', '2019-01-15 14:13:39', 'kickoff2019', '14', '161', '0', '0', '2', '13');
INSERT INTO `device_copy` VALUES ('00000000110305DC', '', '00000000110305E0', '', '2018-12-21 16:00:09', '2019-01-15 14:13:02', 'kickoff2019', '14', '161', '0', '1', '2', '524');
INSERT INTO `device_copy` VALUES ('00000000110305DD', '', '00000000110305E1', '', '2018-12-21 16:00:09', '2019-01-15 14:25:05', 'kickoff2019', '14', '161', '0', '0', '2', '765');
INSERT INTO `device_copy` VALUES ('00000000110305DE', '', '00000000110305E3', '', '2018-12-21 16:00:09', '2019-01-15 14:46:00', 'kickoff2019', '14', '161', '0', '1', '2', '16');
INSERT INTO `device_copy` VALUES ('00000000110305DF', '', '00000000110305E4', '', '2018-12-21 16:00:09', '2019-01-14 22:00:47', 'kickoff2019', null, '252', '1', '0', '2', '416');
INSERT INTO `device_copy` VALUES ('00000000110305E0', '', '00000000110305E5', '', '2018-12-21 16:00:09', '2019-01-15 14:25:21', 'kickoff2019', '14', '161', '0', '1', '2', '410');
INSERT INTO `device_copy` VALUES ('00000000110305E1', '', '00000000110305E6', '', '2018-12-21 16:00:09', '2019-01-15 14:47:38', 'kickoff2019', '14', '161', '0', '1', '2', '32');
INSERT INTO `device_copy` VALUES ('00000000110305E2', '', '00000000110305E7', '', '2018-12-21 16:00:09', '2019-01-15 14:48:20', 'kickoff2019', '14', '161', '0', '1', '2', '40');
INSERT INTO `device_copy` VALUES ('00000000110305E3', '', '00000000110305E8', '', '2018-12-21 16:00:09', '2019-01-15 14:48:15', 'kickoff2019', '14', '161', '0', '1', '2', '361');
INSERT INTO `device_copy` VALUES ('00000000110305E4', '', '00000000110305E9', '', '2018-12-21 16:00:09', '2019-01-15 14:11:57', 'kickoff2019', '14', '161', '0', '1', '2', '20');
INSERT INTO `device_copy` VALUES ('00000000110305E5', '', '00000000110305EA', '', '2018-12-21 16:00:09', '2019-01-15 14:17:30', 'kickoff2019', '14', '161', '0', '0', '2', '17');
INSERT INTO `device_copy` VALUES ('00000000110305E6', '', '00000000110305EB', '', '2018-12-21 16:00:09', '2019-01-14 22:20:43', 'kickoff2019', null, '252', '1', '0', '2', '435');
INSERT INTO `device_copy` VALUES ('00000000110305E7', '', '00000000110305EC', '', '2018-12-21 16:00:09', '2019-01-14 22:20:43', 'kickoff2019', null, '252', '1', '0', '2', '400');
INSERT INTO `device_copy` VALUES ('00000000110305E8', '', '00000000110305ED', '', '2018-12-21 16:00:09', '2019-01-15 14:12:00', 'kickoff2019', '14', '161', '0', '1', '2', '11');
INSERT INTO `device_copy` VALUES ('00000000110305E9', '', '00000000110305EE', '', '2018-12-21 16:00:09', '2019-01-15 14:47:28', 'kickoff2019', '14', '161', '0', '0', '2', '411');
INSERT INTO `device_copy` VALUES ('00000000110305EA', '', '00000000110305EF', '', '2018-12-21 16:00:09', '2019-01-15 14:11:55', 'kickoff2019', '14', '161', '0', '1', '2', '17');
INSERT INTO `device_copy` VALUES ('00000000110305EB', '', '00000000110305F0', '', '2018-12-21 16:00:09', '2019-01-15 14:46:28', 'kickoff2019', '14', '161', '0', '0', '2', '15');
INSERT INTO `device_copy` VALUES ('00000000110305EC', '', '00000000110305F1', '', '2018-12-21 16:00:09', '2019-01-15 14:25:42', 'kickoff2019', '14', '161', '0', '0', '2', '231');
INSERT INTO `device_copy` VALUES ('00000000110305ED', '', '00000000110305F2', '', '2018-12-21 16:00:09', '2019-01-15 14:16:27', 'kickoff2019', '14', '161', '0', '0', '2', '399');
INSERT INTO `device_copy` VALUES ('00000000110305EE', '', '00000000110305F3', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', '14', '161', '1', '1', '2', '175');
INSERT INTO `device_copy` VALUES ('00000000110305EF', '', '00000000110305F4', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', '14', '161', '1', '1', '2', '365');
INSERT INTO `device_copy` VALUES ('00000000110305F0', '', '00000000110305F5', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', null, '252', '1', '0', '2', '377');
INSERT INTO `device_copy` VALUES ('00000000110305F1', '', '00000000110305F6', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', '14', '161', '1', '1', '2', '260');
INSERT INTO `device_copy` VALUES ('00000000110305F2', '', '00000000110305F7', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', '14', '161', '1', '1', '2', '5');
INSERT INTO `device_copy` VALUES ('00000000110305F3', '', '00000000110305F8', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', '14', '161', '1', '0', '2', '280');
INSERT INTO `device_copy` VALUES ('00000000110305F4', '', '00000000110305F9', '', '2018-12-21 16:00:09', '2019-01-15 14:18:08', 'kickoff2019', '14', '161', '1', '1', '2', '283');
INSERT INTO `device_copy` VALUES ('00000000110305F5', '', '00000000110305FA', '', '2018-12-21 16:00:09', '2019-01-15 14:34:18', 'kickoff2019', '14', '161', '0', '0', '2', '230');
INSERT INTO `device_copy` VALUES ('00000000110305F6', '', '00000000110305FB', '', '2018-12-21 16:00:09', '2019-01-15 14:12:37', 'kickoff2019', '14', '161', '0', '0', '2', '24');
INSERT INTO `device_copy` VALUES ('00000000110305F7', '', '00000000110305FC', '', '2018-12-21 16:00:09', '2019-01-15 14:35:53', 'kickoff2019', '14', '161', '0', '1', '2', '5');
INSERT INTO `device_copy` VALUES ('00000000110305F8', '', '00000000110305FD', '', '2018-12-21 16:00:09', '2019-01-15 14:43:20', 'kickoff2019', '14', '161', '0', '1', '2', '12');
INSERT INTO `device_copy` VALUES ('00000000110305F9', '', '00000000110305FE', '', '2018-12-21 16:00:09', '2019-01-15 14:46:53', 'kickoff2019', '14', '161', '0', '0', '2', '6');
INSERT INTO `device_copy` VALUES ('00000000110305FA', '', '00000000110305FF', '', '2018-12-21 16:00:09', '2019-01-15 14:24:40', 'kickoff2019', '14', '161', '0', '0', '2', '11');

-- ----------------------------
-- Table structure for function_dep
-- ----------------------------
DROP TABLE IF EXISTS `function_dep`;
CREATE TABLE `function_dep` (
  `id` varchar(100) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of function_dep
-- ----------------------------
INSERT INTO `function_dep` VALUES ('10051001', 'ChiP');
INSERT INTO `function_dep` VALUES ('10051002', 'DonP');
INSERT INTO `function_dep` VALUES ('10051004', 'NiP');
INSERT INTO `function_dep` VALUES ('10051005', 'PE-BE');
INSERT INTO `function_dep` VALUES ('10051006', 'PgP2');
INSERT INTO `function_dep` VALUES ('10051007', 'PT');
INSERT INTO `function_dep` VALUES ('10051008', 'PT-AC');
INSERT INTO `function_dep` VALUES ('10051009', 'PT-BE');
INSERT INTO `function_dep` VALUES ('10051010', 'PT-BI');
INSERT INTO `function_dep` VALUES ('10051011', 'PT-HG');
INSERT INTO `function_dep` VALUES ('10051012', 'PT-MT');
INSERT INTO `function_dep` VALUES ('10051013', 'PT-RT');
INSERT INTO `function_dep` VALUES ('10051014', 'PTCN');
INSERT INTO `function_dep` VALUES ('10051015', 'PujP');
INSERT INTO `function_dep` VALUES ('10051016', 'RBCN');
INSERT INTO `function_dep` VALUES ('10051017', 'FIXED-TERM Dremel AP');
INSERT INTO `function_dep` VALUES ('10051018', 'Staff');
INSERT INTO `function_dep` VALUES ('10051019', 'safetyHat');

-- ----------------------------
-- Table structure for indoor_map
-- ----------------------------
DROP TABLE IF EXISTS `indoor_map`;
CREATE TABLE `indoor_map` (
  `id` varchar(50) NOT NULL COMMENT 'ID',
  `image` varchar(255) DEFAULT NULL COMMENT '图片路径',
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_at` datetime DEFAULT NULL COMMENT '更新时间',
  `map_id` varchar(100) NOT NULL COMMENT '楼层名称',
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='室内地图';

-- ----------------------------
-- Records of indoor_map
-- ----------------------------
INSERT INTO `indoor_map` VALUES ('1076360529225846783', '/ISiteImg/KF19_Floor_Plan_TR_Final_17.svg', '2018-12-22 14:15:23', '2018-12-22 14:36:56', 'kickoff2019', '595', '841');
INSERT INTO `indoor_map` VALUES ('1076360529225846784', '/ISiteImg/KF19_Floor_Plan_TR_Final_18_Morning11.svg', '2018-12-22 14:15:23', '2018-12-22 14:36:56', 'kickoff2019', '595', '841');
INSERT INTO `indoor_map` VALUES ('1076360529225846785', '/ISiteImg/KF19_Floor_Plan_TR_Final_18_Rotation_11.svg', '2018-09-12 08:54:15', '2018-09-14 15:22:14', 'kickoff2019', '595', '841');
INSERT INTO `indoor_map` VALUES ('1076360529225846786', '/ISiteImg/KF19_Floor_Plan_TR_Final_18_Rotation_2.svg', '2018-09-12 08:54:15', '2018-09-14 15:22:14', 'kickoff2019', '595', '841');
INSERT INTO `indoor_map` VALUES ('1076360529225846787', '/ISiteImg/KF19_Floor_Plan_TR_Final_18_Rotation_3.svg', '2018-09-12 08:54:15', '2018-09-14 15:22:14', 'kickoff2019', '595', '841');

-- ----------------------------
-- Table structure for indoor_map_bound
-- ----------------------------
DROP TABLE IF EXISTS `indoor_map_bound`;
CREATE TABLE `indoor_map_bound` (
  `id` varchar(50) NOT NULL,
  `map_id` varchar(50) DEFAULT NULL,
  `create_at` datetime DEFAULT NULL COMMENT '创建时间',
  `update_at` datetime DEFAULT NULL COMMENT '更新时间',
  `indoor_map_bound_arr_str` mediumtext COMMENT '存储画图路径的数组字符串',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of indoor_map_bound
-- ----------------------------
INSERT INTO `indoor_map_bound` VALUES ('1076374954993389568', 'kickoff2019', '2018-12-22 14:34:17', '2019-01-04 15:07:15', '[{\"lat\":7.5822285881151075,\"lon\":196.5077643135991},{\"lat\":155.54310473534986,\"lon\":196.50489240410587},{\"lat\":157.98993838553378,\"lon\":196.30330327141357},{\"lat\":157.71691493259377,\"lon\":196.21348053159787},{\"lat\":158.00459080697956,\"lon\":196.21103969627677},{\"lat\":158.00633079087947,\"lon\":150.53757127933386},{\"lat\":462.63216876518504,\"lon\":150.56826345894135},{\"lat\":462.62775051617774,\"lon\":177.39939684328374},{\"lat\":474.1316689127858,\"lon\":177.3861288662393},{\"lat\":474.1292202203416,\"lon\":310.56406219854955},{\"lat\":257.994070507554,\"lon\":310.5619464273187},{\"lat\":258.0022136750551,\"lon\":221.02746250321547},{\"lat\":233.36848888688058,\"lon\":221.01177812660774},{\"lat\":233.38082166031313,\"lon\":201.3460566441876},{\"lat\":226.0052871652919,\"lon\":201.36675733931412},{\"lat\":226.00380001144543,\"lon\":191.43608035098336},{\"lat\":219.38452446348114,\"lon\":191.42623433919132},{\"lat\":219.3750039839458,\"lon\":211.38773208032248},{\"lat\":187.52076241319602,\"lon\":211.37499451908235},{\"lat\":187.48398085496257,\"lon\":229.6598027308124},{\"lat\":158.0575778792348,\"lon\":229.63933054427704},{\"lat\":158.07402008390295,\"lon\":216.04334327937187},{\"lat\":154.36704567152967,\"lon\":216.1485416374351},{\"lat\":154.13846789697524,\"lon\":216.7323894462373},{\"lat\":154.28805127717158,\"lon\":216.74413628594021},{\"lat\":154.25047754230278,\"lon\":343.12186391027666},{\"lat\":7.603780159000872,\"lon\":343.1351116536002}]');

-- ----------------------------
-- Table structure for report_statistic
-- ----------------------------
DROP TABLE IF EXISTS `report_statistic`;
CREATE TABLE `report_statistic` (
  `id` varchar(255) NOT NULL,
  `dev_id` varchar(255) NOT NULL,
  PRIMARY KEY (`dev_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of report_statistic
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT '' COMMENT 'Mr/Ms/Mrs',
  `function_dep_id` varchar(255) DEFAULT NULL COMMENT '大部门  职能',
  `function_dep` varchar(255) DEFAULT NULL COMMENT '大部门  职能',
  `department` varchar(255) DEFAULT NULL COMMENT '部门',
  `country` varchar(255) DEFAULT NULL COMMENT '国家',
  `telephone` varchar(255) DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像',
  `password` varchar(255) DEFAULT NULL COMMENT '卡号后五位',
  `email` varchar(255) DEFAULT NULL,
  `user_group_id` varchar(255) DEFAULT NULL COMMENT '用户分组(卡)id',
  `device_color` varchar(255) DEFAULT NULL COMMENT '用户卡的颜色',
  `create_at` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('001', 'safety1', '', '安全帽', null, '', 'Dev', 'China', null, null, '000x', '', '6', null, null);
INSERT INTO `user` VALUES ('002', 'safety2', '', '安全帽', null, '', 'Dev', 'China', null, null, '000x', '', '6', null, null);
INSERT INTO `user` VALUES ('003', 'safety3', '', '安全帽', null, '', 'Dev', 'China', null, null, '000x', '', '6', null, null);
INSERT INTO `user` VALUES ('004', 'safety4', '', '安全帽', null, '', 'Dev', 'China', null, null, '000x', '', '6', null, null);
INSERT INTO `user` VALUES ('005', 'safety5', '', '安全帽', null, '', 'Dev', 'China', null, null, '000x', '', '6', null, null);
INSERT INTO `user` VALUES ('10051000', 'Francis', 'Zheng', '测试用户', null, 'Touch-Spring', 'Dev', 'China', null, '/ISiteImg/1547977842255.jpeg', '000x', 'zhengyouyue27@163.com', '1', null, null);
INSERT INTO `user` VALUES ('10051001', 'Mustafa', 'Gen', null, null, 'PT-RT', 'MKT-AP', 'Australia', null, null, '05c2', 'genevieve.mustafa@au.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051002', 'Sek', 'Bunchoeun', null, null, 'PT-BE', 'SKH', 'Cambodia', null, null, null, 'bunchoeun.sek@bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051003', 'Xia', 'Feng', null, null, 'PT-BE', 'SCN-KU', 'China', null, null, '0630', 'feng.xia@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051004', 'Bao', 'Ming', null, null, 'PT-BE', 'SCN-AM3', 'China', null, null, '05A0', 'ming.bao@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051005', 'HUANG', 'Mang', null, null, 'PT-MT', 'MKR-CN', 'China', null, null, null, 'mang.huang@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051006', 'WANG', 'Lifeng', null, null, 'PT-MT', 'SCN-AM', 'China', null, null, '0606', 'lifeng.wang@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051007', 'Zhen', 'Jinyi', null, null, 'PT-BE', 'SCS1-CN ', 'China', null, null, '05d3', 'jingyi.zhen@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051008', 'JIA', 'Zhenglin', null, null, 'RBCN', 'HRC5-JMP', 'China', null, null, null, 'zhenglin.jia@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051009', 'HU', 'Lifan', null, null, 'PT-BE', 'SAH PT-BE/SHK', 'China', null, null, '0615', 'lifan.hu@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051010', 'Hu', 'Chao', null, null, 'PT-AC', 'MKT5-AP', 'China', null, null, '05B4', 'chao.hu2@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051011', 'Jin', 'Saijun', null, null, 'PT-BE', 'SCS2-CN ', 'China', null, null, '0589', 'saijun.jin@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051012', 'JIN', 'Xueshan', null, null, 'PT-BE', 'ASA-CN', 'China', null, null, '05F3', 'xueshan.jin@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051013', 'LI', 'Chunyu', null, null, 'PT-BE', 'SCN-KA', 'China', null, null, '05C0', 'chunyu.li@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051014', 'LI', 'Hong', null, null, 'PT-BE', 'MKU-CN', 'China', null, null, '0684', 'hong.li@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051015', 'LI', 'Weidong', null, null, 'PT-BE', 'SCN-AM5', 'China', null, null, '060a', 'weidong.li@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051016', 'LIU', 'Gang', null, null, 'PT-RT', 'MKR-CN', 'China', null, null, '05c1', 'gang.liu@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051017', 'LU', 'Zhen', null, null, 'PT-BE', 'MKR-CN', 'China', null, null, '0650', 'zhen.lu2@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051018', 'PAN', 'Yu', null, null, 'PT-BE', 'SCN-AM6 PT-BE/SCN-AM7', 'China', null, null, '05D7', 'yu.pan@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051019', 'QIU', 'Xufei', null, null, 'PT-BE', 'SCS-CN', 'China', null, null, '058c', 'xufei.qiu@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051020', 'Wang', 'Xinyan', null, null, 'PT-BE', 'SCS3-CN ', 'China', null, null, '0607', 'xinyan.wang@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051021', 'XU', 'Kai', null, null, 'PT-AC', 'MKR-CN', 'China', null, null, '0593', 'kai.xu4@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051022', 'Xu', 'Qiangtian', null, null, 'PT-BE', 'SCS4-CN ', 'China', null, null, '0661', 'qiangtian.xu@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051023', 'YANG', 'Xuegang', null, null, 'PT-BE', 'SCN-AM1 PT-BE/SCN-AM2', 'China', null, null, '060d', 'xuegang.yang@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051024', 'YANG', 'Zhe', null, null, 'PT-BE', 'SCN-DB', 'China', null, null, '05a4', 'zhe.yang2@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051025', 'YU', 'Tao', null, null, 'PT-BE', 'MKR-CN PT-AC/MKR-CN', 'China', null, null, '066D', 'rick.yu@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051026', 'ZHU', 'Yichun', null, null, 'PT-BE', 'SCN-AM3 PT-BE/SCN-AM4', 'China', null, null, '062f', 'yichun.zhu@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051027', 'Qian', 'Zhigang', null, null, 'PT-BE', 'MKR-CN', 'China', null, null, '059b', 'zhigang.qian@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051028', 'ZHANG', 'Xinyi', null, null, 'PT-BE', 'MKR-CN', 'China', null, null, '0644', 'xinyi.zhang@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051029', 'Bao', 'Zhiyuan', null, null, 'PT-BE', 'MKR-CN', 'China', null, null, '0601', 'zhiyuan.bao@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051030', 'Lai', 'Suqin', null, null, 'PT-BE', 'SCN-DB', 'China', null, null, '05E3', 'suqin.lai@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051031', 'LI', 'JIE', null, null, 'DonP', 'HRL', 'China', null, '/ISiteImg/1547699934237.jpeg', '0686', 'jie.li2@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051032', 'Li', 'Jin', null, null, 'PT-MT', 'PPU', 'China', null, null, '05F9', 'jin.li@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051033', 'Soh', 'Hockbee', null, null, 'DonP', 'PM', 'China', null, null, '05ce', 'hockbee.soh@hk.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051034', 'Lisa', 'Li', null, null, 'DonP', 'LOG', 'China', null, '/ISiteImg/1547700548716.jpeg', '05CC', 'lisa.li4@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051035', 'Jiang', 'Yanshan', null, null, 'PT-AC', 'LOP-AP', 'China', null, null, '05ef', 'yanshan.jiang@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051036', 'HU', 'Min', null, null, 'PT-BE', 'EXI', 'China', null, null, '0595', 'min.hu@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051037', 'JIANG', 'Xuemei', null, null, 'PT-BE', 'PPU', 'China', null, null, null, 'xuemei.jiang@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051038', 'LIANG', 'Kaiqi', null, null, 'PT-AC', 'MKT4-AP', 'China', null, null, '05E8', 'kaiqi.liang@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051039', 'RUAN', 'Ying', null, null, 'PT-BE', 'MXG PT-BE/MXG-Hz', 'China', null, null, '11030596', 'ying.ruan@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051040', 'Sui', 'Ronghua', null, null, 'PT-AC', 'EDP1-AP', 'China', null, null, '065D', 'ronghua.sui2@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051041', 'WU', 'Dehua', null, null, 'PT', 'PUR-CN1', 'China', null, null, '0611', 'dehua.wu2@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051042', 'YE', 'George', null, null, 'PTCN', 'HRL3', 'China', null, null, '0578', 'george.ye@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051043', 'YU', 'Ronnie', null, null, 'PTCN', 'TE HzP/PM', 'China', null, null, '0675', 'ronnie.yu@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051044', 'YUAN', 'Lihua', null, null, 'PT-AC', 'MKT4-AP', 'China', null, null, '063D', 'lihua.yuan@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051045', 'Luo', 'Miduo', null, null, 'PT-BE', 'LOI', 'China', null, null, '05BE', 'miduo.luo@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051046', 'Murat', 'Akyol', null, null, 'PT', 'LOI-AP', 'China', null, null, '0694', 'Murat.Akyol2@de.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051047', 'LI', 'Jun', null, null, 'PT-AC', 'MKI-KBD', 'China', null, null, '058B', 'jun.li9@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051048', 'Bachofer', 'Martin  ', null, null, 'PT', 'PUR-CN2', 'China', null, null, '0613', 'Martin.Bachofer@de.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051049', 'CAO', 'Zhenggui', null, null, 'PT-BE', 'MG', 'China', null, null, '0592', 'zhenggui.cao@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051050', 'Che', 'Peiqian', null, null, 'PT-BE', 'MXC', 'China', null, null, '065B', 'peiqian.che@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051051', 'CHEN', 'Huilan', null, null, 'PTCN', 'CTG', 'China', null, null, '062D', 'huilan.chen@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051052', 'DAI', 'Bizhi', null, null, 'PT-BE', 'ETD PT-BE/ETS-Hz', 'China', null, null, '0575', 'bizhi.dai@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051053', 'FANG', 'Linda', null, null, 'PT-BE', 'LOP-AP', 'China', null, null, '05DA', 'linda.fang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051054', 'GAO', 'Shan', null, null, 'PT-AC', 'MKT4-AP', 'China', null, null, '064B', 'shan.gao@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051055', 'Jiang', 'Chen', null, null, 'RBCN', 'HRC5-JMP', 'China', null, null, '063B', 'chen.jiang2@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051056', 'JIANG', 'Xingjun', null, null, 'PT-BE', 'PJ-MG', 'China', null, null, '05D9', 'xingjun.jiang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051057', 'JIN', 'Hongxiang', null, null, 'PT-AC', 'PUR-Hz', 'China', null, null, '11030668', 'hongxiang.jin@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051058', 'Jin', 'Tingting', null, null, 'PT-AC', 'LOG-AP', 'China', null, null, '0605', 'tingting.jin@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051059', 'LAI', 'Xiaozhou', null, null, 'PT-AC', 'MKT2', 'China', null, null, '05BA', 'xiaozhou.lai@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051060', 'LI', 'Buyang', null, null, 'PT-BE', 'MXH PT-BE/MXC-Hz', 'China', null, null, '11030673', 'buyang.li@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051061', 'LI', 'Yi', null, null, 'PT-BE', 'ETP-Hz', 'China', null, null, '11030628', 'yi.li3@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051062', 'LINTHORST', 'Jord', null, null, 'PT-AC', 'MKT3-AP', 'China', null, null, '05A3', 'jord.linthorst@ch.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051063', 'LOU', 'Youlong', null, null, 'PT-BE', 'MFT3', 'China', null, null, '065a', 'youlong.lou@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051064', 'LV', 'Jiaqi', null, null, 'PT-AC', 'MKT1-AP', 'China', null, null, '11030639', 'jiaqi.lv@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051065', 'LV', 'Qiongli', null, null, 'PT-AC', 'MKT5-AP', 'China', null, null, '05DD', 'qiongli.lv@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051066', 'Mao', 'Yingying', null, null, 'PT-AC', 'MKB', 'China', null, null, '0649', 'yingying.mao@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051067', 'SHU', 'Xuan', null, null, 'PT-AC', 'MKI-KAS', 'China', null, null, '0632', 'xuan.shu@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051068', 'TIAN', 'Hui', null, null, 'PT-AC', 'MKT1-AP', 'China', null, null, null, 'hui.tian@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051069', 'TIAN', 'Weibin', null, null, 'PT-BE', 'EXC', 'China', null, null, '0690', 'weibin.tian@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051070', 'TONG', 'Yan', null, null, 'PT-AC', 'MKT1-AP', 'China', null, null, '11030637', 'tong.yan@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051071', 'WANG', 'Feifei', null, null, 'PT-AC', 'MKT5-AP', 'China', null, null, '0568', 'feifei.wang3@cn.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051072', 'WANG', 'Liang', null, null, 'PT-BE', 'EXG', 'China', null, null, '05B7', 'liang.wang2@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051073', 'WEI', 'Qing', null, null, 'PT-AC', 'QMM2-AP PT-AC/ESP-AP', 'China', null, '/ISiteImg/1547693825715.jpeg', '068E', 'qing.wei@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051074', 'Xu', 'Dan', null, null, 'PT', 'ICO-AP', 'China', null, null, '057f', 'dan.xu@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051075', 'XU', 'Gang', null, null, 'PT-BE', 'MFT PT-BE/MFT1', 'China', null, null, '062E', 'gang.xu@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051076', 'YANG', 'Hui', null, null, 'PT-AC', 'MKB', 'China', null, null, '05AF', 'hui.yang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051077', 'YAO', 'Min', null, null, 'PT-AC', 'PXG-PA5', 'China', null, null, '1103061F', 'min.yao2@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051078', 'YE', 'Lei', null, null, 'PT-AC', 'MKB', 'China', null, null, '05B0', 'lei.ye@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051079', 'Zhan', 'Dongfang', null, null, 'PT-BE', 'CTG', 'China', null, null, '11030677', 'dongfang.zhan@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051080', 'Zhang', 'Chunyan', null, null, 'PTCN', 'HRL', 'China', null, null, '057E', 'chunyan.zhang@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051081', 'ZHANG', 'Ping', null, null, 'PT-AC', 'PXE-PA3', 'China', null, null, '059a', 'ping.zhang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051082', 'ZHANG', 'Zhenji', null, null, 'PT-BE', 'PJ-AT', 'China', null, null, '11030693', 'zhenji.zhang@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051083', 'ZHAO', 'Hong', null, null, 'PTCN', 'GM PTCN/FC', 'China', null, null, '05e9', 'hong.zhao@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051084', 'ZHEN', 'Bo', null, null, 'PT-BE', 'NE', 'China', null, null, '05ac', 'bo.zhen@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051085', 'ZHENG', 'Hans', null, null, 'PT', 'PUB PT/PUB-ET', 'China', null, null, '0662', 'hans.zheng@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051086', 'ZHENG', 'Yanru', null, null, 'PT-AC', 'MKT3-AP', 'China', null, null, '05F8', 'yanru.zheng@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051087', 'Zhou', 'Long', null, null, 'PT-AC', 'PXI-AP', 'China', null, null, '0597', 'long.zhou@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051088', 'ZHU', 'Kevin', null, null, 'PT-BE', 'QMM', 'China', null, null, '11030678', 'kevin.zhu@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051089', 'ZHU', 'Yeping', null, null, 'PT-AC', 'MKT1-AP', 'China', null, null, '11030638', 'yeping.zhu@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051090', 'ZONG', 'Senyang', null, null, 'PT-AC', 'MKT2', 'China', null, null, '05BB', 'senyang.zong@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051091', 'Zheng', 'Weixin', null, null, 'PT-BE', 'EXC', 'China', null, null, '0695', 'weixin.zheng@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051092', 'Li', 'Xiaolong', null, null, 'PT-BE', 'EXH', 'China', null, null, '068C', 'xiaolong.li@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051093', 'Song', 'Chunlei', null, null, 'PT-BE', 'EXD', 'China', null, null, '0629', 'chunlei.song@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051094', 'Wu', 'Jian', null, null, 'PT-BE', 'ETD3', 'China', null, '/ISiteImg/1547685554635.jpeg', '0570', 'jian.wu4@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051095', 'YANG', 'David', null, null, 'PujP', 'PM', 'China', null, null, '110305AD', 'qiming.yang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051096', 'Anna', 'FEKETE', null, null, 'PT', 'EDA', 'China', null, null, '0654', 'anna.fekete@hu.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051097', 'Zsombor', 'BATHORI', null, null, 'PT-BE', 'ASA', 'China', null, null, '0640', 'zsombor.bathori@ru.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051098', 'PAN', 'Doris', null, null, 'PT-BE', 'PXF', 'China', null, null, '056F', 'doris.pan@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051099', 'DELANGE', 'Douglas', null, null, 'PT-BE', 'PXF', 'China', null, null, '05B9', 'douglas.delange@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051100', 'Max', 'Ong CHEE HAO', null, null, 'PT-BE', 'PXF', 'China', null, null, null, 'cheehao.ong@my.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051101', 'Schulte', 'Jasper', null, null, 'PT-BE', 'PXF', 'China', null, null, '067F', 'jasper.schulte@nl.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051102', 'Vinay', 'Anand S', null, null, 'PT-BE', 'PXD', 'China', null, null, '0635', 'vinayanand.s@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051103', 'YUAN', 'Sabrina', null, null, 'PT-BE', 'PXN', 'China', null, null, null, 'sabrina.yuan@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051104', 'ZAPLETAL', 'Petr', null, null, 'PT-BE', 'PXF', 'China', null, null, '0687', 'petr.zapletal@de.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051105', 'B', 'MOHAMED NORI JAMAL MATIN', null, null, 'PT-BE', 'PXF', 'China', null, null, '05ff', 'jamal.matin@my.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051106', 'CHAND', 'Akshat', null, null, 'PT-BE', 'PXG', 'China', null, null, '058E', 'akshat.chand@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051107', 'DUAN', 'Ruilong', null, null, 'PT-BE', 'PXC', 'China', null, null, '0656', 'ruilong.duan@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051108', 'GURUDATTA', 'Baksheesh', null, null, 'PT-BE', 'EDA ', 'China', null, '/ISiteImg/1547715078234.jpeg', '0691', 'baksheesh.gurudatta@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051109', 'KIM', 'Sung Lim', null, null, 'PT', 'GDU-AP', 'China', null, null, '11030580', 'sarah.s.kim@kr.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051110', 'LIN', 'Archer', null, null, 'PT-BE', 'PXN', 'China', null, '/ISiteImg/1547702667682.jpeg', '05CA', 'archer.lin@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051111', 'Lin', 'Zhi', null, null, 'PT-BE', 'PXD', 'China', null, null, '0658', 'zhi.lin@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051112', 'Prasad', 'P', null, null, 'PT-BE', 'MKR-AP', 'China', null, null, '0610', 'prasad.p@in.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051113', 'REED', 'Martin', null, null, 'PT', 'GDU-AP', 'China', null, null, null, 'fixed-term.martin.reed@bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051114', 'TANG', 'Hanyu', null, null, 'PT-BE', 'ASA-RAP', 'China', null, null, '0587', 'hanyu.tang@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051115', 'Ulrich', 'Stefan', null, null, 'PT-BE', 'UXD', 'China', null, null, '05f1', 'stefan.ulrich4@de.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051116', 'Yang', 'Jitao', null, null, 'PT-AC', 'MKT4-AP', 'China', null, null, '05AA', 'jitao.yang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051117', 'Skryabikov', 'Alexey', null, null, 'PT-BE', 'ASA', 'China', null, null, '0579', 'alexey.skryabikov@ru.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051118', 'LEI', 'Hao', null, null, 'PT-BE', 'PXG', 'China', null, '/ISiteImg/1547689034901.jpeg', '05fe', 'hao.lei@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051119', 'NEOH', 'CHEE UEE', null, null, 'PT-BE', 'PXF', 'China', null, null, '05d4', 'cheeuee.neoh@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051120', 'Pitkin', 'Orin', null, null, 'PT-BE', 'MKU', 'China', null, null, '065c', 'orin.pitkin@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051121', 'ZHAO', 'Aimin', null, null, 'PT-BE', 'EXN', 'China', null, null, '0588', 'aimin.zhao@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051122', 'SUN', 'Yuwei', null, null, 'PT-BE', 'PXN', 'China', null, null, '0622', 'yuwei.sun2@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051123', 'CHEN', 'Chao', null, null, 'PT-BE', 'PXB', 'China', null, '/ISiteImg/1547703353117.jpeg', '05c3', 'chao.chen10@ch.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051124', 'DI', 'Anran', null, null, 'PT-BE', 'PXH RBCN/HRC5-JMP', 'China', null, null, '068F', 'anran.di@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051125', 'GU', 'Wei', null, null, 'PT-BE', 'PXH', 'China', null, null, '062b', 'wei.gu3@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051126', 'JIN', 'Xizi', null, null, 'PT-BE', 'PXB', 'China', null, null, '05C7', 'xizi.jin@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051127', 'KAPREEVA', 'Elena', null, null, 'PT-BE', 'PXB', 'China', null, null, '0681', 'elena.kapreeva@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051128', 'LAU', 'Manson', null, null, 'PT-BE', 'PXC', 'China', null, null, '0631', 'manson.lau@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051129', 'LING', 'Tong', null, null, 'RBCN', 'HRC5-JMP', 'China', null, '/ISiteImg/1547772888092.jpeg', '05C8', 'tong.ling2@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051130', 'LIU', 'Johnson', null, null, 'PT-BE', 'PXD', 'China', null, null, '11030657', 'johnson.liu2@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051131', 'LIU', 'Linlin', null, null, 'PT-BE', 'PXG', 'China', null, null, '061D', 'linlin.liu2@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051132', 'Ravic', 'Aleksandar', null, null, 'PT-BE', 'PXG', 'China', null, null, '05A2', 'aleksandar.ravic@hu.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051133', 'SHEN', 'Qiong', null, null, 'PT-BE', 'PXD', 'China', null, null, '0666', 'qiong.shen@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051134', 'Tan', 'Chee Khiang', null, null, 'PT-BE', 'PXB', 'China', null, '/ISiteImg/1547704814554.jpeg', '0565', 'cheekhiang.tan@my.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051135', 'TANG', 'Qingyun', null, null, 'PT-BE', 'PXC RBCN/HRC5', 'China', null, null, '0627', 'qingyun.tang@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051136', 'TIAN', 'Jindan', null, null, 'PT-BE', 'PXC', 'China', null, null, '057B', 'jindan.tian@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051137', 'TU', 'Hengsong', null, null, 'PT-BE', 'PXB', 'China', null, null, '0614', 'hengsong.tu@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051138', 'WANG', 'Xiuping', null, null, 'PT-BE', 'PXN', 'China', null, null, '0679', 'xiuping.wang@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051139', 'YIAP', 'CHIEN WERN', null, null, 'PT-BE', 'PXN', 'China', null, '/ISiteImg/1547703637732.jpeg', '0619', 'chienwern.yiap@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051140', 'YIN', 'Mengling', null, null, 'PT-BE', 'PXB', 'China', null, null, '0577', 'mengling.yin@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051141', 'Zhai', 'Jianping', null, null, 'PT-BE', 'PXC', 'China', null, null, null, 'jianping.zhai@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051142', 'ZHANG', 'Liping', null, null, 'PT-BE', 'PXC', 'China', null, null, '0655', 'liping.zhang@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051143', 'ZHANG', 'Xuze', null, null, 'PT-BE', 'PXI', 'China', null, null, '0633', 'xuze.zhang@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051144', 'ZHOU', 'Ruobing', null, null, 'PT-BE', 'PXG', 'China', null, null, '0573', 'ruobing.zhou@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051145', 'ZHU', 'Chenxi', null, null, 'PT-BE', 'PXG', 'China', null, null, '110305cb', 'chenxi.zhu@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051146', 'ZOU', 'Will', null, null, 'PT-BE', 'PXF', 'China', null, null, null, 'will.zou@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051147', 'An', 'Bing', null, null, 'PT-RT', 'LOG-AP', 'China', null, '/ISiteImg/1547735291303.jpeg', '060F', 'bing.an@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051148', 'Ataide', 'Eduardo', null, null, 'PT-BE', 'PXI', 'China', null, null, '058f', 'eduardo.ataide@br.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051149', 'BAO', 'Lei', null, null, 'PT-BE', 'PXB', 'China', null, '/ISiteImg/1547685968337.png', '0667', 'lei.bao2@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051150', 'BIN', 'ABDUL SHUKOR MUHAMMAD AFIQ', null, null, 'PT-BE', 'PXI', 'China', null, null, '061B', 'muhammadafiq.abdulshukor@my.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051151', 'CHAN', 'Richard', null, null, 'PT-BE', 'ASA-RAP', 'China', null, '/ISiteImg/1547689734356.jpeg', '05E2', 'richard.chan@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051152', 'CHEN', 'Tracy', null, null, 'PT-BE', 'MKO', 'China', null, null, null, 'tracychanmin@hotmail.com', null, null, null);
INSERT INTO `user` VALUES ('10051153', 'CHIANG', 'Bella', null, null, 'PT-BE', 'MKU', 'China', null, '/ISiteImg/1547690437608.jpeg', '057d', 'bella.chiang@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051154', 'CHOI', 'Alex', null, null, 'PT', 'GDU-AP', 'China', null, null, '0616', 'alex.choi@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051155', 'CHU', 'David', null, null, 'PT-BE', 'MKU-AP', 'China', null, null, '11030566', 'david.chu2@cn.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051156', 'DE', 'GROOT Stephan', null, null, 'PT-BE', 'PXH', 'China', null, null, '05bd', 'stephan.degroot@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051157', 'Deng', 'Ying', null, null, 'PT-BE', 'EDA', 'China', null, null, '11030676', 'ying.deng@tw.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051158', 'Fabricio', 'Alexandre', null, null, 'PT-BE', 'EDA', 'China', null, '/ISiteImg/1547783350913.jpeg', '0621', 'alexandre.fabricio@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051159', 'Gerkhardt', 'Jan', null, null, 'PT-BE', 'CTG', 'China', null, null, '05CF', 'jan.gerkhardt@de.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051160', 'Guan', 'Ensheng', null, null, 'PT-AC', 'MKT3-AP', 'China', null, null, '3065E', 'ensheng.guan@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051161', 'GUO', 'Yuanyuan', null, null, 'PT-BE', 'CTG', 'China', null, null, '061e', 'yuanyuan.guo@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051162', 'HAN', 'Yuhui', null, null, 'PT', 'GDU-AP', 'China', null, null, null, 'yuhui.han@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051163', 'Hrulev', 'Evgenij', null, null, 'PT-BE', 'PXI', 'China', null, null, '067a', 'evgenij.hrulev@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051164', 'ISIP', 'Dulce', null, null, 'PT-BE', 'MKR-AP', 'China', null, '/ISiteImg/1547783360232.jpeg', '0571', 'dulce.isip@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051165', 'Jeng', 'Yiyun', null, null, 'PT-BE', 'FC', 'China', null, null, '05D2', 'yiyun.jeng@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051166', 'Jenny', 'Zheng', null, null, 'FIXED-TERM Dremel AP', 'FIXED-TERM Dremel AP', 'China', null, '/ISiteImg/1547690550991.jpeg', '056B', 'jenny.zheng@cn.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051167', 'Ji', 'Xiaoqian', null, null, 'PT-BE', 'CTG', 'China', null, null, '11030620', 'xiaoqian.ji@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051168', 'KUMAR', 'Dinesh', null, null, 'PT-BE', 'MKU', 'China', null, '/ISiteImg/1547748879620.jpeg', '056a', 'dinesh.kumard@cn.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051169', 'LIN', 'Jackie', null, null, 'PT-BE', 'ASA-RAP', 'China', null, null, '05F0', 'jackie.lin@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051170', 'Liu', 'Shu (Rachel)', null, null, 'PT-BE', 'BUD', 'China', null, '/ISiteImg/1547703848882.jpeg', '058D', 'shu.liu@bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051171', 'MATSUNAGA', 'Rodrigo', null, null, 'PT-BE', 'MKO', 'China', null, null, '0645', 'rodrigo.matsunaga@br.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051172', 'OLIVEIRA', 'Renato', null, null, 'PT-RT', 'CTG', 'China', null, '/ISiteImg/1547765975415.jpeg', '0670', 'renato.oliveira@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051173', 'Pscheidl', 'Claudius', null, null, 'PT', 'GDU-AP', 'China', null, '/ISiteImg/1547714072532.jpeg', '05A1', 'pscheidl.claudius@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051174', 'Razumowsky', 'Anton', null, null, 'PE-BE', 'PXC', 'China', null, null, null, 'anton.razumowsky@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051175', 'Reis', 'Andre', null, null, 'PT-BE', 'FC', 'China', null, null, '110305E7', 'andre.reis@nl.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051176', 'SCHMIDT', 'Christoph', null, null, 'PT-BE', 'BUD', 'China', null, '/ISiteImg/1547694964940.jpeg', '0591', 'christoph.schmidt@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051177', 'SHEN', 'Vivi', null, null, 'PT-BE', 'CTG', 'China', null, null, '067D', 'vivi.shen@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051178', 'STEEB', 'Helena', null, null, 'PT-BE', 'PXI', 'China', null, null, '062C', 'helena.steeb@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051179', 'Tang', 'Samantha', null, null, 'PT-BE', 'BUD', 'China', null, null, '110305D1', 'samantha.tang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051180', 'TIAN', 'Jing', null, null, 'PT', 'HRM-AP', 'China', null, null, '0574', 'jing.tian@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051181', 'TIBBOTT', 'Ben', null, null, 'PT-BE', 'PJ-AT', 'China', null, null, '0572', 'ben.tibbott@au.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051182', 'Torres', 'Rafael', null, null, 'PT-BE', 'MKO', 'China', null, null, '064d', 'rafael.torres@br.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051183', 'Uzcanga', 'Agustin', null, null, 'PT-BE', 'GP', 'China', null, null, '0636', 'agustin.uzcanga@hu.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051184', 'Wang', 'Aiqi', null, null, 'PT-BE', 'EDA', 'China', null, null, '059D', 'aiqi.wang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051185', 'WANG', 'Catty', null, null, 'PT-BE', 'CTG', 'China', null, null, '0659', 'catty.wang@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051186', 'WANG', 'Wenxu', null, null, 'PT-BE', 'MKU-AP', 'China', null, null, '063a', 'wenxu.wang@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051187', 'WEIGELT', 'Fraenze', null, null, null, null, 'China', null, null, '05E6', 'fraenze.weigelt@hu.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051188', 'Yang', 'Xi', null, null, 'PT-BE', 'PXH', 'China', null, '/ISiteImg/1547702555966.jpeg', '068D', 'xi.yang2@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051189', 'ZHANG', 'Echo', null, null, 'PT-RT', 'MKT-AP', 'China', null, null, '05C5', 'echo.zhang@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051190', 'Zhang', 'Lei', null, null, 'PT-BE', 'MKR-AP', 'China', null, '/ISiteImg/1547700159266.jpeg', '0576', 'lei.zhang2@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051191', 'ZHANG', 'Yu', null, null, 'PT-BE', 'GP', 'China', null, '/ISiteImg/1547776107578.jpeg', '0567', 'yu.zhang4@cn.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051192', 'ZHAO', 'Sally', null, null, 'PT-BE', 'CTG', 'China', null, null, '11030674', 'xi.zhao2@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051193', 'ZHENG', 'Valerie', null, null, 'PT', 'GDU-AP', 'China', null, null, '061C', 'valerie.zheng2@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051194', 'ZHONG', 'Clare', null, null, 'PT-BE', 'MKO', 'China', null, null, null, 'clare.zhong@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051195', 'ZHU', 'Sandra', null, null, 'RBCN', 'HRL', 'China', null, null, '0581', 'sandra.zhu@cn.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051196', 'ZHU', 'Zane', null, null, 'PT', 'GDU-AP', 'China', null, null, '060b', 'zane.zhu@cn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051197', 'FERRER', 'CATALA JOSE RAFAEL', null, null, 'PT-BE', 'MKO (Intern)', 'China', null, null, '056e', 'fixed-term.JOSERAFAEL.FERRERCATALA@cn.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051198', 'ZHENG', 'Yuanjing', null, null, 'PT-AC', 'MKT5-AP', 'China', null, null, '05E4', 'yuanjing.zheng@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051199', 'Becker', 'Henk', null, null, 'PT', 'P', 'Germany', null, null, '0646', 'henk.becker@de.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051200', 'de', 'Vet Lennart', null, null, 'PT', 'ES', 'Germany', null, null, '0603', 'lennart.devet@de.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051201', 'Hoelzl', 'Stephan', null, null, 'PT', 'EC', 'Germany', null, null, '05E0', 'stephan.hoelzl@de.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051202', 'Holfelder', 'Christian', null, null, 'PT', 'OFE-ET', 'Germany', null, '/ISiteImg/1547697979769.jpeg', '0584', 'christian.holfelder@de.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051203', 'SIEGERT', 'Elly ', null, null, 'PT', 'HR', 'Germany', null, null, '056C', 'elly.siegert@de.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051204', 'Singer', 'Irene', null, null, 'PT', 'BUD', 'Germany', null, '/ISiteImg/1547697744320.jpeg', '305fd', 'irene.singer@de.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051205', 'KIANG', 'Yoyo', null, null, 'PT-MT', 'MKP4', 'China', null, null, '0672', 'yoyo.kiang@hk.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051206', 'LO', 'Vincent', null, null, 'PT-MT', 'MKC-AP', 'China', null, null, null, 'vincent.lo@hk.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051207', 'Mark', 'Bobby', null, null, 'PT-MT', 'PJM3-HK', 'China', null, null, '05DC', 'bobby.mark@hk.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051208', 'SO', 'Sirina', null, null, 'PT-MT', 'MKP4', 'China', null, null, '0665', 'sirina.so@hk.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051209', 'WONG', 'Hok Tai', null, null, 'PT-MT', 'MKT-AP PT-MT/MKC-AP', 'China', null, null, '11030623', 'hoktai.wong@hk.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051210', 'Yuen', 'Clement', null, null, 'PT-MT', 'MKT-AP', 'China', null, null, '05BF', 'clement.yuen2@hk.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051211', 'Anand', 'Pardeep', null, null, 'PT-AC', 'SIN PT-AC/SIN-AM', 'India', null, null, '0683', 'pradeep.anand@in.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051212', 'Jha', 'Ritu', null, null, 'PT-AC', 'MKR-IN', 'India', null, null, '05FC', 'ritu.jha@in.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051213', 'Krishnaswamy', 'Kiran', null, null, 'PT-BE', 'ASA-IN PT-BE/SIN-DB', 'India', null, null, '05A8', 'kiran.krishnaswamy@in.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051214', 'Mohandasan', 'P', null, null, 'PT-BE', 'SCS-IN PT-BE/SCS1-IN', 'India', null, null, '064f', 'mohan.das@in.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051215', 'Sharma', 'Maneesh', null, null, 'PT-BE', 'MKR-IN', 'India', null, null, '063F', 'maneesh.sharma2@in.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051216', 'Singh', 'Raina', null, null, 'PT-BE', 'MKU-AP', 'India', null, null, '05A7', 'raina.singh@in.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051217', 'Viswanatha', 'Raju K', null, null, 'PT-BE', 'SIN-RD', 'India', null, null, '064E', 'viswanatha.raju@in.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051218', 'Agarwal', 'Hunny', null, null, 'PT-BE', 'SIN-AM6', 'India', null, null, null, 'hunny.agarwal@in.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051219', 'Mehta', 'Manoj', null, null, 'PT-BE', 'SIN-AM1', 'India', null, null, '0598', 'manoj.mehta@in.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051220', 'Panish', 'P K', null, null, 'PT-BE', 'SAD', 'India', null, null, null, 'panish.pk@in.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051221', 'Ranjith', 'Kumar', null, null, 'PT-BE', 'SIN-AM8', 'India', null, null, null, 'kumar.ranjith@in.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051222', 'Ravi', 'Kumar M V M N', null, null, 'PT-BE', 'SIN-KU', 'India', null, null, null, 'ravikumar@in.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051223', 'Singh', 'Vinitkumar', null, null, 'PT-BE', 'SIN-AM7', 'India', null, null, null, 'vinitkumar.singh@in.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051224', 'Sundaram', 'Soma', null, null, 'PT-BE', 'SIN-AM4', 'India', null, null, null, 'soma.sundaram@in.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051225', 'Bala', 'Subramaniam', null, null, 'PT-AC', 'MKT4-AP', 'India', null, '/ISiteImg/1547695865226.jpeg', '05AB', 'bala.subramaniam@in.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051226', 'Giridhar', 'J', null, null, 'ChiP', 'PM ChiP/HRL ChiP/PJM1', 'India', null, null, '0680', 'giridhar.j@in.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051227', 'Himanshu', 'Atmaprakash Mamtani', null, null, 'PT-BE', 'SIN-KU2', 'India', null, null, '05EB', 'himanshuatmaprakash.mamtani@in.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051228', 'Fachri', 'Riza Ferdiansyah', null, null, 'PT', 'SID', 'Indonesia', null, null, '0590', 'rizaferdiansyah.fachri@id.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051229', 'HO', 'Andrew', null, null, 'PT', 'SID-MK', 'Indonesia', null, null, '0583', 'andrew.ho@id.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051230', 'Iskandar', 'Genesis', null, null, 'PT', 'SID-NSM', 'Indonesia', null, '/ISiteImg/1547694274907.jpeg', '05FB', 'genesis.iskandar@id.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051231', 'Krisna', 'Sadeli Kevin', null, null, 'PT', 'SID-MK', 'Indonesia', null, null, '05E1', 'kevin.krisnasadeli@id.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051232', 'LIZWAN', 'Michael', null, null, 'PT', 'SID-MK', 'Indonesia', null, null, '11030689', 'michael.lizwan@id.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051233', 'Heli', 'Susanto Salim', null, null, 'PT', 'SID-SCM2', 'Indonesia', null, null, null, 'agus.susanto@id.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051234', 'Sato', 'Noboru', null, null, 'PT-BI', 'MKR-JP', 'Japan', null, null, null, 'noboru.sato@jp.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051235', 'Kimura', 'Kimihito', null, null, 'PT-MT', 'MKT-AP', 'Japan', null, null, null, 'kimihito.kimura@jp.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051236', 'Jung', 'Yeonkyu', null, null, 'PT-MT', 'MKT-AP', 'Korea', null, null, null, 'yeonkyu.jung@kr.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051237', 'STEINLE', 'Sebastian', null, null, 'PT', 'GDU2 PT/GDU3', 'Leinfelden', null, null, null, 'sebastian.steinle@de.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051238', 'Park', 'Jooran', null, null, 'PT-RT', 'MKT-AP', 'Korea', null, null, '1103066f', 'jooran.park@kr.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051239', 'LANGNER', 'Michael', null, null, 'PT', 'GDU3', 'Leinfelden', null, null, '0608', 'michael.langner@de.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051240', 'WALLBERG', 'Jennifer', null, null, 'PT', 'GDU', 'Leinfelden', null, null, null, 'jennifer.wallberg@de.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051241', 'DIRKS', 'Fabian', null, null, 'PT', 'HRD', 'Leinfelden', null, null, '0569', 'fabian.dirks@de.bosch.com', '4', null, null);
INSERT INTO `user` VALUES ('10051242', 'Wong', 'Pei Yee', null, null, 'PT-AC', 'MKR-MY', 'Malaysia', null, '/ISiteImg/1547689171630.jpeg', '0652', 'peiyee.wong@my.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051243', 'Chu', 'Chee Bee', null, null, 'PT-BE', 'SMY', 'Malaysia', null, null, '061A', 'cheebee.chu@my.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051244', 'Ea', 'Siong Lin', null, null, 'PT-BE', 'SMY', 'Malaysia', null, null, '05B8', 'siong.lin@bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051245', 'Kuek', 'Caroline', null, null, 'PT-BE', 'MKR-MY', 'Malaysia', null, null, '0642', 'caroline.kuek@my.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051246', 'Foo', 'Zhilin', null, null, 'PT-BE', 'SMY-KA', 'Malaysia', null, null, '0624', 'zhilin.foo@my.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051247', 'Ng', 'Michelle', null, null, 'PT-BE', 'SAZ', 'Malaysia', null, null, '05de', 'michelle.ng@my.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051248', 'Komadina', 'Andrea', null, null, 'PT-AC', 'MKT3-AP', 'Malaysia', null, null, '064A', 'andrea.komadina@my.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051249', 'Beetz', 'Ralph', null, null, 'PgP2', 'PM', 'Malaysia', null, null, '0604', 'ralph.beetz@my.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051250', 'Donneau', 'Sandra', null, null, 'PgP2', 'COR', 'Malaysia', null, null, '05BC', 'sandra.donneau2@my.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051251', 'Ginn', 'Yuh Gan', null, null, 'PT-BE', 'MXI', 'Malaysia', null, null, '068B', 'ginnyuh.gan@my.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051252', 'Ng', 'Chin Moh', null, null, 'PT-MT', 'PJM-Pg', 'Malaysia', null, null, '05F5', 'chinmoh.ng@my.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051253', 'Ong', 'Ewe Lay', null, null, 'PgP2', 'MSE3', 'Malaysia', null, null, '059C', 'ewelay.ong@my.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051254', 'Tan', 'Peck Ying', null, null, 'PT-BE', 'MXF', 'Malaysia', null, null, '0669', 'peckying.tan@my.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051255', 'Yeap', 'Keng Soon', null, null, 'PgP2', 'HRL1', 'Malaysia', null, null, '057a', 'kengsoon.yeap@my.bosch.com', '5', null, null);
INSERT INTO `user` VALUES ('10051256', 'Yeo', 'Joanne', null, null, 'PT-BE', 'ETS-Pg', 'Malaysia', null, null, '0625', 'aimin.yeo@my.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051257', 'Yeoh', 'Sim Teik', null, null, 'PT-BE', 'EXF-C PT-BE/ETP-Pg', 'Malaysia', null, null, '0594', 'simteik.yeoh@my.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051258', 'Han', 'Hnin Wai', null, null, 'PT-BE', 'SSG-SMM', 'Myanmar', null, null, '066c', 'hninwai.han@sg.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051259', 'Beuker', 'Danielle', null, null, 'PT-RT', 'MKU-EA', 'Netherland', null, null, '0618', 'danielle.beuker@bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051260', 'Rajna', 'Istvan', null, null, 'PT-RT', 'MKP-EA', 'Netherland', null, '/ISiteImg/1547719209608.jpeg', '05c6', 'istvan.rajna@bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051261', 'Shimazu', 'Andriel', null, null, 'PT-RT', 'MKT-LA', 'Netherland', null, null, '066E', 'andriel.shimazu@br.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051262', 'van', 'Benthem Edwin', null, null, 'PT-RT', 'MKT-EA PT-RT/MKR-EA', 'Netherland', null, null, null, 'edwin.vanbenthem@bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051263', 'Espinosa', 'Michelle', null, null, 'PT-BE', 'SPH-KA', 'Philippines', null, null, '05E5', 'michelle.espinosa@ph.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051264', 'Go', 'William', null, null, 'PT-BE', 'SPH', 'Philippines', null, '/ISiteImg/1547774943598.jpeg', '0685', 'william.go@ph.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051265', 'Tabada', 'Roy', null, null, 'PT-BE', 'SPH-AM', 'Philippines', null, null, '0602', 'roy.tabada@ph.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051266', 'Umlas', 'Nate Christian', null, null, 'PT-AC', 'MKR-PH', 'Philippines', null, null, '05a9', 'natechristian.umlas@ph.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051267', 'Valenzuela', 'Martin Edgar', null, null, 'PT-BE', 'SPH', 'Philippines', null, '/ISiteImg/1547775225074.jpeg', '0653', 'martinedgar.valenzuela@ph.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051268', 'Tanangco', 'Jonathan Sanvictores', null, null, 'PT-BE', 'SPH', 'Philippines', null, null, '0600', 'jonathansanvictores.tanangco@ph.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051269', 'Gemma', 'Stephanie Alviso', null, null, 'PT-BE', 'SPH-MKU', 'Philippines', null, null, '05DF', 'gemmastephanie.alviso@ph.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051270', 'Manocha', 'Rohit', null, null, 'PT-AC', 'SAP PT-AC/SFA-RAP', 'Singapore', null, null, null, 'rohit.manocha@sg.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051271', 'Choong', 'Eddent', null, null, 'PT-BE', 'SSG', 'Singapore', null, null, '0626', 'eddent.choong@sg.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051272', 'Ong', 'Ray', null, null, 'PT-BE', 'SSG', 'Singapore', null, null, '05CD', 'ray.ong@sg.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051273', 'Ang', 'Joo Sing', null, null, 'PT-BE', 'SSG', 'Singapore', null, null, null, 'ajs5sgp@bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051274', 'Eileen', 'Chng', null, null, 'PT-BE', 'SSG', 'Singapore', null, null, '062A', 'eileen.chng@sg.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051275', 'Marzel', 'Chanton', null, null, 'NiP', 'PM PT-AC/PA2 NiP/PJ-PM', 'Switzerland', null, null, '05B5', 'marzell.chanton@ch.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051276', 'Yvonne', 'Ongetta', null, null, 'PT-AC', 'MKE-PA2 PT-AC/PXS-PA2 PT-AC/MKT2', 'Switzerland', null, null, '1103068A', 'yvonne.ongetta@ch.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051277', 'Frick', 'Michael', null, null, 'PT-AC', 'PA3 PT-AC/PXT-PA3', 'Switzerland', null, null, null, 'michael.frick2@ch.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051278', 'Theiss', 'Ingo', null, null, 'PT-AC', 'MKB', 'Switzerland', null, null, '0599', 'ingo.theiss@ch.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051279', 'Ko', 'Tom', null, null, 'PT-AC', 'MKR-CN', 'China', null, null, '0641', 'tom.ko@tw.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051280', 'Lei', 'Lei', null, null, 'PT-BE', 'STW', 'China', null, null, '1103060E', 'lei.lei@tw.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051281', 'Lien', 'Jane', null, null, 'PT-MT', 'MKT-AP', 'China', null, null, '110305D5', 'jane.lien@tw.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051282', ' Chen', 'Linda ', null, null, 'PT-BE', 'STW', 'China', null, '/ISiteImg/1547720192171.jpeg', '1103066b', 'linda.chen2@tw.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051283', 'Chen', 'Andy', null, null, 'PT-BE', 'STW', 'China', null, null, '0617', 'andy.chen@tw.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051284', 'KoK', 'Yee Choy', null, null, 'PT-BE', 'STW', 'China', null, null, '05a5', 'yeechoy.kok3@cn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051285', 'Kalavantavanich', 'Kawin', null, null, 'PT-BE', 'STH', 'Thailand', null, null, '0647', 'kawink@th.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051286', 'Kumpinyo', 'Patcharakanok', null, null, 'PT-AC', 'MKR-TH', 'Thailand', null, null, '1103063E', 'patcharakanokk@th.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051287', 'Prasertmethakul', 'Teerathas', null, null, 'PT-BE', 'STH', 'Thailand', null, null, '05D0', 'teerathasp@th.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051288', 'TRUONG', 'Maxime Jean', null, null, 'PT-BE', 'MKU-AP', 'Thailand', null, null, '0585', 'maximejean.truong@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051289', 'Kittiphan', 'Sakronram', null, null, 'PT-AC', 'MKR-TH', 'Thailand', null, null, '063c', 'kittiphans@th.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051290', 'Kunprayod', 'Nasikan', null, null, 'PT-BE', 'STH-KA', 'Thailand', null, null, '05b2', 'nasikank@th.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051291', 'Nguyen', 'Thi Huong Lan', null, null, 'PT-BE', 'SVN', 'Vietnam', null, null, null, 'lan.nguyenthihuong@vn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051292', 'Tong', 'Thi Viet Nga', null, null, 'PT-AC', 'SAP', 'Vietnam', null, '/ISiteImg/1547685938183.jpeg', '05ee', 'nga.tongthiviet@vn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051293', 'Tran', 'Thanh Vu', null, null, 'PT-BE', 'SVN', 'Vietnam', null, null, '110305B6', 'vu.tranthanh@vn.bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051294', 'Bui', 'Anh Tuan', null, null, 'PT-BE', 'SVN', 'Vietnam', null, '/ISiteImg/1547774903275.jpeg', '067e', 'tuan.buianh@vn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051295', 'Tran', 'Tri Dang', null, null, 'PT-HG', 'SKA15', 'Vietnam', null, null, '11030612', 'dang.trantri2@vn.bosch.com', '2', null, null);
INSERT INTO `user` VALUES ('10051296', 'Kurtic', 'Jana', null, null, 'RBSM', 'PJ-DSC', 'Serbia', null, '/ISiteImg/1547771120893.jpeg', '1103059E', 'Jana.Kurtic@bosch.com', '1', null, null);
INSERT INTO `user` VALUES ('10051297', 'Christian', 'Long', null, null, 'PT-BE', 'MKU', 'China', null, null, '064c', 'Christian.LONG@cn.bosch.com', '3', null, null);
INSERT INTO `user` VALUES ('10051298', 'Vivian', 'Chen       ', null, null, 'PT-BE', 'MKB1 (MKU) ', 'China', null, null, null, 'MKB1.PT-BE@cn.bosch.com', null, null, null);
INSERT INTO `user` VALUES ('10051299', 'Jiang', 'Wei          ', null, null, 'PT-BE', 'MKB1-2 (MKB1)', 'China', null, null, null, 'MKB1-2.PT-BE@cn.bosch.com', null, null, null);

-- ----------------------------
-- Table structure for user_card_bind
-- ----------------------------
DROP TABLE IF EXISTS `user_card_bind`;
CREATE TABLE `user_card_bind` (
  `id` varchar(255) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `dev_id` varchar(255) DEFAULT NULL COMMENT '设备id',
  `create_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户和卡绑定表';

-- ----------------------------
-- Records of user_card_bind
-- ----------------------------
INSERT INTO `user_card_bind` VALUES ('1085547872616845312', '10051000', '000000000000000x', '2019-01-16 22:42:35');
INSERT INTO `user_card_bind` VALUES ('1085547944654016512', '10051134', '0000000011030565', '2019-01-16 22:42:53');
INSERT INTO `user_card_bind` VALUES ('1085690175406870528', '10051116', '00000000110305AA', '2019-01-17 08:08:03');
INSERT INTO `user_card_bind` VALUES ('1085692551744327680', '10051084', '00000000110305AC', '2019-01-17 08:17:30');
INSERT INTO `user_card_bind` VALUES ('1085694183446024192', '10051083', '00000000110305E9', '2019-01-17 08:23:59');
INSERT INTO `user_card_bind` VALUES ('1085696132434235392', '10051149', '0000000011030667', '2019-01-17 08:31:43');
INSERT INTO `user_card_bind` VALUES ('1085696800775606272', '10051019', '000000001103058C', '2019-01-17 08:34:23');
INSERT INTO `user_card_bind` VALUES ('1085696881511763968', '10051011', '0000000011030589', '2019-01-17 08:34:42');
INSERT INTO `user_card_bind` VALUES ('1085697427740168192', '10051047', '000000001103058B', '2019-01-17 08:36:52');
INSERT INTO `user_card_bind` VALUES ('1085697484531044352', '10051094', '0000000011030570', '2019-01-17 08:37:06');
INSERT INTO `user_card_bind` VALUES ('1085697521361227776', '10051066', '0000000011030649', '2019-01-17 08:37:15');
INSERT INTO `user_card_bind` VALUES ('1085697626990579712', '10051248', '000000001103064A', '2019-01-17 08:37:40');
INSERT INTO `user_card_bind` VALUES ('1085698221130518528', '10051284', '00000000110305A5', '2019-01-17 08:40:01');
INSERT INTO `user_card_bind` VALUES ('1085698647636709376', '10051292', '00000000110305EE', '2019-01-17 08:41:43');
INSERT INTO `user_card_bind` VALUES ('1085698780919107584', '10051067', '0000000011030632', '2019-01-17 08:42:15');
INSERT INTO `user_card_bind` VALUES ('1085699299838398464', '10051044', '000000001103063D', '2019-01-17 08:44:19');
INSERT INTO `user_card_bind` VALUES ('1085699361960235008', '10051225', '00000000110305AB', '2019-01-17 08:44:33');
INSERT INTO `user_card_bind` VALUES ('1085699571738349568', '10051054', '000000001103064B', '2019-01-17 08:45:23');
INSERT INTO `user_card_bind` VALUES ('1085699694685982720', '10051062', '00000000110305A3', '2019-01-17 08:45:53');
INSERT INTO `user_card_bind` VALUES ('1085699883308027904', '10051010', '00000000110305B4', '2019-01-17 08:46:38');
INSERT INTO `user_card_bind` VALUES ('1085700049268248576', '10051117', '0000000011030579', '2019-01-17 08:47:17');
INSERT INTO `user_card_bind` VALUES ('1085700343586754560', '10051024', '00000000110305A4', '2019-01-17 08:48:27');
INSERT INTO `user_card_bind` VALUES ('1085700770214580224', '10051181', '0000000011030572', '2019-01-17 08:50:09');
INSERT INTO `user_card_bind` VALUES ('1085700848438349824', '10051213', '00000000110305A8', '2019-01-17 08:50:28');
INSERT INTO `user_card_bind` VALUES ('1085700901953474560', '10051173', '00000000110305A1', '2019-01-17 08:50:41');
INSERT INTO `user_card_bind` VALUES ('1085701042768842752', '10051266', '00000000110305A9', '2019-01-17 08:51:14');
INSERT INTO `user_card_bind` VALUES ('1085701078919548928', '10051216', '00000000110305A7', '2019-01-17 08:51:23');
INSERT INTO `user_card_bind` VALUES ('1085701442393739264', '10051144', '0000000011030573', '2019-01-17 08:52:49');
INSERT INTO `user_card_bind` VALUES ('1085701476388573184', '10051182', '000000001103064D', '2019-01-17 08:52:57');
INSERT INTO `user_card_bind` VALUES ('1085701616738373632', '10051052', '0000000011030575', '2019-01-17 08:53:31');
INSERT INTO `user_card_bind` VALUES ('1085701854299557888', '10051214', '000000001103064F', '2019-01-17 08:54:28');
INSERT INTO `user_card_bind` VALUES ('1085702068645269504', '10051297', '000000001103064C', '2019-01-17 08:55:19');
INSERT INTO `user_card_bind` VALUES ('1085702822089068544', '10051242', '0000000011030652', '2019-01-17 08:58:18');
INSERT INTO `user_card_bind` VALUES ('1085703072329633792', '10051097', '0000000011030640', '2019-01-17 08:59:18');
INSERT INTO `user_card_bind` VALUES ('1085703080974094336', '10051286', '000000001103063E', '2019-01-17 08:59:20');
INSERT INTO `user_card_bind` VALUES ('1085703189359104000', '10051078', '00000000110305B0', '2019-01-17 08:59:46');
INSERT INTO `user_card_bind` VALUES ('1085703253930414080', '10051065', '00000000110305DD', '2019-01-17 09:00:01');
INSERT INTO `user_card_bind` VALUES ('1085703356615364608', '10051086', '00000000110305F8', '2019-01-17 09:00:26');
INSERT INTO `user_card_bind` VALUES ('1085703440409169920', '10051076', '00000000110305AF', '2019-01-17 09:00:46');
INSERT INTO `user_card_bind` VALUES ('1085703554133528576', '10051183', '0000000011030636', '2019-01-17 09:01:13');
INSERT INTO `user_card_bind` VALUES ('1085703555966439424', '10051030', '00000000110305E3', '2019-01-17 09:01:13');
INSERT INTO `user_card_bind` VALUES ('1085703599339737088', '10051289', '000000001103063C', '2019-01-17 09:01:24');
INSERT INTO `user_card_bind` VALUES ('1085703664133345280', '10051038', '00000000110305E8', '2019-01-17 09:01:39');
INSERT INTO `user_card_bind` VALUES ('1085703938503741440', '10051017', '0000000011030650', '2019-01-17 09:02:45');
INSERT INTO `user_card_bind` VALUES ('1085704170775908352', '10051190', '0000000011030576', '2019-01-17 09:03:40');
INSERT INTO `user_card_bind` VALUES ('1085704346945064960', '10051290', '00000000110305B2', '2019-01-17 09:04:22');
INSERT INTO `user_card_bind` VALUES ('1085704470228242432', '10051215', '000000001103063F', '2019-01-17 09:04:51');
INSERT INTO `user_card_bind` VALUES ('1085704552193331200', '10051171', '0000000011030645', '2019-01-17 09:05:11');
INSERT INTO `user_card_bind` VALUES ('1085704608120180736', '10051279', '0000000011030641', '2019-01-17 09:05:24');
INSERT INTO `user_card_bind` VALUES ('1085704984085008384', '10051114', '0000000011030587', '2019-01-17 09:06:54');
INSERT INTO `user_card_bind` VALUES ('1085705299026907136', '10051001', '0000000011030566', '2019-01-17 09:08:09');
INSERT INTO `user_card_bind` VALUES ('1085705832802422784', '10051200', '0000000011030603', '2019-01-17 09:10:16');
INSERT INTO `user_card_bind` VALUES ('1085705879187230720', '10051265', '0000000011030602', '2019-01-17 09:10:27');
INSERT INTO `user_card_bind` VALUES ('1085706152261586944', '10051121', '0000000011030588', '2019-01-17 09:11:32');
INSERT INTO `user_card_bind` VALUES ('1085706761907867648', '10051042', '0000000011030578', '2019-01-17 09:13:58');
INSERT INTO `user_card_bind` VALUES ('1085706816870027264', '10051217', '000000001103064E', '2019-01-17 09:14:11');
INSERT INTO `user_card_bind` VALUES ('1085707193409474560', '10051231', '00000000110305E1', '2019-01-17 09:15:41');
INSERT INTO `user_card_bind` VALUES ('1085707837667151872', '10051288', '0000000011030585', '2019-01-17 09:18:14');
INSERT INTO `user_card_bind` VALUES ('1085708101878943744', '10051118', '00000000110305FE', '2019-01-17 09:19:17');
INSERT INTO `user_card_bind` VALUES ('1085709071375536128', '10051199', '0000000011030646', '2019-01-17 09:23:08');
INSERT INTO `user_card_bind` VALUES ('1085709185963921408', '10051203', '000000001103056C', '2019-01-17 09:23:36');
INSERT INTO `user_card_bind` VALUES ('1085710035536973824', '10051123', '00000000110305C3', '2019-01-17 09:26:58');
INSERT INTO `user_card_bind` VALUES ('1085710155158523904', '10051202', '0000000011030584', '2019-01-17 09:27:27');
INSERT INTO `user_card_bind` VALUES ('1085710489989812224', '10051129', '00000000110305C8', '2019-01-17 09:28:46');
INSERT INTO `user_card_bind` VALUES ('1085710518955675648', '10051204', '00000000110305FD', '2019-01-17 09:28:53');
INSERT INTO `user_card_bind` VALUES ('1085710642750558208', '10051126', '00000000110305C7', '2019-01-17 09:29:23');
INSERT INTO `user_card_bind` VALUES ('1085711059718901760', '10051186', '000000001103063A', '2019-01-17 09:31:02');
INSERT INTO `user_card_bind` VALUES ('1085712054058356736', '10051249', '0000000011030604', '2019-01-17 09:34:59');
INSERT INTO `user_card_bind` VALUES ('1085714112094277632', '10051112', '0000000011030610', '2019-01-17 09:43:10');
INSERT INTO `user_card_bind` VALUES ('1085714934563737600', '10051151', '00000000110305E2', '2019-01-17 09:46:26');
INSERT INTO `user_card_bind` VALUES ('1085718347301130240', '10051153', '000000001103057D', '2019-01-17 10:00:00');
INSERT INTO `user_card_bind` VALUES ('1085718601392066560', '10051166', '000000001103056B', '2019-01-17 10:01:00');
INSERT INTO `user_card_bind` VALUES ('1085719365996908544', '10051140', '0000000011030577', '2019-01-17 10:04:03');
INSERT INTO `user_card_bind` VALUES ('1085719785746075648', '10051191', '0000000011030567', '2019-01-17 10:05:43');
INSERT INTO `user_card_bind` VALUES ('1085721050089656320', '10051045', '00000000110305BE', '2019-01-17 10:10:44');
INSERT INTO `user_card_bind` VALUES ('1085722917553180672', '10051136', '000000001103057B', '2019-01-17 10:18:09');
INSERT INTO `user_card_bind` VALUES ('1085723260584333312', '10051069', '0000000011030690', '2019-01-17 10:19:31');
INSERT INTO `user_card_bind` VALUES ('1085724827576307712', '10051267', '0000000011030653', '2019-01-17 10:25:45');
INSERT INTO `user_card_bind` VALUES ('1085727199316807680', '10051125', '000000001103062B', '2019-01-17 10:35:10');
INSERT INTO `user_card_bind` VALUES ('1085727262751461376', '10051156', '00000000110305BD', '2019-01-17 10:35:25');
INSERT INTO `user_card_bind` VALUES ('1085727318988689408', '10051124', '000000001103068F', '2019-01-17 10:35:39');
INSERT INTO `user_card_bind` VALUES ('1085727762725081088', '10051074', '000000001103057F', '2019-01-17 10:37:25');
INSERT INTO `user_card_bind` VALUES ('1085727776310431744', '10051188', '000000001103068D', '2019-01-17 10:37:28');
INSERT INTO `user_card_bind` VALUES ('1085728874165309440', '10051250', '00000000110305BC', '2019-01-17 10:41:50');
INSERT INTO `user_card_bind` VALUES ('1085729102079594496', '10051255', '000000001103057A', '2019-01-17 10:42:44');
INSERT INTO `user_card_bind` VALUES ('1085731220958089216', '10051090', '00000000110305BB', '2019-01-17 10:51:09');
INSERT INTO `user_card_bind` VALUES ('1085731594871902208', '10051070', '0000000011030637', '2019-01-17 10:52:38');
INSERT INTO `user_card_bind` VALUES ('1085731872622907392', '10051072', '00000000110305B7', '2019-01-17 10:53:45');
INSERT INTO `user_card_bind` VALUES ('1085732015254409216', '10051073', '000000001103068E', '2019-01-17 10:54:19');
INSERT INTO `user_card_bind` VALUES ('1085732076260560896', '10051064', '0000000011030639', '2019-01-17 10:54:33');
INSERT INTO `user_card_bind` VALUES ('1085732528054210560', '10051059', '00000000110305BA', '2019-01-17 10:56:21');
INSERT INTO `user_card_bind` VALUES ('1085733878792065024', '10051021', '0000000011030593', '2019-01-17 11:01:43');
INSERT INTO `user_card_bind` VALUES ('1085733971452628992', '10051089', '0000000011030638', '2019-01-17 11:02:05');
INSERT INTO `user_card_bind` VALUES ('1085734222007767040', '10051080', '000000001103057E', '2019-01-17 11:03:05');
INSERT INTO `user_card_bind` VALUES ('1085734424508764160', '10051230', '00000000110305FB', '2019-01-17 11:03:53');
INSERT INTO `user_card_bind` VALUES ('1085734646727184384', '10051036', '0000000011030595', '2019-01-17 11:04:46');
INSERT INTO `user_card_bind` VALUES ('1085734646882373632', '10051251', '000000001103068B', '2019-01-17 11:04:46');
INSERT INTO `user_card_bind` VALUES ('1085735270566989824', '10051093', '0000000011030629', '2019-01-17 11:07:15');
INSERT INTO `user_card_bind` VALUES ('1085735596003037184', '10051135', '0000000011030627', '2019-01-17 11:08:32');
INSERT INTO `user_card_bind` VALUES ('1085735900341735424', '10051092', '000000001103068C', '2019-01-17 11:09:45');
INSERT INTO `user_card_bind` VALUES ('1085736025818533888', '10051049', '0000000011030592', '2019-01-17 11:10:15');
INSERT INTO `user_card_bind` VALUES ('1085736668604010496', '10051176', '0000000011030591', '2019-01-17 11:12:48');
INSERT INTO `user_card_bind` VALUES ('1085736759695904768', '10051276', '000000001103068A', '2019-01-17 11:13:10');
INSERT INTO `user_card_bind` VALUES ('1085736801919963136', '10051178', '000000001103062C', '2019-01-17 11:13:20');
INSERT INTO `user_card_bind` VALUES ('1085736865610469376', '10051209', '0000000011030623', '2019-01-17 11:13:35');
INSERT INTO `user_card_bind` VALUES ('1085736886879784960', '10051104', '0000000011030687', '2019-01-17 11:13:40');
INSERT INTO `user_card_bind` VALUES ('1085737514049867776', '10051229', '0000000011030583', '2019-01-17 11:16:10');
INSERT INTO `user_card_bind` VALUES ('1085737550510952448', '10051246', '0000000011030624', '2019-01-17 11:16:18');
INSERT INTO `user_card_bind` VALUES ('1085737649454583808', '10051245', '0000000011030642', '2019-01-17 11:16:42');
INSERT INTO `user_card_bind` VALUES ('1085737765917822976', '10051257', '0000000011030594', '2019-01-17 11:17:10');
INSERT INTO `user_card_bind` VALUES ('1085737779138269184', '10051175', '00000000110305E7', '2019-01-17 11:17:13');
INSERT INTO `user_card_bind` VALUES ('1085737821056143360', '10051283', '0000000011030617', '2019-01-17 11:17:23');
INSERT INTO `user_card_bind` VALUES ('1085738092784128000', '10051271', '0000000011030626', '2019-01-17 11:18:28');
INSERT INTO `user_card_bind` VALUES ('1085738804427493376', '10051244', '00000000110305B8', '2019-01-17 11:21:17');
INSERT INTO `user_card_bind` VALUES ('1085739121709813760', '10051142', '0000000011030655', '2019-01-17 11:22:33');
INSERT INTO `user_card_bind` VALUES ('1085739801107369984', '10051081', '000000001103059A', '2019-01-17 11:25:15');
INSERT INTO `user_card_bind` VALUES ('1085740206298107904', '10051061', '0000000011030628', '2019-01-17 11:26:51');
INSERT INTO `user_card_bind` VALUES ('1085740215982755840', '10051241', '0000000011030569', '2019-01-17 11:26:54');
INSERT INTO `user_card_bind` VALUES ('1085741986960510976', '10051025', '000000001103066D', '2019-01-17 11:33:56');
INSERT INTO `user_card_bind` VALUES ('1085742543838253056', '10051102', '0000000011030635', '2019-01-17 11:36:09');
INSERT INTO `user_card_bind` VALUES ('1085742575236812800', '10051143', '0000000011030633', '2019-01-17 11:36:16');
INSERT INTO `user_card_bind` VALUES ('1085742670946635776', '10051111', '0000000011030658', '2019-01-17 11:36:39');
INSERT INTO `user_card_bind` VALUES ('1085742752945278976', '10051198', '00000000110305E4', '2019-01-17 11:36:59');
INSERT INTO `user_card_bind` VALUES ('1085743597963317248', '10051128', '0000000011030631', '2019-01-17 11:40:20');
INSERT INTO `user_card_bind` VALUES ('1085744620043898880', '10051003', '0000000011030630', '2019-01-17 11:44:24');
INSERT INTO `user_card_bind` VALUES ('1085745502575792128', '10051051', '000000001103062D', '2019-01-17 11:47:54');
INSERT INTO `user_card_bind` VALUES ('1085745665616777216', '10051087', '0000000011030597', '2019-01-17 11:48:33');
INSERT INTO `user_card_bind` VALUES ('1085745850505891840', '10051254', '0000000011030669', '2019-01-17 11:49:17');
INSERT INTO `user_card_bind` VALUES ('1085746152722272256', '10051268', '0000000011030600', '2019-01-17 11:50:29');
INSERT INTO `user_card_bind` VALUES ('1085747018514698240', '10051120', '000000001103065C', '2019-01-17 11:53:56');
INSERT INTO `user_card_bind` VALUES ('1085747318839447552', '10051075', '000000001103062E', '2019-01-17 11:55:07');
INSERT INTO `user_card_bind` VALUES ('1085747547231883264', '10051063', '000000001103065A', '2019-01-17 11:56:02');
INSERT INTO `user_card_bind` VALUES ('1085747619277443072', '10051050', '000000001103065B', '2019-01-17 11:56:19');
INSERT INTO `user_card_bind` VALUES ('1085748485292167168', '10051197', '000000001103056E', '2019-01-17 11:59:45');
INSERT INTO `user_card_bind` VALUES ('1085749838819233792', '10051071', '0000000011030568', '2019-01-17 12:05:08');
INSERT INTO `user_card_bind` VALUES ('1085750783363911680', '10051275', '00000000110305B5', '2019-01-17 12:08:53');
INSERT INTO `user_card_bind` VALUES ('1085750966898266112', '10051027', '000000001103059B', '2019-01-17 12:09:37');
INSERT INTO `user_card_bind` VALUES ('1085751185014657024', '10051212', '00000000110305FC', '2019-01-17 12:10:29');
INSERT INTO `user_card_bind` VALUES ('1085751568059469824', '10051256', '0000000011030625', '2019-01-17 12:12:00');
INSERT INTO `user_card_bind` VALUES ('1085751837883240448', '10051132', '00000000110305A2', '2019-01-17 12:13:05');
INSERT INTO `user_card_bind` VALUES ('1085752099502952448', '10051107', '0000000011030656', '2019-01-17 12:14:07');
INSERT INTO `user_card_bind` VALUES ('1085753008400240640', '10051219', '0000000011030598', '2019-01-17 12:17:44');
INSERT INTO `user_card_bind` VALUES ('1085755386117623808', '10051258', '000000001103066C', '2019-01-17 12:27:11');
INSERT INTO `user_card_bind` VALUES ('1085758087803047936', '10051031', '0000000011030686', '2019-01-17 12:37:55');
INSERT INTO `user_card_bind` VALUES ('1085758099295440896', '10051034', '00000000110305CC', '2019-01-17 12:37:57');
INSERT INTO `user_card_bind` VALUES ('1085758780983087104', '10051033', '00000000110305CE', '2019-01-17 12:40:40');
INSERT INTO `user_card_bind` VALUES ('1085759066711658496', '10051101', '000000001103067F', '2019-01-17 12:41:48');
INSERT INTO `user_card_bind` VALUES ('1085759802744901632', '10051159', '00000000110305CF', '2019-01-17 12:44:44');
INSERT INTO `user_card_bind` VALUES ('1085760632696999936', '10051168', '000000001103056A', '2019-01-17 12:48:01');
INSERT INTO `user_card_bind` VALUES ('1085761783614017536', '10051272', '00000000110305CD', '2019-01-17 12:52:36');
INSERT INTO `user_card_bind` VALUES ('1085761897111883776', '10051243', '000000001103061A', '2019-01-17 12:53:03');
INSERT INTO `user_card_bind` VALUES ('1085761959166611456', '10051287', '00000000110305D0', '2019-01-17 12:53:18');
INSERT INTO `user_card_bind` VALUES ('1085762089907261440', '10051264', '0000000011030685', '2019-01-17 12:53:49');
INSERT INTO `user_card_bind` VALUES ('1085762114792067072', '10051294', '000000001103067E', '2019-01-17 12:53:55');
INSERT INTO `user_card_bind` VALUES ('1085763835303956480', '10051026', '000000001103062F', '2019-01-17 13:00:45');
INSERT INTO `user_card_bind` VALUES ('1085764768146526208', '10051228', '0000000011030590', '2019-01-17 13:04:27');
INSERT INTO `user_card_bind` VALUES ('1085765661747187712', '10051098', '000000001103056F', '2019-01-17 13:08:00');
INSERT INTO `user_card_bind` VALUES ('1085765780181749760', '10051131', '000000001103061D', '2019-01-17 13:08:29');
INSERT INTO `user_card_bind` VALUES ('1085765914525306880', '10051122', '0000000011030622', '2019-01-17 13:09:01');
INSERT INTO `user_card_bind` VALUES ('1085766222173310976', '10051158', '0000000011030621', '2019-01-17 13:10:14');
INSERT INTO `user_card_bind` VALUES ('1085766276405661696', '10051039', '0000000011030596', '2019-01-17 13:10:27');
INSERT INTO `user_card_bind` VALUES ('1085766302217408512', '10051138', '0000000011030679', '2019-01-17 13:10:33');
INSERT INTO `user_card_bind` VALUES ('1085766351802470400', '10051150', '000000001103061B', '2019-01-17 13:10:45');
INSERT INTO `user_card_bind` VALUES ('1085766422740733952', '10051163', '000000001103067A', '2019-01-17 13:11:02');
INSERT INTO `user_card_bind` VALUES ('1085766488339648512', '10051145', '00000000110305CB', '2019-01-17 13:11:18');
INSERT INTO `user_card_bind` VALUES ('1085766612793036800', '10051088', '0000000011030678', '2019-01-17 13:11:47');
INSERT INTO `user_card_bind` VALUES ('1085766717914877952', '10051192', '0000000011030674', '2019-01-17 13:12:12');
INSERT INTO `user_card_bind` VALUES ('1085766746561974272', '10051165', '00000000110305D2', '2019-01-17 13:12:19');
INSERT INTO `user_card_bind` VALUES ('1085766788148498432', '10051167', '0000000011030620', '2019-01-17 13:12:29');
INSERT INTO `user_card_bind` VALUES ('1085766842758336512', '10051060', '0000000011030673', '2019-01-17 13:12:42');
INSERT INTO `user_card_bind` VALUES ('1085766855647432704', '10051179', '00000000110305D1', '2019-01-17 13:12:45');
INSERT INTO `user_card_bind` VALUES ('1085767018663251968', '10051157', '0000000011030676', '2019-01-17 13:13:24');
INSERT INTO `user_card_bind` VALUES ('1085767201568460800', '10051252', '00000000110305F5', '2019-01-17 13:14:08');
INSERT INTO `user_card_bind` VALUES ('1085768828564148224', '10051184', '000000001103059D', '2019-01-17 13:20:35');
INSERT INTO `user_card_bind` VALUES ('1085769142973370368', '10051110', '00000000110305CA', '2019-01-17 13:21:50');
INSERT INTO `user_card_bind` VALUES ('1085770556923580416', '10051041', '0000000011030611', '2019-01-17 13:27:28');
INSERT INTO `user_card_bind` VALUES ('1085770614452654080', '10051253', '000000001103059C', '2019-01-17 13:27:41');
INSERT INTO `user_card_bind` VALUES ('1085770687156719616', '10051048', '0000000011030613', '2019-01-17 13:27:59');
INSERT INTO `user_card_bind` VALUES ('1085771177286307840', '10051032', '00000000110305F9', '2019-01-17 13:29:55');
INSERT INTO `user_card_bind` VALUES ('1085771181786796032', '10051154', '0000000011030616', '2019-01-17 13:29:57');
INSERT INTO `user_card_bind` VALUES ('1085772387640807424', '10051105', '00000000110305FF', '2019-01-17 13:34:44');
INSERT INTO `user_card_bind` VALUES ('1085773723690209280', '10051004', '00000000110305A0', '2019-01-17 13:40:03');
INSERT INTO `user_card_bind` VALUES ('1085773754396708864', '10051139', '0000000011030619', '2019-01-17 13:40:10');
INSERT INTO `user_card_bind` VALUES ('1085774513469263872', '10051195', '0000000011030581', '2019-01-17 13:43:11');
INSERT INTO `user_card_bind` VALUES ('1085774656063016960', '10051170', '000000001103058D', '2019-01-17 13:43:45');
INSERT INTO `user_card_bind` VALUES ('1085775529384218624', '10051247', '00000000110305DE', '2019-01-17 13:47:13');
INSERT INTO `user_card_bind` VALUES ('1085775632236941312', '10051148', '000000001103058F', '2019-01-17 13:47:38');
INSERT INTO `user_card_bind` VALUES ('1085775742610051072', '10051127', '0000000011030681', '2019-01-17 13:48:04');
INSERT INTO `user_card_bind` VALUES ('1085776105899692032', '10051077', '000000001103061F', '2019-01-17 13:49:31');
INSERT INTO `user_card_bind` VALUES ('1085776303900200960', '10051160', '000000001103065E', '2019-01-17 13:50:18');
INSERT INTO `user_card_bind` VALUES ('1085777111047868416', '10051177', '000000001103067D', '2019-01-17 13:53:30');
INSERT INTO `user_card_bind` VALUES ('1085778407821807616', '10051185', '0000000011030659', '2019-01-17 13:58:39');
INSERT INTO `user_card_bind` VALUES ('1085780959602806784', '10051079', '0000000011030677', '2019-01-17 14:08:48');
INSERT INTO `user_card_bind` VALUES ('1085781161692762112', '10051210', '00000000110305BF', '2019-01-17 14:09:36');
INSERT INTO `user_card_bind` VALUES ('1085781437715714048', '10051096', '0000000011030654', '2019-01-17 14:10:42');
INSERT INTO `user_card_bind` VALUES ('1085781895104565248', '10051091', '0000000011030695', '2019-01-17 14:12:31');
INSERT INTO `user_card_bind` VALUES ('1085783029965787136', '10051226', '0000000011030680', '2019-01-17 14:17:01');
INSERT INTO `user_card_bind` VALUES ('1085783059502075904', '10051043', '0000000011030675', '2019-01-17 14:17:08');
INSERT INTO `user_card_bind` VALUES ('1085786207251730432', '10051014', '0000000011030684', '2019-01-17 14:29:39');
INSERT INTO `user_card_bind` VALUES ('1085787879386517504', '10051013', '00000000110305C0', '2019-01-17 14:36:18');
INSERT INTO `user_card_bind` VALUES ('1085787974102290432', '10051029', '0000000011030601', '2019-01-17 14:36:40');
INSERT INTO `user_card_bind` VALUES ('1085791865887920128', '10051169', '00000000110305F0', '2019-01-17 14:52:08');
INSERT INTO `user_card_bind` VALUES ('1085791941926457344', '10051028', '0000000011030644', '2019-01-17 14:52:26');
INSERT INTO `user_card_bind` VALUES ('1085794767356432384', '10051055', '000000001103063B', '2019-01-17 15:03:40');
INSERT INTO `user_card_bind` VALUES ('1085796897983172608', '10051023', '000000001103060D', '2019-01-17 15:12:08');
INSERT INTO `user_card_bind` VALUES ('1085799451018268672', '10051015', '000000001103060A', '2019-01-17 15:22:16');
INSERT INTO `user_card_bind` VALUES ('1085799451437699072', '10051018', '00000000110305D7', '2019-01-17 15:22:17');
INSERT INTO `user_card_bind` VALUES ('1085801597394620416', '10051053', '00000000110305DA', '2019-01-17 15:30:48');
INSERT INTO `user_card_bind` VALUES ('1085802684772126720', '10051040', '000000001103065D', '2019-01-17 15:35:07');
INSERT INTO `user_card_bind` VALUES ('1085803138709065728', '10051106', '000000001103058E', '2019-01-17 15:36:56');
INSERT INTO `user_card_bind` VALUES ('1085804962656686080', '10051108', '0000000011030691', '2019-01-17 15:44:11');
INSERT INTO `user_card_bind` VALUES ('1085805399275343872', '10051196', '000000001103060B', '2019-01-17 15:45:55');
INSERT INTO `user_card_bind` VALUES ('1085805606197137408', '10051020', '0000000011030607', '2019-01-17 15:46:44');
INSERT INTO `user_card_bind` VALUES ('1085805844853035008', '10051022', '0000000011030661', '2019-01-17 15:47:41');
INSERT INTO `user_card_bind` VALUES ('1085805882245255168', '10051007', '00000000110305D3', '2019-01-17 15:47:50');
INSERT INTO `user_card_bind` VALUES ('1085807081921056768', '10051058', '0000000011030605', '2019-01-17 15:52:36');
INSERT INTO `user_card_bind` VALUES ('1085807134593126400', '10051035', '00000000110305EF', '2019-01-17 15:52:48');
INSERT INTO `user_card_bind` VALUES ('1085809118519889920', '10051207', '00000000110305DC', '2019-01-17 16:00:41');
INSERT INTO `user_card_bind` VALUES ('1085809146512674816', '10051205', '0000000011030672', '2019-01-17 16:00:48');
INSERT INTO `user_card_bind` VALUES ('1085809170265018368', '10051208', '0000000011030665', '2019-01-17 16:00:54');
INSERT INTO `user_card_bind` VALUES ('1085810791686475776', '10051293', '00000000110305B6', '2019-01-17 16:07:20');
INSERT INTO `user_card_bind` VALUES ('1085811422534963200', '10051119', '00000000110305D4', '2019-01-17 16:09:51');
INSERT INTO `user_card_bind` VALUES ('1085813372420755456', '10051012', '00000000110305F3', '2019-01-17 16:17:36');
INSERT INTO `user_card_bind` VALUES ('1085814218973908992', '10051295', '0000000011030612', '2019-01-17 16:20:57');
INSERT INTO `user_card_bind` VALUES ('1085814335210655744', '10051281', '00000000110305D5', '2019-01-17 16:21:25');
INSERT INTO `user_card_bind` VALUES ('1085815325766848512', '10051057', '0000000011030668', '2019-01-17 16:25:21');
INSERT INTO `user_card_bind` VALUES ('1085820124784627712', '10051046', '0000000011030694', '2019-01-17 16:44:25');
INSERT INTO `user_card_bind` VALUES ('1085820288383455232', '10051187', '00000000110305E6', '2019-01-17 16:45:04');
INSERT INTO `user_card_bind` VALUES ('1085822987397107712', '10051211', '0000000011030683', '2019-01-17 16:55:48');
INSERT INTO `user_card_bind` VALUES ('1085826512546041856', '10051172', '0000000011030670', '2019-01-17 17:09:48');
INSERT INTO `user_card_bind` VALUES ('1085826519395340288', '10051147', '000000001103060F', '2019-01-17 17:09:50');
INSERT INTO `user_card_bind` VALUES ('1085826570783952896', '10051137', '0000000011030614', '2019-01-17 17:10:02');
INSERT INTO `user_card_bind` VALUES ('1085827217889562624', '10051261', '000000001103066E', '2019-01-17 17:12:37');
INSERT INTO `user_card_bind` VALUES ('1085827327579000832', '10051082', '0000000011030693', '2019-01-17 17:13:03');
INSERT INTO `user_card_bind` VALUES ('1085828085292601344', '10051056', '00000000110305D9', '2019-01-17 17:16:03');
INSERT INTO `user_card_bind` VALUES ('1085828594699210752', '10051239', '0000000011030608', '2019-01-17 17:18:05');
INSERT INTO `user_card_bind` VALUES ('1085831040632754176', '10051016', '00000000110305C1', '2019-01-17 17:27:48');
INSERT INTO `user_card_bind` VALUES ('1085838535090638848', '10051280', '000000001103060E', '2019-01-17 17:57:35');
INSERT INTO `user_card_bind` VALUES ('1085838879866621952', '10051260', '00000000110305C6', '2019-01-17 17:58:57');
INSERT INTO `user_card_bind` VALUES ('1085839176986923008', '10051238', '000000001103066F', '2019-01-17 18:00:08');
INSERT INTO `user_card_bind` VALUES ('1085839601689563136', '10051259', '0000000011030618', '2019-01-17 18:01:49');
INSERT INTO `user_card_bind` VALUES ('1085839746019758080', '10051282', '000000001103066B', '2019-01-17 18:02:24');
INSERT INTO `user_card_bind` VALUES ('1085840937663467520', '10051278', '0000000011030599', '2019-01-17 18:07:08');
INSERT INTO `user_card_bind` VALUES ('1085843149772951552', '10051285', '0000000011030647', '2019-01-17 18:15:55');
INSERT INTO `user_card_bind` VALUES ('1085846531887730688', '10051227', '00000000110305EB', '2019-01-17 18:29:21');
INSERT INTO `user_card_bind` VALUES ('1085848160439504896', '10051155', '0000000011030566', '2019-01-17 18:35:50');
INSERT INTO `user_card_bind` VALUES ('1085858431216259072', '10051109', '0000000011030580', '2019-01-17 19:16:38');
INSERT INTO `user_card_bind` VALUES ('1085902303799676928', '10051133', '0000000011030666', '2019-01-17 22:10:58');
INSERT INTO `user_card_bind` VALUES ('1085902775952478208', '10051130', '0000000011030657', '2019-01-17 22:12:51');
INSERT INTO `user_card_bind` VALUES ('1085902807673999360', '10051095', '00000000110305AD', '2019-01-17 22:12:59');
INSERT INTO `user_card_bind` VALUES ('1085908223350935552', '10051201', '00000000110305E0', '2019-01-17 22:34:30');
INSERT INTO `user_card_bind` VALUES ('001', '001', '0000000011030696', '2019-01-17 09:04:22');
INSERT INTO `user_card_bind` VALUES ('002', '002', '0000000011030697', '2019-01-17 09:04:22');
INSERT INTO `user_card_bind` VALUES ('003', '003', '0000000011030698', '2019-01-17 09:04:22');
INSERT INTO `user_card_bind` VALUES ('004', '004', '0000000011030699', '2019-01-17 09:04:22');
INSERT INTO `user_card_bind` VALUES ('005', '005', '000000001103069a', '2019-01-17 09:04:22');
INSERT INTO `user_card_bind` VALUES ('1086047704523608064', '10051009', '0000000011030615', '2019-01-18 07:48:45');
INSERT INTO `user_card_bind` VALUES ('1086047859939348480', '10051006', '0000000011030606', '2019-01-18 07:49:22');
INSERT INTO `user_card_bind` VALUES ('1086050237568651264', '10051085', '0000000011030662', '2019-01-18 07:58:49');
INSERT INTO `user_card_bind` VALUES ('1086054188418469888', '10051189', '00000000110305C5', '2019-01-18 08:14:31');
INSERT INTO `user_card_bind` VALUES ('1086055578800885760', '10051180', '0000000011030574', '2019-01-18 08:20:02');
INSERT INTO `user_card_bind` VALUES ('1086056792171089920', '10051296', '000000001103059E', '2019-01-18 08:24:51');
INSERT INTO `user_card_bind` VALUES ('1086057453596053504', '10051193', '000000001103061C', '2019-01-18 08:27:29');
INSERT INTO `user_card_bind` VALUES ('1086073031895420928', '10051269', '00000000110305DF', '2019-01-18 09:29:23');
INSERT INTO `user_card_bind` VALUES ('1086086312584417280', '10051001', '00000000110305C2', '2019-01-18 10:22:10');
INSERT INTO `user_card_bind` VALUES ('1086091628072013824', '10051115', '00000000110305F1', '2019-01-18 10:43:17');
INSERT INTO `user_card_bind` VALUES ('1086105168648474624', '10051164', '0000000011030571', '2019-01-18 11:37:05');
INSERT INTO `user_card_bind` VALUES ('1086130983587155968', '10051099', '00000000110305B9', '2019-01-18 13:19:40');
INSERT INTO `user_card_bind` VALUES ('1086135470791987200', '10051161', '000000001103061E', '2019-01-18 13:37:30');
INSERT INTO `user_card_bind` VALUES ('1086148106808070144', '10051274', '000000001103062A', '2019-01-18 14:27:42');
INSERT INTO `user_card_bind` VALUES ('1086151262128443392', '10051263', '00000000110305E5', '2019-01-18 14:40:15');
INSERT INTO `user_card_bind` VALUES ('1086165510640504832', '10051232', '0000000011030689', '2019-01-18 15:36:52');

-- ----------------------------
-- Table structure for user_card_bind_copy
-- ----------------------------
DROP TABLE IF EXISTS `user_card_bind_copy`;
CREATE TABLE `user_card_bind_copy` (
  `id` varchar(255) NOT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `dev_id` varchar(255) DEFAULT NULL COMMENT '设备id',
  `create_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户和卡绑定表';

-- ----------------------------
-- Records of user_card_bind_copy
-- ----------------------------
INSERT INTO `user_card_bind_copy` VALUES ('1085547872616845312', '10051000', '000000000000000x', '2019-01-16 22:42:35');
INSERT INTO `user_card_bind_copy` VALUES ('1085547944654016512', '10051134', '0000000011030565', '2019-01-16 22:42:53');
INSERT INTO `user_card_bind_copy` VALUES ('1085690175406870528', '10051116', '00000000110305AA', '2019-01-17 08:08:03');
INSERT INTO `user_card_bind_copy` VALUES ('1085692551744327680', '10051084', '00000000110305AC', '2019-01-17 08:17:30');
INSERT INTO `user_card_bind_copy` VALUES ('1085694183446024192', '10051083', '00000000110305E9', '2019-01-17 08:23:59');
INSERT INTO `user_card_bind_copy` VALUES ('1085696132434235392', '10051149', '0000000011030667', '2019-01-17 08:31:43');
INSERT INTO `user_card_bind_copy` VALUES ('1085696800775606272', '10051019', '000000001103058C', '2019-01-17 08:34:23');
INSERT INTO `user_card_bind_copy` VALUES ('1085696881511763968', '10051011', '0000000011030589', '2019-01-17 08:34:42');
INSERT INTO `user_card_bind_copy` VALUES ('1085697427740168192', '10051047', '000000001103058B', '2019-01-17 08:36:52');
INSERT INTO `user_card_bind_copy` VALUES ('1085697484531044352', '10051094', '0000000011030570', '2019-01-17 08:37:06');
INSERT INTO `user_card_bind_copy` VALUES ('1085697521361227776', '10051066', '0000000011030649', '2019-01-17 08:37:15');
INSERT INTO `user_card_bind_copy` VALUES ('1085697626990579712', '10051248', '000000001103064A', '2019-01-17 08:37:40');
INSERT INTO `user_card_bind_copy` VALUES ('1085698221130518528', '10051284', '00000000110305A5', '2019-01-17 08:40:01');
INSERT INTO `user_card_bind_copy` VALUES ('1085698647636709376', '10051292', '00000000110305EE', '2019-01-17 08:41:43');
INSERT INTO `user_card_bind_copy` VALUES ('1085698780919107584', '10051067', '0000000011030632', '2019-01-17 08:42:15');
INSERT INTO `user_card_bind_copy` VALUES ('1085699299838398464', '10051044', '000000001103063D', '2019-01-17 08:44:19');
INSERT INTO `user_card_bind_copy` VALUES ('1085699361960235008', '10051225', '00000000110305AB', '2019-01-17 08:44:33');
INSERT INTO `user_card_bind_copy` VALUES ('1085699571738349568', '10051054', '000000001103064B', '2019-01-17 08:45:23');
INSERT INTO `user_card_bind_copy` VALUES ('1085699694685982720', '10051062', '00000000110305A3', '2019-01-17 08:45:53');
INSERT INTO `user_card_bind_copy` VALUES ('1085699883308027904', '10051010', '00000000110305B4', '2019-01-17 08:46:38');
INSERT INTO `user_card_bind_copy` VALUES ('1085700049268248576', '10051117', '0000000011030579', '2019-01-17 08:47:17');
INSERT INTO `user_card_bind_copy` VALUES ('1085700343586754560', '10051024', '00000000110305A4', '2019-01-17 08:48:27');
INSERT INTO `user_card_bind_copy` VALUES ('1085700770214580224', '10051181', '0000000011030572', '2019-01-17 08:50:09');
INSERT INTO `user_card_bind_copy` VALUES ('1085700848438349824', '10051213', '00000000110305A8', '2019-01-17 08:50:28');
INSERT INTO `user_card_bind_copy` VALUES ('1085700901953474560', '10051173', '00000000110305A1', '2019-01-17 08:50:41');
INSERT INTO `user_card_bind_copy` VALUES ('1085701042768842752', '10051266', '00000000110305A9', '2019-01-17 08:51:14');
INSERT INTO `user_card_bind_copy` VALUES ('1085701078919548928', '10051216', '00000000110305A7', '2019-01-17 08:51:23');
INSERT INTO `user_card_bind_copy` VALUES ('1085701442393739264', '10051144', '0000000011030573', '2019-01-17 08:52:49');
INSERT INTO `user_card_bind_copy` VALUES ('1085701476388573184', '10051182', '000000001103064D', '2019-01-17 08:52:57');
INSERT INTO `user_card_bind_copy` VALUES ('1085701616738373632', '10051052', '0000000011030575', '2019-01-17 08:53:31');
INSERT INTO `user_card_bind_copy` VALUES ('1085701854299557888', '10051214', '000000001103064F', '2019-01-17 08:54:28');
INSERT INTO `user_card_bind_copy` VALUES ('1085702068645269504', '10051297', '000000001103064C', '2019-01-17 08:55:19');
INSERT INTO `user_card_bind_copy` VALUES ('1085702822089068544', '10051242', '0000000011030652', '2019-01-17 08:58:18');
INSERT INTO `user_card_bind_copy` VALUES ('1085703072329633792', '10051097', '0000000011030640', '2019-01-17 08:59:18');
INSERT INTO `user_card_bind_copy` VALUES ('1085703080974094336', '10051286', '000000001103063E', '2019-01-17 08:59:20');
INSERT INTO `user_card_bind_copy` VALUES ('1085703189359104000', '10051078', '00000000110305B0', '2019-01-17 08:59:46');
INSERT INTO `user_card_bind_copy` VALUES ('1085703253930414080', '10051065', '00000000110305DD', '2019-01-17 09:00:01');
INSERT INTO `user_card_bind_copy` VALUES ('1085703356615364608', '10051086', '00000000110305F8', '2019-01-17 09:00:26');
INSERT INTO `user_card_bind_copy` VALUES ('1085703440409169920', '10051076', '00000000110305AF', '2019-01-17 09:00:46');
INSERT INTO `user_card_bind_copy` VALUES ('1085703554133528576', '10051183', '0000000011030636', '2019-01-17 09:01:13');
INSERT INTO `user_card_bind_copy` VALUES ('1085703555966439424', '10051030', '00000000110305E3', '2019-01-17 09:01:13');
INSERT INTO `user_card_bind_copy` VALUES ('1085703599339737088', '10051289', '000000001103063C', '2019-01-17 09:01:24');
INSERT INTO `user_card_bind_copy` VALUES ('1085703664133345280', '10051038', '00000000110305E8', '2019-01-17 09:01:39');
INSERT INTO `user_card_bind_copy` VALUES ('1085703938503741440', '10051017', '0000000011030650', '2019-01-17 09:02:45');
INSERT INTO `user_card_bind_copy` VALUES ('1085704170775908352', '10051190', '0000000011030576', '2019-01-17 09:03:40');
INSERT INTO `user_card_bind_copy` VALUES ('1085704346945064960', '10051290', '00000000110305B2', '2019-01-17 09:04:22');
INSERT INTO `user_card_bind_copy` VALUES ('1085704470228242432', '10051215', '000000001103063F', '2019-01-17 09:04:51');
INSERT INTO `user_card_bind_copy` VALUES ('1085704552193331200', '10051171', '0000000011030645', '2019-01-17 09:05:11');
INSERT INTO `user_card_bind_copy` VALUES ('1085704608120180736', '10051279', '0000000011030641', '2019-01-17 09:05:24');
INSERT INTO `user_card_bind_copy` VALUES ('1085704984085008384', '10051114', '0000000011030587', '2019-01-17 09:06:54');
INSERT INTO `user_card_bind_copy` VALUES ('1085705299026907136', '10051001', '0000000011030566', '2019-01-17 09:08:09');
INSERT INTO `user_card_bind_copy` VALUES ('1085705832802422784', '10051200', '0000000011030603', '2019-01-17 09:10:16');
INSERT INTO `user_card_bind_copy` VALUES ('1085705879187230720', '10051265', '0000000011030602', '2019-01-17 09:10:27');
INSERT INTO `user_card_bind_copy` VALUES ('1085706152261586944', '10051121', '0000000011030588', '2019-01-17 09:11:32');

-- ----------------------------
-- Table structure for user_group
-- ----------------------------
DROP TABLE IF EXISTS `user_group`;
CREATE TABLE `user_group` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT '组的名称(包括颜色)',
  `color` varchar(255) DEFAULT NULL COMMENT '组的颜色',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_group
-- ----------------------------
INSERT INTO `user_group` VALUES ('1', 'group_red', 'red');
INSERT INTO `user_group` VALUES ('2', 'group_green', '#8EC63F');
INSERT INTO `user_group` VALUES ('3', 'group_blue', '#01AEF0');
INSERT INTO `user_group` VALUES ('4', 'Staff', 'red');
INSERT INTO `user_group` VALUES ('5', 'Speakers_Leaders', '#b5b504');
INSERT INTO `user_group` VALUES ('6', 'safetyHat', '#b5b504');
